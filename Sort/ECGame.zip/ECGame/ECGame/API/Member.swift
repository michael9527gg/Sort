//
//  Account.swift
//  EEGame
//
//  Created by Michale on 2019/10/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import Moya



enum Member {
    static let provider = ECProvider<Member>(manager: ECSessionManager.shared)

    
    /// 用户名+ 密码+ 验证码 登陆
    case loginCaptcha(userID:String,pwd:String,captchaValue:String,captchaKey:String)
    
    /// 用户名+ 密码 登陆
    case login(userID:String,pwd:String)
    case logout
    case register(userName:String,pwd:String,recommend:String?)
    
    /// 获取用户信息
    case userInfo(userID:String,connectionID:String)
    
    /// 用户是否存在
    case userExists(userId:String)
    
    /// 修改用户密码
    case modifyPwd(userID:String,oldPwd:String,newPwd:String)
    
    /// 交易记录 存款充值
    case payDetailsList(startDate:String?,endDate:String?,state:String?,
        pageIndex:Int,pageSize:Int,userID:String)
    
    /// 交易记录 提现提款
    case distillDetailsList(startDate:String?,endDate:String?,state:String?,
        pageIndex:Int,pageSize:Int,userID:String)
    
    /// 交易记录 优惠记录
    case promotionDetailsList(startDate:String?,endDate:String?,state:String?,
        pageIndex:Int,pageSize:Int,userID:String)
    
    /// 交易记录 返水记录
    case returnDetailsList(startDate:String?,endDate:String?,state:String?,
        pageIndex:Int,pageSize:Int,userID:String)
    
    /// 投注记录
    case betsList(startDate:String?,endDate:String?,
        betState:String?,openState:Bool,
        pageIndex:Int?,pageSize:Int?,userID:String)
    

    /// 消息列表
    case messageList(pageIndex:Int,pageSize:Int,userID:String)
    
    /// 消息详情
    case messageInfo(mid:String,userID:String)
    
    /// 绑定银行卡列表
    case userBankList(userID:String,pageIndex:Int,pageSize:Int)
    
    /// 绑定银行卡
    case bindBank(bankID:String,subbranch:String,cardNumber:String,userID:String)
    
    /// 发送手机验证码
    case mobileCode(mobile:String)
    
    /// 手机号注册
    case registerMobile(mobile:String,authCode:String,recommend:String?)
    
    /// 手机号登陆
    case loginMobile(mobile:String,authCode:String)
    
    /// 绑定手机号
    case bindMobile(mobile:String,authCode:String,userID:String)
    
    /// 修改用户信息
    case updateUserInfo(realityName:String?,nickName:String?,
        sex:Bool?,birthDay:String?,idcardNumber:String?,
        address:String?,qq:String?,email:String?,userID:String)
    
    /// 验证手机号码
    case verifyCode(mobile:String,authCode:String)
    
    /// 重置密码
    case resetPwd(mobile:String,authCode:String,newPassword:String,userID:String)
    
    /// 提现提款
    case distill(ubid:String,money:String,userID:String)
    
    /// 开下级会员
    case createSubUser(name:String?,password:String,subUserID:String,userID:String)
    
    /// 佣金列表
    case bonusList(pageIndex:Int,pageSize:Int,userID:String)
    
    /// 下级会员列表
    case subUserList(pageIndex:Int,pageSize:Int,userID:String)
    
    /// 为下级充值
    case rechargeSub(subUserID:String,payType:Int,money:String,
        description:String,userID:String)
    
    /// 投注记录（下级）
    case subBetRecord(subUserID:String?,startDate:String?,endDate:String?,
        betState:String?,openState:Bool,pageIndex:Int,pageSize:Int,userID:String)
}

extension Member:ECTargetType{
    
    var baseURL: URL {
        return self.domain.appendingPathComponent("api/Member")
    }
    
    var path: String {
        switch self {
        case .login:
            return "Login1"
        case .loginCaptcha:
            return "Login2"
        case .logout:
            return "Logout"
        case .register:
            return "RegisterByUserID"
        case .userInfo:
            return "GetUserBaseInfo"
        case .modifyPwd:
            return "ModifyPassword"
        case .payDetailsList:
            return "GetUserPayDetailsList"
        case .distillDetailsList:
            return "GetUserDistillDetailsList"
        case .promotionDetailsList:
            return "GetUserPromotionDetailsList"
        case .returnDetailsList:
            return "GetUserReturnDetailsList"
        case .betsList:
            return "GetUserBetsList"
        case .userExists:
            return "UserExists"
        case .messageList:
            return "GetMsgMessageList"
        case .messageInfo:
            return "GetMsgMessageInfo"
        case .userBankList:
            return "GetUserBankList"
        case .bindBank:
            return "BindBank"
        case .mobileCode:
            return "SendMobileAuthCode"
        case .registerMobile:
            return "RegisterByMobile"
        case .loginMobile:
            return "LoginMobile"
        case .bindMobile:
            return "BindMobile"
        case .updateUserInfo:
            return "UpdateUserBaseInfo"
        case .distill:
            return "UserDistill"
        case .verifyCode:
            return "VerifyMobileAuthCode"
        case .resetPwd:
            return "ResetPassword"
        case .createSubUser:
            return "CreateSubUser"
        case .bonusList:
            return "GetUnionBonusList"
        case .subUserList:
            return "GetRecommendInfoList"
        case .rechargeSub:
            return "SubUserPay"
        case .subBetRecord:
            return "GetSubUserBetsList"
        }
    }
    
    var parameters: [String : Any]?{
        
        switch self {
        case let .userExists(userId):
            return ["userID":userId]
        case let .login(userID, pwd):
            return ["userID": userID, "password": pwd]
        case let .register(userName, pwd, recommend):
            return ["userID": userName, "password": pwd,"recommend":recommend ?? ""]
        case let .loginCaptcha(userID, pwd, captchaValue, captchaKey):
            return ["userID": userID, "password": pwd,
                    "captchaVerifyParam":["captchaValue":captchaValue,
                                          "captchaKey":captchaKey]]
        case let .userInfo(userID, connectionID):
            return ["userID": userID,"connectionID":connectionID]
        case let .modifyPwd(userId,oldPwd, newPwd):
            return ["userID":userId, "oldPassword": oldPwd,"newPassword":newPwd]
            
        /// 交易记录
        case let .distillDetailsList(startDate, endDate, state, pageIndex, pageSize, userID):
            return ["startDate":startDate ?? "", "endDate": endDate ?? "","state":state ?? "","pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .payDetailsList(startDate, endDate, state, pageIndex, pageSize, userID):
            return ["startDate":startDate ?? "", "endDate": endDate ?? "","state":state ?? "","pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .returnDetailsList(startDate, endDate, state, pageIndex, pageSize, userID):
            return ["startDate":startDate ?? "", "endDate": endDate ?? "","state":state ?? "","pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .promotionDetailsList(startDate, endDate, state, pageIndex, pageSize, userID):
            return ["startDate":startDate ?? "", "endDate": endDate ?? "","state":state ?? "","pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .betsList(startDate, endDate, betState, openState, pageIndex, pageSize, userID):
            return ["startDate":startDate ?? "", "endDate": endDate ?? "","betState":betState ?? "","openState":openState ?1:0,"pageIndex":pageIndex ?? 0,"pageSize":pageSize ?? 0,"userID":userID]
            
        case let .messageList(pageIndex, pageSize, userID):
            return ["pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .messageInfo(mid, userID):
            return ["mid":mid,"userID":userID]
        case let .userBankList(userID, pageIndex, pageSize):
            return ["userID":userID,"pageIndex":pageIndex,"pageSize":pageSize]
        case let .bindBank(bankID, subbranch, cardNumber, userID):
            return ["bankID":bankID,"subbranch":subbranch,
                    "cardNumber":cardNumber,"userID":userID]
        case let .mobileCode(mobile):
            return ["mobile":mobile]
        case let .registerMobile(mobile, authCode, recommend):
            return ["mobile":mobile,"authCode":authCode,"recommend":recommend ?? ""]
        case let .loginMobile(mobile, authCode):
            return ["mobile":mobile,"authCode":authCode]
        case let .bindMobile(mobile, authCode, userID):
            return ["mobile":mobile,"authCode":authCode,"userID":userID]
        case let .updateUserInfo(realityName, nickName, sex, birthDay, idcardNumber, address, qq, email, userID):
            var info:[String:Any] = ["userID":userID]
            realityName != nil ? (info["realityName"] = realityName!) : nil
            nickName != nil ? (info["nickName"] = nickName!) : nil
            sex != nil ? (info["sex"] = sex!) : nil
            birthDay != nil ? (info["birthDay"] = birthDay!) : nil
            idcardNumber != nil ? (info["idcardNumber"] = idcardNumber!) : nil
            address != nil ? (info["address"] = address!) : nil
            qq != nil ? (info["qq"] = qq!) : nil
            email != nil ? (info["email"] = email!) : nil
            return info
        case let .verifyCode(mobile, authCode):
            return ["mobile":mobile,"authCode":authCode]
        case let .resetPwd(mobile, authCode, newPassword, userID):
            return ["mobile":mobile,"authCode":authCode,
                    "newPassword":newPassword,"userID":userID]
        case let .distill(ubid, money, userID):
            return ["ubid":ubid,"money":money,"userID":userID]
        case let .createSubUser(name, password, subUserID, userID):
            return ["name":name ?? "","password":password,
                    "subUserID":subUserID,"userID":userID]
        case let .bonusList(pageIndex, pageSize, userID):
            return ["pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .subUserList(pageIndex, pageSize, userID):
            return ["pageIndex":pageIndex,"pageSize":pageSize,"userID":userID]
        case let .rechargeSub(subUserID, payType, money, description, userID):
            return ["subUserID":subUserID,"payType":payType,
                    "money":money,"description":description,"userID":userID]
        case let .subBetRecord(subUserID, startDate, endDate, betState, openState, pageIndex, pageSize, userID):
            return ["subUserID":subUserID ?? "","startDate":startDate ?? "",
                    "endDate":endDate ?? "","betState":betState ?? "",
                    "openState":openState ? 1 : 0,"pageIndex":pageIndex,
                    "pageSize":pageSize,"userID":userID]
        default:
            return nil
        }
    }
    
    func translate<T>(resultData: NSDictionary?) -> T? {
        switch self {
        case .register,.login,.loginCaptcha,.registerMobile,.loginMobile:
            let result = MAccessToken(dict: resultData)
            return result as? T
        case .userInfo:
            let user = MUser(dict: resultData)
            return user as? T
        case .distillDetailsList:
            if let dicts = resultData?["userDistillDetailsList"] as? [NSDictionary]{
                let list:[MDistillDetail] = dicts.toModels()
                return list as? T
            }
        case .payDetailsList:
            if let dicts = resultData?["userPayDetailsList"] as? [NSDictionary]{
                let list:[MPayDetail] = dicts.toModels()
                return list as? T
            }
        case .promotionDetailsList:
            if let dicts = resultData?["userPromotionDetailsList"] as? [NSDictionary]{
                let list:[MPromotionDetail] = dicts.toModels()
                return list as? T
            }
        case .returnDetailsList:
            if let dicts = resultData?["userReturnDetailsList"] as? [NSDictionary]{
                let list:[MReturnDetail] = dicts.toModels()
                return list as? T
            }
        case .betsList:
            if let dicts = resultData?["userBetsList"] as? [NSDictionary]{
                let list:[MUserBet] = dicts.toModels()
                return list as? T
            }
        case .messageList:
            if T.self == [MMessage].self,let dicts = resultData?["msgMessageList"] as? [NSDictionary]{
                let list:[MMessage] = dicts.toModels()
                return list as? T
            }
        case .messageInfo:
            if T.self == MMessage.self{
                let info = MMessage(dict: resultData)
                return info as? T
            }
        case .userBankList:
            if T.self == [MUserBank].self,let dicts = resultData?["userBankList"] as? [NSDictionary]{
                let list:[MUserBank] = dicts.toModels()
                return list as? T
            }
        case .bonusList:
            if T.self == [MBonus].self,let dicts = resultData?["unionBonusList"] as? [NSDictionary]{
                let list:[MBonus] = dicts.toModels()
                return list as? T
            }
        case .subUserList:
            if T.self == [MSubUser].self,let dicts = resultData?["recommendInfoList"] as? [NSDictionary]{
                let list:[MSubUser] = dicts.toModels()
                return list as? T
            }
        case .subBetRecord:
            if T.self == [MSubUserBet].self,let dicts = resultData?["userBetsList"] as? [NSDictionary]{
                let list:[MSubUserBet] = dicts.toModels()
                return list as? T
            }
        default:
            break
        }
        return nil
    }
    
}
