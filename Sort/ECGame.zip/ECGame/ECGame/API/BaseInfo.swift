//
//  BaseInfo.swift
//  EEGame
//
//  Created by Michale on 2019/10/8.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import Moya


enum BaseInfo {
    static let provider = ECProvider<BaseInfo>(manager: ECSessionManager.shared)
    
    ///优惠列表
    case promotionList(state:Int?,pageIndex:Int ,pageSize:Int)
    
    /// 公告
    case msgNoticeList(pageIndex:Int,pageSize:Int)
    
    /// 获取验证码
    case getCaptcha(width:Int,height:Int,charCount:Int)
    
    /// 运营商信息
    case getSiteOperator
    
    /// 银行信息列表
    case bankList(pageIndex:Int,pageSize:Int)
}


extension BaseInfo:ECTargetType{
    
    var baseURL: URL {
        return self.domain.appendingPathComponent("api/BaseInfo")
    }
    
    var path: String {
        switch self {
        case .promotionList:
            return "GetPPromotionList"
        case .msgNoticeList:
            return "GetMsgNoticeList"
        case .getCaptcha:
            return "GetCaptchaInfo"
        case .getSiteOperator:
            return "GetSiteOperator"
        case .bankList:
            return "GetBaseBankList"
        }
    }
    
    var parameters: [String : Any]?{
        switch self {
        case let .promotionList(state,pageIndex,pageSize):
            return ["state":state ?? "","pageIndex": pageIndex, "pageSize": pageSize]
        case let .msgNoticeList(pageIndex, pageSize):
            return ["pageIndex": pageIndex, "pageSize": pageSize]
        case let .getCaptcha(width, height, charCount):
            return ["width": width, "height":height,"charCount":charCount]
        case let .bankList(pageIndex, pageSize):
            return ["pageIndex":pageIndex,"pageSize":pageSize]
        default:
            return nil
        }
    }
    
    
    func translate<T>(resultData: NSDictionary?) -> T? {
        switch self {
        case .promotionList:
            if T.self == [MPromotion].self,let dicts = resultData?["pPromotionList"] as? [NSDictionary]{
                let banners:[MPromotion] = dicts.toModels()
                return banners as? T
            }
        case .msgNoticeList:
            if T.self == [MNotice].self,let dicts = resultData?["msgNoticeList"] as? [NSDictionary]{
                let notices:[MNotice] = dicts.toModels()
                return notices as? T
            }
        case .getCaptcha:
            if T.self == MCaptchaInfo.self{
                let captcha = MCaptchaInfo(dict: resultData)
                return captcha as? T
            }
        case .getSiteOperator:
            if T.self == MSiteOperator.self{
                let site = MSiteOperator(dict: resultData)
                return site as? T
            }
        case .bankList:
            if T.self == [MBank].self,let dicts = resultData?["baseBankList"] as? [NSDictionary]{
                let notices:[MBank] = dicts.toModels()
                return notices as? T
            }
        }
        return nil
    }
}
