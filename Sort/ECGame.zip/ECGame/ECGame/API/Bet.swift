//
//  Bet.swift
//  ECGame
//
//  Created by Michale on 2019/10/13.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import Moya
import Result

enum  Bet{
    static let provider = ECProvider<Bet>(manager: ECSessionManager.shared)
    
    /// 游戏列表
    case baseEgameList
    
    /// 首页 比赛列表热门
    case egEgameMatchHotList
    
    /// 比赛明细
    case egEgameMatchDetails(mid:String)
    
    enum MatchSortId:Int {
        /// 今日
        case today = 1
        /// 滚盘
        case rollPlate = 2
        /// 赛前
        case beforeMatch = 3
        /// 赛果
        case afterMatch = 4
    }
    
    /// 赛事列表
    case egEgameMatchList(egids:[String]?,sortID:MatchSortId,pageIndex:Int,pageSize:Int)
    
    /// 用户投注(单关)
    case singleBet(list:[NSDictionary],acceptOddsChange:Bool,userID:String)
    
    /// 用户投注(串投)
    case multipleBet(list:[NSDictionary],acceptOddsChange:Bool,
        money:Decimal,userID:String)
}

extension Bet:ECTargetType{
    
    var baseURL: URL {
        return self.domain.appendingPathComponent("api/Bet")
    }
    
    var path: String {
        switch self {
        case .baseEgameList:
            return "GetBaseEgameList"
        case .egEgameMatchHotList:
            return "GetEgEgameMatchHotList"
        case .egEgameMatchList:
            return "GetEgEgameMatchList"
        case .egEgameMatchDetails:
            return "GetEgEgameMatchDetailsList"
        case .singleBet:
            return "UserBetSingle"
        case .multipleBet:
            return "UserBetMultiple"
        }
    }
    
    var parameters: [String : Any]?{
        switch self {
        case let .egEgameMatchList(egids, sortID, pageIndex, pageSize):
            return ["egid":egids ?? [],"sortID": sortID.rawValue, "pageIndex": pageIndex,"pageSize":pageSize]
        case let .egEgameMatchDetails(mid):
            return ["mid":mid]
        case let .singleBet(list, acceptOddsChange, userID):
            return ["userBetSingleList":list,
                    "acceptOddsChange":acceptOddsChange,"userID":userID]
        case let .multipleBet(list, acceptOddsChange, money, userID):
            return ["acceptOddsChange":acceptOddsChange,"userID":userID,
                    "userBetMultipleExtend":["betType":"\(list.count)",
                        "money":money,"userBetMultipleList":list]]
        default:
            return nil
        }
    }
    
    func translate<T>(resultData: NSDictionary?) -> T? {
        switch self {
        case .baseEgameList:
            if let dicts = resultData?["baseEgameList"] as? [NSDictionary]{
                let list:[MBaseEgame] = dicts.toModels()
                return list as? T
            }
        case .egEgameMatchHotList,.egEgameMatchList:
            if let dicts = resultData?["egEgameMatchList"] as? [NSDictionary]{
                let list:[MEgEgameMatch] = dicts.toModels()
                return list as? T
            }
        case .egEgameMatchDetails:
            let match = MMatchDetail(dict: resultData)
            return match as? T
        default:
            break
        }
        return nil
    }
}

