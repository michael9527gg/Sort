//
//  ECSessionManager.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import Alamofire

class ECSessionManager: Alamofire.SessionManager {
    public static let shared:ECSessionManager = {
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = SessionManager.defaultHTTPHeaders
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 15
        return ECSessionManager(configuration: configuration)
    }()
}
