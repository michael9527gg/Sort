//
//  Account.swift
//  ECGame
//
//  Created by Michale on 2019/10/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

///当前用户登陆后的信息
class Account {
    
    /// current login user
    static var current:Account? = nil
    
    var token:MAccessToken?
    
    var user:MUser?
    
    class func clear() -> Void {
        current = nil
    }
}
