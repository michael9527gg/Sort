//
//  ECProvider.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import Moya
import Result

let refererUrl = "http://10.10.10.25:8888/"

enum ECResult<Type> {
    case success(Type)
    
    /// Indicates a response failed with an invalid HTTP status code.
    case statusCode(Int)
    
    /// Indicates resultCode uncorrect
    case failed(_ code:Int,_ msg:String)
    
    /// Indicates translate dict to model failed
    case untranslate(NSDictionary?)
    
    /// Indicates Data format uncorrect
    case unknowFormat(Response)
    
    /// Indicates failed to connect to server
    case unreachable
}


protocol API {
    var parameters: [String: Any]?{
        get
    }
}
extension API{
    var domain: URL {
        return URL(string: "http://10.10.10.25:8888")!
    }
    var parameters: [String: Any]?{
        return nil
    }
}

protocol ECTargetType:TargetType,API {
    
    /// verify resultCode
    func verify(resultCode:Int) -> Bool
    
    
    /// translate dict to expect type
    func translate<T>(resultData:NSDictionary?) -> T?
}

extension ECTargetType{

    var method: Moya.Method {
        return .post
    }
    
    var sampleData: Data {
        return "".data(using: .utf8)!
    }
    
    var task: Task {
        return .requestParameters(parameters:ECSignature.sign(parameters), encoding: JSONEncoding.default)
    }
    
    var headers: [String : String]? {
        var dict = ["Content-type":"application/json",
                    "Application":"iOS",
                    "Referer":refererUrl]
        if let token = Account.current?.token?.accessToken {
            dict["token"] = token
        }
        return dict
    }
    
    func verify(resultCode:Int) -> Bool{
        return resultCode == 1
    }
    
    func translate<T>(resultData: NSDictionary?) -> T? {
        return nil
    }
}

class ECProvider<Target: ECTargetType>: MoyaProvider<Target> {
    

    /// Closure to be executed when a request has completed.
    public typealias ECCompletion<Type> = (_ result: ECResult<Type>) -> Void

    
    @discardableResult
    open func request<T>(_ target: Target, callbackQueue: DispatchQueue? = .none, progress: ProgressBlock? = .none, completion: @escaping ECCompletion<T>) -> Cancellable{
        return request(target, callbackQueue: callbackQueue, progress: progress) { (result) in
            
            switch result {
            case let .success(moyaResponse):
                let statusCode = moyaResponse.statusCode // Int - 200, 401, 500, etc
                if statusCode != 200{ //wrong code
                    completion(.statusCode(statusCode))
                    return
                }
                
                do{
                    guard let data = try moyaResponse.mapJSON() as? NSDictionary,
                        let code:Int = data["resultCode"],
                        let msg:String = data["message"] else{
                            throw MoyaError.jsonMapping(moyaResponse)
                    }
                    
                    if !target.verify(resultCode: code){
                        completion(.failed(code, msg))
                        return
                    }
                    
                    var resultData:NSDictionary? = nil
                    if let data = data["resultData"] as? NSDictionary{
                        resultData = data
                    }
                    
                    guard let t:T = target.translate(resultData: resultData) else{
                        completion(.untranslate(resultData))
                        return
                    }
                    
                    completion(.success(t))
                }catch{completion(.unknowFormat(moyaResponse))}
            case .failure(_):
                completion(.unreachable)
            }
        }
    }
}
