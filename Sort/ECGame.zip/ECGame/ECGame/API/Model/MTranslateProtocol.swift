//
//  MTranslateProtocol.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


protocol MTranslateProtocol {
    init(dict:NSDictionary?)
}

extension NSDictionary{
    
    subscript<T>(key:String) ->T?{
        get{
            let o = object(forKey: key)
            
            if (o as? T) != nil{
                return o as? T
            }
            
            if (o as? NSNull) != nil{
                return nil
            }
            
            switch T.self {
            case is Int.Type:
                if let str = o as? String{
                    return Int(str) as? T
                }
                return Int("\(o ?? "")") as? T
            case is String.Type:
                return "\(o ?? "")" as? T
            case is Bool.Type:
                if let str = o as? String{
                    return Bool(truncating:NSNumber(value:Int(str) ?? 0)) as? T
                }
                return Bool(truncating: NSNumber(value: Int("\(o ?? "")") ?? 0)) as? T
            case is Double.Type:
                if let str = o as? String{
                    return Double(str) as? T
                }
                return Double("\(o ?? "0")") as? T
            default:
                break
            }
            
            assert(false, "\(T.self) is not implement")//should never come here
            return nil
        }
    }
}

extension Array where Element == NSDictionary{
    func toModels<T>() -> [T] where T:MTranslateProtocol{
        var array = [T]()
        for dict in self {
            array.append(T(dict: dict))
        }
        return array
    }
}
