//
//  MRegisterResult.swift
//  ECGame
//
//  Created by Michale on 2019/10/15.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MAccessToken: MTranslateProtocol {
    
    required init(dict: NSDictionary?) {
        accessToken = dict?["accessToken"]
        tokenTimeOut = dict?["tokenTimeOut"]
        userID = dict?["userID"]
    }

    var userID:String?
    var accessToken:String?//": "string",
    var tokenTimeOut:String?//": "string"
}
