//
//  MUserBet.swift
//  ECGame
//
//  Created by Michale on 2019/11/8.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MUserBet: MTranslateProtocol {
    
    enum State:Int {
        case unsure = 0
        case success = 1
        case canceld = 2
    }
    
    class Details: MTranslateProtocol {
        var edoid:String?//投注ID
        var egameLogo:String?//游戏图标
        var egameName:String?//游戏名称
        var matchName:String?//比赛名称
        var team:String?//队伍
        var handicap:String?//盘口
        var odds:Double?//赔率
        var matchDateTime:String?//比赛时间
        var playSortName:String?//玩法分类
        var playName:String?//玩法名称
        var betType:Int?//投注类型
        var oddsName:String?//赔率名称
        
        required init(dict: NSDictionary?) {
            edoid = dict?["edoid"]
            egameLogo = dict?["egameLogo"]
            egameName = dict?["egameName"]
            matchName = dict?["matchName"]
            team = dict?["team"]
            handicap = dict?["handicap"]
            odds = dict?["odds"]
            matchDateTime = dict?["matchDateTime"]
            playSortName = dict?["playSortName"]
            playName = dict?["playName"]
            betType = dict?["betType"]
            oddsName = dict?["oddsName"]
        }
    }
    
    var bid:String?//投注ID
    var userID:String?//用户
    var betType:Int?//投资类型
    var betTypeName:String?//投资类型名称
    var money:Double?//金额
    var betDateTime:String?//投注时间
    var winMoney:Double?//营利
    var betState:State?//投注状态
    var betStateName:String?//投注状态
    var openState:Bool?//开奖状态 未派奖 = 0,已派奖 = 1
    var openStateName:String?//开奖状态
    var oddsTotal:Double?//总赔率
    var expectedWinMoney:Double?//预计营利
    var egameName:String?//游戏名称
    var matchName:String?//比赛名称
    var betsDetails:[Details]? //投注明细
    
    required init(dict: NSDictionary?) {
        bid = dict?["bid"]
        userID = dict?["userID"]
        betType = dict?["betType"]
        betTypeName = dict?["betTypeName"]
        money = dict?["money"]
        betDateTime = dict?["betDateTime"]
        winMoney = dict?["winMoney"]
        betState = State(rawValue: dict?["betState"] ?? -1)
        betStateName = dict?["betStateName"]
        openState = dict?["openState"]
        openStateName = dict?["openStateName"]
        oddsTotal = dict?["oddsTotal"]
        expectedWinMoney = dict?["expectedWinMoney"]
        egameName = dict?["egameName"]
        matchName = dict?["matchName"]
        if let array = dict?["betsDetails"] as? [NSDictionary],array.count > 0{
            betsDetails = array.toModels()
        }
    }


}
