//
//  MReturnDetail.swift
//  ECGame
//
//  Created by Michale on 2019/10/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MReturnDetail: MTranslateProtocol {
    var rid:String?
    var returnDay:String?//投注日期
    var scale:String?//返水比例
    var money:Double?//返水金额
    var betNumber:Int?//投注笔数
    var betSum:Double?//投注金额
    var state:Bool?//状怘状态 0、失败 1、成功
    var stateName:String?//状态名称
    var returnDate:String?//派发日期
    
    required init(dict: NSDictionary?) {
        rid = dict?["rid"]
        returnDay = dict?["returnDay"]
        scale = dict?["scale"]
        money = dict?["money"]
        betNumber = dict?["betNumber"]
        betSum = dict?["betSum"]
        state = dict?["state"]
        stateName = dict?["stateName"]
        returnDate = dict?["returnDate"]
    }

}
