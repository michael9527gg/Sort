//
//  MSort.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MNewsSort: MTranslateProtocol {
    
    var nSid:String?//分类ID
    var name:String?//名称
    var logo:String?//logo
    
    required init(dict: NSDictionary?) {
        nSid = dict?["nSid"]
        name = dict?["name"]
        logo = dict?["logo"]
    }

}
