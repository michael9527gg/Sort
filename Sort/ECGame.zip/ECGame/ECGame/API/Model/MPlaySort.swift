//
//  MPlaySort.swift
//  ECGame
//
//  Created by Michale on 2019/10/23.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MPlaySort: MTranslateProtocol {
    
    class Detail: MTranslateProtocol {
        
        class Odds: MTranslateProtocol {
            
            required init(dict: NSDictionary?) {
                edoid = dict?["edoid"] ?? ""
                oddsName = dict?["oddsName"] ?? ""
                odds = dict?["odds"] ?? 0
                oddsBetState = dict?["oddsBetState"] ?? false
                result = MEgEgameMatch.Team.State(rawValue: dict?["result"] ?? 0) ?? .nothing
            }
            
            var edoid:String//赔率ID
            var oddsName:String//赔率名称
            var odds:Double// 赔率
            var oddsBetState:Bool//赔率状态
            var result:MEgEgameMatch.Team.State// 结果
        }
        
        required init(dict: NSDictionary?) {
            betState = dict?["betState"] ?? false
            canCombine = dict?["canCombine"] ?? false
            edid = dict?["edid"]
            minMoney = dict?["minMoney"] ?? 0
            maxMoney = dict?["maxMoney"] ?? 0
            playName = dict?["playName"] ?? ""
            if let dicts = dict?["egEgameMatchDetailOddsList"] as? [NSDictionary],
                dicts.count > 0{
                egEgameMatchDetailOddsList = dicts.toModels()
            }
        }
        var edid:String?
        var betState:Bool//能否投注
        var canCombine:Bool//能否串关
        var egEgameMatchDetailOddsList:[Odds]?
        var minMoney:Double//最小投注额
        var maxMoney:Double//最大投注额
        var playName:String//玩法名称
    }
    
    required init(dict: NSDictionary?) {
        playSortName = dict?["playSortName"] ?? ""
        
        if let dicts = dict?["egEgameMatchDetailsList"] as? [NSDictionary],
            dicts.count > 0{
            egEgameMatchDetailsList = dicts.toModels()
        }
    }
    var playSortName:String//分类名称
    var egEgameMatchDetailsList:[Detail]?//玩法列表
}
