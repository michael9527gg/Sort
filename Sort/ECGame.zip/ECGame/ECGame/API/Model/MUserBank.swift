//
//  MUserBank.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class MUserBank: MTranslateProtocol {
    var ubid:String?//绑定银行ID
    var userID:String?//用户ID
    var dateTime:String?//绑定时间
    var bankID:String?//银行名称
    var bankName:String?//银行名称
    var logoUrl:String?
    var subbranch:String?//分行
    var cardNumber:String?//卡号
    var state:String?//状态
    var stateName:String?//状态
    var isDefault:Bool? //是否默认卡
    
    required init(dict: NSDictionary?) {
        ubid = dict?["ubid"]
        userID = dict?["userID"]
        dateTime = dict?["dateTime"]
        bankID = dict?["bankID"]
        bankName = dict?["bankName"]
        logoUrl = dict?["logoUrl"]
        subbranch = dict?["subbranch"]
        cardNumber = dict?["cardNumber"]
        state = dict?["state"]
        stateName = dict?["stateName"]
        isDefault = dict?["isDefault"]
    }


}
