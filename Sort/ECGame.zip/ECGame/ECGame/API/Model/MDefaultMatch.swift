//
//  MDefaultMatch.swift
//  ECGame
//
//  Created by Michale on 2019/10/23.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MDefaultMatch: MTranslateProtocol {
    
    var mid:String? // 比赛ID
    var edid:String? //玩法ID
    var egameLogo:String?//游戏图标
    var matchName:String?//比赛名称
    var matchDateTime:Double?//比赛时间
    var bo:String?//场数
    var hTeam:String?//主队
    var hTeamLogo:String?//主队图标
    var hTeamEDOID:String?//主队赔率ID
    var hTeamOdds:Double?//主队赔率
    var vTeam:String?//主队
    var vTeamLogo:String?//客队图标
    var vTeamOdds:Double?//客队赔率
    var vTeamEDOID:String?//客队赔率ID
    var state:MEgEgameMatch.MatchState?//比赛状态：1、未开赛 2、正在进行 3、比赛结束 4、取消
    var stateName:String?//比赛状态名称：1、未开赛 2、正在进行 3、比赛结束 4、取消
    var result:String?//比赛结果
    var videourl:String?//视频URL
    var liveUrl:String?//直播URL
    var betState:Bool?//投注状态（0、封盘 1、开盘）
    var canCombine:Bool?
    
    required init(dict: NSDictionary?) {
        mid = dict?["mid"]
        edid = dict?["edid"]
        egameLogo = dict?["egameLogo"]
        matchName = dict?["matchName"]
        matchDateTime = dict?["matchDateTime"]
        bo = dict?["bo"]
        hTeam = dict?["hTeam"]
        hTeamLogo = dict?["hTeamLogo"]
        hTeamEDOID = dict?["hTeamEDOID"]
        hTeamOdds = dict?["hTeamOdds"]
        vTeam = dict?["vTeam"]
        vTeamLogo = dict?["vTeamLogo"]
        vTeamOdds = dict?["vTeamOdds"]
        vTeamEDOID = dict?["vTeamEDOID"]
        state = MEgEgameMatch.MatchState(rawValue: dict?["state"] ?? -1)
        stateName = dict?["stateName"]
        result = dict?["result"]
        videourl = dict?["videourl"]
        liveUrl = dict?["liveUrl"]
        betState = dict?["betState"]
        canCombine = dict?["canCombine"]
    }
}
