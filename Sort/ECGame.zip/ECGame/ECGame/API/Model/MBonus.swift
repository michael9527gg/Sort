//
//  MBonus.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class MBonus: MTranslateProtocol {
    var bid:String?//佣金ID
    var returnMonth:String?//返佣年月
    var usersCount:Int?//用户数
    var profit:Double?//利润
    var scale:Double?//比例
    var bonus:Double?//佣金
    var state:Bool?//状态码 1 已结算 0 未结算
    var stateName:String?//状态名称
    var dateTime:String?//日期
    
    required init(dict: NSDictionary?) {
        bid = dict?["bid"]
        returnMonth = dict?["returnMonth"]
        usersCount = dict?["usersCount"]
        profit = dict?["profit"]
        scale = dict?["scale"]
        bonus = dict?["bonus"]
        state = dict?["state"]
        stateName = dict?["stateName"]
        dateTime = dict?["dateTime"]
    }

}
