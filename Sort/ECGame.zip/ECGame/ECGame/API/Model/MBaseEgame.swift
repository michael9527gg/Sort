//
//  MBaseEgame.swift
//  ECGame
//
//  Created by Michale on 2019/10/13.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MBaseEgame: MTranslateProtocol {
   
    required init(dict: NSDictionary?) {
        egid = dict?["egid"] ?? ""
        name = dict?["name"] ?? ""
        shortName = dict?["shortName"] ?? ""
        logo = dict?["logo"] ?? ""
    }
    
    var egid:String//": "4ad3d2fb-97b1-4749-aaf2-7304130f732a",
    var name:String//": "DOTA2",
    var shortName:String//": "DOTA2",
    var logo:String//": "https://yzdj1.com/static/imgs/game/dota1.svg"

}
