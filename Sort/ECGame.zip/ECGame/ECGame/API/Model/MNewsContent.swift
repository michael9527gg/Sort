//
//  MNewsContent.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MNewsContent: MTranslateProtocol {
    
    var cid:String?//资讯信息ID
    var title:String?//标题
    var content:String?//内容
    var clickCount:Int?//点击数
    var memo:String?//备注
    var imgPath:String?//图片地址
    var imageUrls:[String]?//图片集地址
    var videoUrl:String?//视频地址
    var videoDuration:String?//视频时长
    var publishDate:String?//发布日期
    var publishDateString:String?//发布日期字符
    
    required init(dict: NSDictionary?) {
        cid = dict?["cid"]
        title = dict?["title"]
        content = dict?["content"]
        clickCount = dict?["clickCount"]
        memo = dict?["memo"]
        imgPath = dict?["imgPath"]
        if let str:String = dict?["imageUrls"]{
            imageUrls = str.components(separatedBy: ",")
        }
        videoUrl = dict?["videoUrl"]
        videoDuration = dict?["videoDuration"]
        publishDate = dict?["publishDate"]
        publishDateString = dict?["publishDateString"]
    }

}
