//
//  MSubUser.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MSubUser: MTranslateProtocol {
    var userID:String?//用户ID
    var realityName:String?//真实姓名
    var balance:Double?//余额
    var giftBalance:Double?//赠送余额
    var mobile:String?//手机
    var memo:String?//备注
    var isOnline:Bool?//是否在线
    var registerTime:String?//注册时间
    var state:Bool?//状态 1正常，0冻结
    var stateName:String?
    
    required init(dict: NSDictionary?) {
        userID = dict?["userID"]
        realityName = dict?["realityName"]
        balance = dict?["balance"]
        giftBalance = dict?["giftBalance"]
        mobile = dict?["mobile"]
        memo = dict?["memo"]
        isOnline = dict?["isOnline"]
        registerTime = dict?["registerTime"]
        state = dict?["state"]
        stateName = dict?["stateName"]
    }

}
