//
//  MDistillDetail.swift
//  ECGame
//
//  Created by Michale on 2019/10/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MDistillDetail: MTranslateProtocol {
    
    required init(dict: NSDictionary?) {
        ddid = dict?["ddid"] ?? ""
        userID = dict?["userID"] ?? ""
        distillDate = dict?["distillDate"] ?? ""
        money = dict?["money"] ?? 0
        formalitiesFees = dict?["formalitiesFees"] ?? ""
        memo = dict?["memo"] ?? ""
        auditor = dict?["auditor"] ?? ""
        auditDate = dict?["auditDate"] ?? ""
        payer = dict?["payer"] ?? ""
        payDate = dict?["payDate"] ?? ""
        state = dict?["state"] ?? false
        stateName = dict?["stateName"] ?? ""
        description = dict?["description"] ?? ""
    }
    
    
    var ddid:String//提现ID
    var userID:String//用户
    var distillDate:String//提现日期
    var money:Double// 金额
    var formalitiesFees:String//手续费
    var memo:String//备注
    var auditor:String//审核人
    var auditDate:String//审核日期
    var payer:String//打款人
    var payDate:String//打款日期
    var state:Bool//状态
    var stateName:String// 状态名称
    var description:String//描述
}
