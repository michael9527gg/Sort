//
//  MNewsType.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MNewsType: MTranslateProtocol {
    
    required init(dict: NSDictionary?) {
        itid = dict?["itid"] ?? ""
        name = dict?["name"] ?? ""
    }

    var itid:String//": "7b261dc2-1cdd-49f0-b477-00280c873a1c",
    var name:String//": "新闻"
}
