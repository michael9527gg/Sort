//
//  MPromotionDetail.swift
//  ECGame
//
//  Created by Michale on 2019/10/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MPromotionDetail: MTranslateProtocol {
    
    var pid:String?//优惠活动编号
    var distillDate:String?//优惠时间
    var money:Double?//金额
    var state:Bool?//状态 0、失败  1、成功
    var stateName:String?//状态名称
    var title:String?//标题
    
    required init(dict: NSDictionary?) {
        pid = dict?["pid"]
        distillDate = dict?["distillDate"]
        money = dict?["money"]
        state = dict?["state"]
        stateName = dict?["stateName"]
        title = dict?["title"]
    }

    
}
