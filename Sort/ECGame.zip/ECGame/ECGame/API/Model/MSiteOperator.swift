
//
//  MSiteOperator.swift
//  ECGame
//
//  Created by Michale on 2019/12/5.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MSiteOperator:MTranslateProtocol {
    var siteName:String?//站点名称
    var state:String?//状态码
    var stateName:String?
    var readOnly:String?//状态名称
    var signalUrl:String?
    var operatorName:String?//运营商名称
    var shortName:String?//简称
    var phone:String?//电话
    var email:String?//邮箱
    var wx:String?//微信
    var wxUrl:String?//微信二维码地址
    var onlineUrl:String?//在线URL
    var qq:String?
    var memo:String?//备注
    var logo:String?
    
    required init(dict: NSDictionary?) {
        siteName = dict?["siteName"]
        state = dict?["state"]
        stateName = dict?["stateName"]
        readOnly = dict?["readOnly"]
        signalUrl = dict?["signalUrl"]
        operatorName = dict?["operatorName"]
        shortName = dict?["shortName"]
        phone = dict?["phone"]
        email = dict?["email"]
        wx = dict?["wx"]
        wxUrl = dict?["wxUrl"]
        onlineUrl = dict?["onlineUrl"]
        qq = dict?["qq"]
        memo = dict?["memo"]
        logo = dict?["logo"]
    }


}
