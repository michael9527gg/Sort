//
//  MUser.swift
//  ECGame
//
//  Created by Michale on 2019/10/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MUser:MTranslateProtocol {

    enum Sex:Int {
        case boy = 4
        case girl = 5
    }
    
    var userID:String?//用户ID
    var realityName:String?//真实姓名
    var nickName:String?//昵称
    var sex:Sex?//性别
    var birthDay:String?//生日
    var idcardNumber:String?//身份证
    var cityID:String?//城市
    var address:String?//地址
    var qq:String?
    var weixin:String?//微信
    var email:String?//邮箱
    var isEmailValided:Bool?//是否邮箱验证
    var mobile:String?//手机
    var isMobileValided:Bool?//是否手机验证
    var isBankValided:Bool?//是否银行验证
    var alipayName:String?//支付宝
    var alipayID:String?//支付宝ID
    var isAlipayValided:Bool?//是否支付宝验证
    var securityQuestion:String?//问题
    var securityAnswer:String?//答案
    var memo:String?//备注
    var level:Int?//级别
    var recommend:String?//推荐人
    var registerTime:String?//注册时间
    var registerIp:String?//注册地址
    var registerFrom:Int?//注册来源
    var lastLoginTime:String?//最后登录时间
    var lastLoginIp:String?//最后登录IP
    var name:String?//名称
    var balance:Double?//余额
    var giftBalance:Double?//赠送余额
    var freeze:Double?//冻结余额
    var isOnline:Bool?//是否在线
    var state:Bool?//状态0、停用  1、启用
    var isUion:Bool?//是否代理商
    
    required init(dict: NSDictionary?) {
        userID = dict?["userID"]
        realityName = dict?["realityName"]
        nickName = dict?["nickName"]
        if let b:Bool = dict?["sex"]{
            sex = b ? .boy : .girl
        }
        birthDay = dict?["birthDay"]
        idcardNumber = dict?["idcardNumber"]
        cityID = dict?["cityID"]
        address = dict?["address"]
        qq = dict?["qq"]
        weixin = dict?["weixin"]
        email = dict?["email"]
        isEmailValided = dict?["isEmailValided"]
        mobile = dict?["mobile"]
        isMobileValided = dict?["isMobileValided"]
        isBankValided = dict?["isBankValided"]
        alipayName = dict?["alipayName"]
        alipayID = dict?["alipayID"]
        isAlipayValided = dict?["isAlipayValided"]
        securityQuestion = dict?["securityQuestion"]
        securityAnswer = dict?["securityAnswer"]
        memo = dict?["memo"]
        level = dict?["level"]
        recommend = dict?["recommend"]
        registerTime = dict?["registerTime"]
        registerIp = dict?["registerIp"]
        registerFrom = dict?["registerFrom"]
        lastLoginTime = dict?["lastLoginTime"]
        lastLoginIp = dict?["lastLoginIp"]
        name = dict?["name"]
        balance = dict?["balance"]
        giftBalance = dict?["giftBalance"]
        freeze = dict?["freeze"]
        isOnline = dict?["isOnline"]
        state = dict?["state"]
        isUion = dict?["isUion"]
    }

}
