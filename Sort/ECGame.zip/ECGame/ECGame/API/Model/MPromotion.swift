//
//  MPromotion.swift
//  ECGame
//
//  Created by Michale on 2019/10/11.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class MPromotion:MTranslateProtocol {
    
    var pid:String?//优惠ID
    var title:String?//标题
    var content:String?//内容
    var activityContent:String?//活动内容
    var activityReward:String?//活动奖励
    var activityRule:String?//活动规则
    var imgUrl:String?//图片地址
    var fromDate:String?//开始时间
    var endDate:String?//结束时间
    var memo:String?//备注
    var state:String?//状态码
    var stateName:String?//状态名称
    
    required init(dict: NSDictionary?) {
        pid = dict?["pid"]
        title = dict?["title"]
        content = dict?["content"]
        activityContent = dict?["activityContent"]
        activityReward = dict?["activityReward"]
        activityRule = dict?["activityRule"]
        imgUrl = dict?["imgUrl"]
        fromDate = dict?["fromDate"]
        endDate = dict?["endDate"]
        memo = dict?["memo"]
        state = dict?["state"]
        stateName = dict?["stateName"]
    }

}
