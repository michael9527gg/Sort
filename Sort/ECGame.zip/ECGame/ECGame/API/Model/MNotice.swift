//
//  MNotice.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation



class MNotice:MTranslateProtocol {
    
    required init(dict:NSDictionary?) {
        nid = dict?["nid"] ?? ""
        title = dict?["title"] ?? ""
        content = dict?["content"] ?? ""
        publishDateTime = dict?["publishDateTime"] ?? ""
        url = dict?["url"] ?? ""
    }
    
    var nid:String//": "476acc06-4a28-4d6e-9a6c-9824e186b2b0",
    var title:String//": "stone是车神",
    var content:String//": "stone是车神",
    var publishDateTime:String//": "2019-09-20",
    var url:String//": ""
}
