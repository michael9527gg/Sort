//
//  MEgEgameMatch.swift
//  ECGame
//
//  Created by Michale on 2019/10/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MEgEgameMatch: MTranslateProtocol {
    
    /// 比赛状态
    enum MatchState:Int {
        
        /// 滚盘中
        case rolling = 1
        
        /// 直播中
        case living = 2
        
        /// 即将滚盘
        case willRoll = 5
        
        /// 即将开始
        case willBegin = 6
        
        /// 比赛结束
        case over = 3

        /// 取消
        case canceled = 4
    }
    
    
    class Team: MTranslateProtocol {
        
        enum State:Int {
            /// 未出结果
            case nothing = 0
            
            /// 赢了
            case win = 1
            
            /// 输了
            case lose = 2
            
            /// 没有结果
            case noResult = 3
            
            /// 取消
            case canceled = 4
        }
        
        required init(dict: NSDictionary?) {
            edoid = dict?["edoid"] ?? ""
            team = dict?["team"] ?? ""
            teamLogo = dict?["teamLogo"] ?? ""
            oddsBetState = dict?["oddsBetState"] ?? false
            odds = dict?["odds"] ?? 0
            oddsName = dict?["oddsName"] ?? ""
            result = State(rawValue: dict?["result"] ?? 0) ?? .nothing
        }
        
        var edoid:String//赔率ID
        var team:String//队伍
        var teamLogo:String//LOGO
        var oddsBetState:Bool//是否可投注状态
        var odds:Double//赔率
        var oddsName:String
        var result:State//胜败结果
        
        var trend:ECSocket.MOddsChanged.Trend?//自定义字段,赔率变化
        var isSelected:Bool? //自定义字段，是否选择
    }
    
    required init(dict: NSDictionary?) {
        mid = dict?["mid"] ?? ""
        edid = dict?["edid"]
        egameLogo = dict?["egameLogo"] ?? ""
        matchName = dict?["matchName"] ?? ""
        matchDateTime = dict?["matchDateTime"] ?? 0
        result = dict?["result"] ?? ""
        bo = dict?["bo"] ?? 0
        isLive = dict?["isLive"] ?? false
        isLiving = dict?["isLiving"] ?? false
        videourl = dict?["videourl"] ?? ""
        liveUrl = dict?["liveUrl"] ?? ""
        updateDateTime = dict?["updateDateTime"] ?? ""
        state = MEgEgameMatch.MatchState(rawValue: dict?["state"] ?? 0)
        stateName = dict?["stateName"] ?? ""
        betState = dict?["betState"] ?? false
        betStateName = dict?["betStateName"] ?? ""
        canCombine = dict?["canCombine"] ?? false
        minMoney = dict?["minMoney"] ?? 0
        maxMoney = dict?["maxMoney"] ?? 0
        playName = dict?["playName"] ?? ""
        playSortName = dict?["playSortName"] ?? ""
        playCount = dict?["playCount"] ?? 0
        
        playDetail = ECSocket.MPlayChanged.Detail(dict: nil)
        playDetail?.betState = dict?["playBetState"] ?? false
        playDetail?.canCombine = dict?["playCanCombine"] ?? false
        
        if let arry = dict?["egEgameMatchTeamList"] as? [NSDictionary],arry.count == 2{
            let modes:[Team] = arry.toModels()
            egEgameMatchTeamList = (left:modes.first!,right:modes.last!)
        }
        
    }
    var edid:String?
    var mid:String//比赛ID
    var egameLogo:String//游戏图标
    var matchName:String//比赛名称
    var matchDateTime:Double//比赛时间
    var result:String//比赛结果
    var bo:Int//场数
    var isLive:Bool//是否有滚盘
    var isLiving:Bool//是否滚盘中
    var videourl:String//视频URL
    var liveUrl:String//直播URL
    var updateDateTime:String//更新时间
    var state:MatchState?//比赛状态：1、未开赛 2、正在进行 3、比赛结束 4、取消
    var stateName:String//比赛状态名称：1、未开赛 2、正在进行 3、比赛结束 4、取消
    var betState:Bool//投注状态（0、封盘 1、开盘）
    var betStateName:String//投注状态名称（0、封盘 1、开盘）
    var canCombine:Bool//是否能串关
    var minMoney:Double//最小投注额
    var maxMoney:Double//最大投注额
    var playName:String//玩法名称
    var playSortName:String
    var playCount:Int//玩法数量
    
    var egEgameMatchTeamList:(left:Team,right:Team)?
    
    var playDetail:ECSocket.MPlayChanged.Detail?
}
