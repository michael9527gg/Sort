//
//  MBank.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class MBank: MTranslateProtocol {
    var bid:String?//银行ID
    var name:String?//名称
    var code:String?//代码
    var logoUrl:String?
    
    required init(dict: NSDictionary?) {
        bid = dict?["bid"]
        name = dict?["name"]
        code = dict?["code"]
        logoUrl = dict?["logoUrl"]
    }

}
