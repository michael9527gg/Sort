//
//  MMessage.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MMessage: MTranslateProtocol {
    
    var mid:String?//消息ID
    var sendDate:String?//发送时间
    var title:String?//标题
    var content:String?//内容
    var isRead:Bool?//是否已读
    
    required init(dict: NSDictionary?) {
        mid = dict?["mid"]
        sendDate = dict?["sendDate"]
        title = dict?["title"]
        content = dict?["content"]
        isRead = dict?["isRead"]
    }

}
