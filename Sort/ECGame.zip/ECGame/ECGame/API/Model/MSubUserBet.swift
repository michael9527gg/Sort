//
//  MSubUserBet.swift
//  ECGame
//
//  Created by Michale on 2019/12/26.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MSubUserBet: MUserBet {
    
}
