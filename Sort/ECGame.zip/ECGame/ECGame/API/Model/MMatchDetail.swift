//
//  MMatchDetail.swift
//  ECGame
//
//  Created by Michale on 2019/10/25.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MMatchDetail: MTranslateProtocol {
    required init(dict: NSDictionary?) {
        if let match = dict?["defaultMatchDetails"] as? NSDictionary,
            let lists = dict?["basePlaySortList"] as? [NSDictionary]{
            basePlaySortList = lists.toModels()
            defaultMatchDetails = MDefaultMatch(dict: match)
        }
    }
    
    var defaultMatchDetails:MDefaultMatch?
    var basePlaySortList:[MPlaySort]?
    
}
