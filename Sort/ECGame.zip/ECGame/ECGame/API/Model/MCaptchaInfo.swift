//
//  MCaptchaInfo.swift
//  ECGame
//
//  Created by Michale on 2019/10/14.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MCaptchaInfo: MTranslateProtocol {
    
    required init(dict: NSDictionary?) {
        if let str:String = dict?["image"]{
            image = Data(base64Encoded: str, options: .ignoreUnknownCharacters)
        }
        captchaKey = dict?["captchaKey"] ?? ""
        contentType = dict?["contentType"] ?? ""
    }

    var image:Data? //base64
    var captchaKey:String//": "Atw0MRgZ/kkhM4ysI8TgmdoeHBdSzxg70lyb8GcU6SA=",
    var contentType:String//": "image/jpeg"
}
