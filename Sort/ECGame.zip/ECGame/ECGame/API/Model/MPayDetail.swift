//
//  MTransaction.swift
//  ECGame
//
//  Created by Michale on 2019/10/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class MPayDetail: MTranslateProtocol {
    
    enum PayType:Int {
        case wechat = 1 //微信支付
        case alipay = 2 //支付宝
        case onlineBank = 3 //网银
        case manual = 4 //手工充值
        case forSubUser = 5 //为下级充值
        case fromAgent = 6 //代理商充值
    }
    
    enum State:Int {
        /// 失败
        case failed = 0
        
        /// 成功
        case success = 1
        
        /// 处理中
        case progress = 2
    }
    
    var pdid:String?//充值ID
    var userID:String?//用户
    var payDate:String?//充值日期
    var payType:PayType?//充值类型
    var payTypeName:String?
    var payAccount:String?//账号
    var payNumber:String?//流水号
    var money:Double?//金额
    var formalitiesFees:Double?//手续费
    var description:String?//描述
    var state:State?//状态
    var stateName:String?//状态名称
    
    required init(dict: NSDictionary?) {
        pdid = dict?["pdid"]
        userID = dict?["userID"]
        payDate = dict?["payDate"]
        payType = PayType.init(rawValue:dict?["payType"] ?? -1)
        payTypeName = dict?["payTypeName"]
        payAccount = dict?["payAccount"]
        payNumber = dict?["payNumber"]
        money = dict?["money"]
        formalitiesFees = dict?["formalitiesFees"]
        description = dict?["description"]
        state = State(rawValue: dict?["state"] ?? -1)
        stateName = dict?["stateName"]
    }
    
}

