//
//  News.swift
//  ECGame
//
//  Created by Michale on 2019/10/12.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import Moya

enum News{
    static let provider = ECProvider<News>(manager: ECSessionManager.shared)
    
    case typeList
    case sortList
    case contentList(itid:String, sid:String,nsid:[String], keyword:String, pageIndex:Int, pageSize:Int)
    
    /// 资讯专题
    case specialList(name:String,pageIndex:Int, pageSize:Int)
    
    /// 资讯内容
    case content(cid:String)
}


extension News:ECTargetType{
   
    var baseURL: URL {
        return self.domain.appendingPathComponent("api/News")
    }
    
    var path: String {
        switch self {
        case .typeList:
            return "GetNewsTypeList"
        case .sortList:
            return "GetNewsSortList"
        case .contentList:
            return "GetNewsContentList"
        case .content:
            return "GetNewsContent"
        case .specialList:
            return "GetNewsSpecialList"
        }
    }
    
    var parameters: [String : Any]? {
        switch self {
        case let .contentList(itid, sid, nsid, keyword, pageIndex, pageSize):
            return ["itid": itid,"sid": sid,"nsid": nsid,"keyword": keyword,"pageIndex": pageIndex,"pageSize": pageSize]
        case let .content(cid):
            return ["cid":cid]
        case let .specialList(name, pageIndex, pageSize):
            return ["name":name,"pageIndex":pageIndex,"pageSize":pageSize]
        default:
            break
        }
        return nil
    }
    
    
    func translate<T>(resultData: NSDictionary?) -> T? {
        switch self {
        case .typeList:
            if let dicts = resultData?["newsTypeList"] as? [NSDictionary]{
                let types:[MNewsType] = dicts.toModels()
                return types as? T
            }
        case .sortList:
            if let dicts = resultData?["newsSortList"] as? [NSDictionary]{
                let types:[MNewsSort] = dicts.toModels()
                return types as? T
            }
        case .contentList:
            if let dicts = resultData?["newsContentList"] as? [NSDictionary]{
                let types:[MNewsContent] = dicts.toModels()
                return types as? T
            }
        default:
            break
        }
        
        return nil
    }
    
}
