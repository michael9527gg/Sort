//
//  ECSignature.swift
//  ECGame
//
//  Created by Michale on 2019/11/14.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

private let secretKey =   "d4rHhEcEyYiPng3o47IFiyrfjpkSI3NpuzPH84SfuAA7fNiAqny2e6B0uCqy6OASklYPAQ68J1lTqL3WTSf2gSIknbDnzGYvGeTO4ApiajY0tgnPJ3D1HIq6aAPK3v07"

class ECSignature {

    public class func sign(_ orignal:[String:Any]?) ->[String:Any]{
        var dict = orignal ?? [String:Any]()
        let timestamp:Int = Int(Date().timeIntervalSince1970)
        let random = randomStr()
        dict["timestamp"] = timestamp
        dict["random"] = random
        dict["signature"] = signature(orignal ?? [String:Any](),timestamp,random) ?? ""
        return dict
    }
    
    private class func randomStr() ->String{
        var str = ""
        for i in 0 ..< Int.random(in: 10 ... 20) {
            let s:Bool = i%2 == 0
            let a:Character = s ? "a" : "A"
            let z:Character = s ? "z" : "Z"
            let n = Int.random(in: Int(a.asciiValue!) ... Int(z.asciiValue!))
            str.append(Character(UnicodeScalar(n)!))
        }
        return str
    }
    
    private class func toJson(dict: [String:Any]) ->String?{

//        if #available(iOS 11.0, *) {
//            if let json = try? JSONSerialization.data(withJSONObject: dict, options:.sortedKeys){
//                return String(data: json, encoding: .utf8)
//            }
//        }
        
        func array2Json(_ array:[Any]) ->String{
            var json = [String]()
            for item in array{
                if let str = item as? String{
                    json.append("\"\(str)\"")
                }else if let ay =  item as? [Any]{
                    json.append(array2Json(ay))
                }else if let dict = item as? [String:Any]{
                    json.append(toJson(dict: dict)!)
                }else{
                    json.append("\(item)")
                }
            }
            let returnString = json.joined(separator:",")
            return "[\(returnString)]"
        }

        if(!JSONSerialization.isValidJSONObject(dict)) {
            return nil
        }
        var namedPaird = [String]()
        let sortedKeysAndValues = dict.sorted{$0.0 < $1.0}
        for(key, value) in sortedKeysAndValues {
            if value is [String:Any] {
                namedPaird.append("\"\(key)\":\(toJson(dict: value as! [String:Any]) ?? "")")
            }else if value is [Any] {
                namedPaird.append("\"\(key)\":\(array2Json(value as! [Any]))")
            }else if value is String{
                namedPaird.append("\"\(key)\":\"\(value)\"")
            }else{
                namedPaird.append("\"\(key)\":\(value)")
            }
        }
        let returnString = namedPaird.joined(separator:",")
        
        return "{\(returnString)}"
    }
    
    private class func signature(_ dict:[String:Any],_ timestamp:Int,_ randomStr:String)->String?{
        if let jsonStr = toJson(dict: dict){
            let total = "\(jsonStr)&\(timestamp)&\(randomStr)&\(secretKey)"
            return total.md5
        }
        return nil
    }
}
