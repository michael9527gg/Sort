//
//  AppDelegate.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow? = UIWindow()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window?.frame = UIScreen.main.bounds
        window?.rootViewController = TabBarController()
        window?.makeKeyAndVisible()
        ECSocket.startConnect()
        return true
    }


}

