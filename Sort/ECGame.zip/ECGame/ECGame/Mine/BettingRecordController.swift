//
//  BettingRecordController.swift
//  ECGame
//
//  Created by Michale on 2019/10/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class BettingRecordController: BaseController {
    
    let ctView = BetRecordView()
    let vm = VMBettingRecord()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        navigationType = .color(.notify)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "投注记录"
        setBackButton()
        
        ctView.setSegementIndex(index: 0) //By default
    }
    
    override func loadView() {
        vm.delegate = self
        ctView.delegate = vm
        ctView.collection.csDelegate = vm
        ctView.updateSegement()
        view = ctView
    }
    
}

extension BettingRecordController:VMBettingRecordProtocol{
    func failed(msg: String) {
        
    }
    
    func success() {
        ctView.collection.reloadData()
    }
}
