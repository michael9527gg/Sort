//
//  ResetPwdController.swift
//  ECGame
//
//  Created by Michale on 2019/12/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class ResetPwdController: BaseController {
    let ctView = ResetPwdView()
    let vm = VMResetPwd()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "重置密码"
        setBackButton()
    }
    
    override func routerEvent(_ event: Any) {
        if case let .save(newPwd)? = event as? ResetPwdView.Event{
            let phone = Account.current?.user?.mobile ?? ""
            sendCode(phone: phone) {[weak self] in
                self?.reset(phone:phone, pwd: newPwd)
            }
        }
    }
    
    func sendCode(phone:String,success:@escaping ()->Void) -> Void {
        self.vm.sendMobileCode(mobile:phone) {[weak self] (result) in
            switch result{
            case let .failed(msg):
                self?.ctView.error.text = msg
            case let .notExist(msg):
                self?.ctView.error.text = msg
            case .success:
                success()
            }
        }
    }
    
    func reset(phone:String,pwd:String) -> Void {
        let verify = VerifyPhoneController(phone: phone) {[weak self] (code, failed) in
            self?.vm.reset(newPwd:pwd, code:code, complete: { (result) in
                switch result{
                case .success:
                    self?.resetSuccess()
                case let .failed(msg):
                    failed?(.error(msg))
                }
            })
        }
        navigationController?.pushViewController(verify, animated: true)
    }
    
    func resetSuccess() -> Void {
        let alert = WhiteAlertController(title: "重置密码成功", message: "以后可以使用此密码登陆", buttons:[.default(title:"我知道了", action: {[weak self] in
            self?.navigationController?.popToRootViewController(animated: true)
        })])
        present(alert, animated: true, completion: nil)
    }
    
    override func loadView() {
        view = ctView
    }
}

