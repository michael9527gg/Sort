//
//  BankListController.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class BankListController: BaseController {
    let ctView = BankListView()
    let vm = VMBankList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "绑定银行卡"
        setBackButton()
    }
    
    override func routerEvent(_ event: Any) {
        if case .add? = event as? BankListFooter.Event{
            let add = BindBankController()
            navigationController?.pushViewController(add, animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        vm.userBankList {[weak self] (_) in
            self?.ctView.reloadData()
        }
    }
    
    override func loadView() {
        view = ctView
        ctView.csDelegate = vm
    }
}
