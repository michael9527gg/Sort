//
//  RecommendController.swift
//  ECGame
//
//  Created by Michale on 2019/12/11.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class RecommendController: BaseController {
    let ctView = RecommendView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "推荐好友"
        setBackButton()
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? RecommendView.Event {
        case .some(.friendList):
            let list = RecommendListController()
            navigationController?.pushViewController(list, animated: true)
        default:
            break
        }
    }
    
    override func loadView() {
        view = ctView
        let user = Account.current?.user
        let userId = user?.userID ?? ""
        let url = refererUrl + "#/recommend/" + userId
        ctView.qrCode.image = url.qrCode(size: ctView.qrCodeSize)
        ctView.link.text = url
        ctView.inviteCode.text = userId
        ctView.btn.isHidden = user?.isUion == true
    }
}
