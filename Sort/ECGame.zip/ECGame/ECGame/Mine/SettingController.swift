//
//  SettingController.swift
//  ECGame
//
//  Created by Michale on 2019/10/18.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class SettingController: BaseController {
    let vm = VMBankList()
    
    private let contentView = SettingView()
    private var list:[SettingView.CellType]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "资料设置"
        
        setBackButton()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        vm.userBankList {[weak self] (result) in
            if case let .success(bankList) = result{
                if let first = self?.vm.defaultBank(bankList: bankList),
                    let row2 = self?.list?[2]{
                    if case let .default(title,_, _, didSelect) = row2{
                        self?.list?[2] = .default(title:title, content:self?.vm.hide(cardId: first.cardNumber), modify: "去修改", didSelect: didSelect)
                        self?.contentView.reloadData()
                    }
                }
            }
        }
    }
    
    override func loadView() {
        view = contentView
        list = rows()
        contentView.csDelegate = self
        contentView.reloadData()
    }
    
    func hide(mobile:String) -> String {
        if mobile.count <= 7 {
            return mobile
        }
        var ret = String(mobile.prefix(3)) + " "
        for _ in 0 ..< mobile.count-7 {
            ret.append("*")
        }
        ret += " " + String(mobile.suffix(4))
        return ret
    }
    
    private func rows()->[SettingView.CellType]{
        var array = [SettingView.CellType]()
        array.append(.default(title:"账号设置", content:"个人资料", modify:"去完善", didSelect:{[weak self] in
            let profile = ProfileController()
            profile.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(profile, animated: true)
        }))
        
        let mobile = Account.current?.user?.mobile
        let hasMobile = mobile?.count ?? 0 > 0
        array.append(.default(title:"手机号", content:hasMobile ? hide(mobile: mobile!) : "请绑定手机号", modify:hasMobile ? "去修改" : "未绑定", didSelect: {[weak self] in
            let ctr = hasMobile ? ChangePhoneController() : BindPhoneController()
            self?.navigationController?.pushViewController(ctr, animated: true)
        }))
        array.append(.default(title:"收款方式", content:"请绑定银行卡", modify:"未绑定", didSelect:{[weak self] in
            let bank = BankListController()
            bank.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(bank, animated: true)
        }))
        array.append(.default(title:"安全设置", content:"修改或重置密码", modify:"去修改", didSelect:{[weak self] in
            let modifyPwd = ModifyPwdController()
            modifyPwd.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(modifyPwd, animated: true)
        }))
        return array
    }
}

extension SettingController:SettingViewProtocol{
    func numberOfItems(in section: Int) -> Int {
        return list?.count ?? 0
    }
    
    func cellForItem(at indexPath: IndexPath) -> SettingView.CellType {
        return list![indexPath.row]
    }
}
