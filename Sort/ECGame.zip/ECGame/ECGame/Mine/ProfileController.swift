//
//  ProfileDetailController.swift
//  ECGame
//
//  Created by Michale on 2019/12/9.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class ProfileController: BaseController {
    let contentView = ProfileView()
    let vm = VMProfile()
    let vmMine = VMMine()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "完善个人资料"
        setBackButton()
    }
    
    override func loadView() {
        let user = Account.current?.user
        
        if let realityName = user?.realityName,realityName.count > 0{
            contentView.realName.textField.text = "***\(realityName.last!)"
            contentView.realName.textField.isEnabled = false
            let image = UIImage(named: "warning-circle")
            let btn = UIButton()
            btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
            btn.setBackgroundImage(image, for: .normal)
            btn.frame = CGRect(origin: .zero, size: image?.size ?? .zero)
            contentView.realName.rightView = btn
            contentView.realName.addSubview(btn)
        }
        contentView.nickName.textField.text = user?.nickName
        contentView.email.textField.text = user?.email
        contentView.qq.textField.text = user?.qq
        contentView.address.textField.text = user?.address
        contentView.idNumber.textField.text = user?.idcardNumber
        contentView.sex.sex = user?.sex
        contentView.check()
        view = contentView
        vm.delegate = self
    }
    
    @objc func btnClick()->Void{
        let alert = WhiteAlertController(title:"如需修改真实姓名请联系客服", message:"真实姓名必须如实填写，否则可能导致提款失败", buttons: [.default(title: "好的", action: nil)])
        present(alert, animated: true, completion: nil)
    }
    
    override func routerEvent(_ event: Any) {
        if case .save? = event as? ProfileView.Event{
            vm.update(view: contentView)
        }
    }
    

    func success() -> Void {
        let alert = WhiteAlertController(title:"修改成功", message:"尽量完善您的个人资料，可以提高您的用户体验的呢", buttons: [.default(title: "好的", action: {[weak self] in
            self?.navigationController?.popViewController(animated: true)
        })])
        present(alert, animated: true, completion: nil)
    }
}

extension ProfileController:VMProfileProtocol{
    func updateSuccess() {
        vmMine.getUserInfo()
        success()
    }
    
    func updateFailed(msg: String) {
        print(msg)
    }
}
