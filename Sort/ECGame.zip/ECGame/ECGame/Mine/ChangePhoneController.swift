//
//  ChangePhoneController.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class ChangePhoneController: BaseController {
    let vm = VMLoginBase()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "手机号"
        setBackButton()
    }
    
    private func hidePhone()->String?{
        if let s = Account.current?.user?.mobile ,s.count >= 11{
            return String(s.prefix(3)) + "****" + String(s.suffix(4))
        }
        return nil
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .navigatonBar
        
        let phone = InputRowView()
        phone.normalTitleColor = .disabled
        phone.normalLineColor = .line
        phone.textField.text = hidePhone()
        phone.textField.textColor = .marchName
        phone.textField.font = UIFont(name: "PingFangSC-Semibold", size:18.scale)
        phone.textField.isEnabled = false
        phone.updateState = {(text)  in
            return .default("已绑定的手机号")
        }
        view.addSubview(phone)
        phone.snp.makeConstraints { (make) in
            let leading  = 16.scale
            make.leading.equalToSuperview().offset(leading)
            make.centerX.equalToSuperview()
            make.top.equalTo(view.snp.topMargin).offset(20.scale)
        }
        
        let btn = UIButton()
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 6.scale
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size:16.scale)
        btn.setTitle("更换手机号", for: .normal)
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.setTitleColor(.white, for: .normal)
        btn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
        view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(15.scale)
            make.centerX.equalToSuperview()
            make.height.equalTo(52.scale)
            make.top.equalTo(phone.snp.bottom).offset(30.scale)
        }
        
       
        let note = UILabel()
        note.backgroundColor = .clear
        note.textColor = .disabled
        note.font = UIFont(name: "PingFangSC-Regular", size:13.scale)
        note.text = "一个手机号只能作为一个账号的登录号"
        view.addSubview(note)
        note.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(btn.snp.bottom).offset(15.scale)
        }
    }
    
    @objc func btnClick()->Void{
        let mobile = Account.current?.user?.mobile ?? ""
        let alert = WhiteAlertController(title:"确认手机号", message: "我们将发送验证码短信到您绑定的号码 +86 \(mobile)", buttons: [.default(title: "取消", action:nil),.hilight(title: "好的", action: {[weak self] in
            self?.vm.sendMobileCode(mobile:mobile, complete: { (result) in
                switch result{
                case .success:
                    self?.verifyOldPhone(mobile: mobile)
                default:
                    break
                }
            })
        })])
        present(alert, animated: true, completion: nil)
    }
    
    func verifyOldPhone(mobile:String) -> Void {
        let code = VerifyPhoneController(phone:mobile, done: {[weak self] (code, failed) in
            self?.vm.verify(mobile:mobile, code: code, complete: { (r) in
                switch r{
                case .success:
                    self?.navigationController?.popViewController(animated: true)
                    self?.bindNewPhone()
                case let .failed(msg):
                    failed?(.error(msg))
                }
            })
        })
        self.navigationController?.pushViewController(code, animated: true)
    }
    
    func bindNewPhone() -> Void {
        let new = BindPhoneController()
        navigationController?.pushViewController(new, animated:true)
    }
}

