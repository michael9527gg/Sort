//
//  MessageDetailController.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class MessageDetailController: BaseController {
    var vm:VMMessageDetail!
    let contentView = MessageDetailView()
    
    convenience init(id:String) {
        self.init(nibName:nil,bundle:nil)
        vm = VMMessageDetail(id: id)
        vm.delegate = self
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的消息"
        setBackButton()
    }
    
    override func loadView() {
        view = contentView
        vm.messageDetail()
    }
}

extension MessageDetailController:VMMessageDetailProtocol{
    func success(title: String?, content: String?, date: String?) {
        contentView.set(title: title, detail: content, time: date)
    }
}
