//
//  VMPickerBank.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMPickerUserBankProtocol:class {
    func didSelect(bank:MUserBank) -> Void
}

class VMPickerUserBank: VMBase {
    
    enum Result {
        case success([MUserBank])
        case noBank
        case failed(String)
    }
    
    weak var delegate:VMPickerUserBankProtocol?
    
    var bankList:[MUserBank]?
    
    func defaultBank(bankList:[MUserBank]?) -> MUserBank? {
        guard let l = bankList else{
            return nil
        }
        for item in l {
            if item.isDefault == true{
                return item
            }
        }
        return l.first
    }
    
    func userBankList(complete:((Result)->Void)?) -> Void {
        Member.provider.request(.userBankList(userID:Account.current?.token?.userID ?? "", pageIndex: 0, pageSize: 0)) { (_ result:ECResult<[MUserBank]>) in
            switch result{
            case let .success(list):
                self.bankList = list
                if list.count > 0{
                    complete?(.success(list))
                }else{
                    complete?(.noBank)
                }
            case let .failed(_, msg):
                complete?(.failed(msg))
            case .unreachable:
                complete?(.failed("网络无法连接"))
            default:
                complete?(.failed("其他错误"))
            }
        }
    }
}

extension VMPickerUserBank:PickerUserBankViewProtocol{
    func didSelect(at indexPath: IndexPath) {
        delegate?.didSelect(bank: bankList![indexPath.row])
    }
    
    func numberOfItems(in section: Int) -> Int {
        return bankList?.count ?? 0
    }
    
    func config(cell: PickerUserBankCell, indexPath: IndexPath) {
        let m = bankList![indexPath.row]
        cell.name.text = m.bankName
        cell.icon.setImage(url:m.logoUrl, placeholder: UIImage(named: "img_nologo"))
        var str:String? = nil
        if let number = m.cardNumber,number.count > 4{
           str = "尾号 " + String(number.suffix(4))
        }
        
        cell.subTitle.text = str
    }
}
