//
//  VMProfile.swift
//  ECGame
//
//  Created by Michale on 2019/12/22.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMProfileProtocol:class {
    func updateSuccess() -> Void
    func updateFailed(msg:String) -> Void
}

class VMProfile: VMBase {
    weak var delegate:VMProfileProtocol?
    
    func update(view:ProfileView) -> Void {
        let realityName:String? = view.realName.textField.isEnabled ? view.realName.textField.text : nil
        
        var tf:UITextField = view.nickName.textField
        let nickName = (tf.text?.count ?? 0) > 0 ? tf.text! : nil
        
        tf = view.birthDay.textField
        let birthDay = (tf.text?.count ?? 0) > 0 ? tf.text! : nil
        
        tf = view.idNumber.textField
        let id = (tf.text?.count ?? 0) > 0 ? tf.text! : nil
        
        tf = view.address.textField
        let address = (tf.text?.count ?? 0) > 0 ? tf.text! : nil
        
        tf = view.qq.textField
        let qq = (tf.text?.count ?? 0) > 0 ? tf.text! : nil
        
        tf = view.email.textField
        let email = (tf.text?.count ?? 0) > 0 ? tf.text! : nil
        
        var sex:Bool? = nil
        switch view.sex.sex {
        case .some(.boy):
            sex = true
        case .some(.girl):
            sex = false
        default:
            sex = nil
        }
        
        
        Member.provider.request(.updateUserInfo(realityName:realityName, nickName:nickName, sex:sex, birthDay:birthDay, idcardNumber:id, address:address, qq:qq, email:email, userID:Account.current?.token?.userID ?? "")) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate://success
                self.delegate?.updateSuccess()
            case let .failed(_, msg):
                self.delegate?.updateFailed(msg: msg)
            case .unreachable:
                self.delegate?.updateFailed(msg: "网络无法连接")
            default:
                self.delegate?.updateFailed(msg: "其他错误")
            }
        }
    }
}
