//
//  VMBankList.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit


class VMBankList: VMPickerUserBank {
    
    func hide(cardId:String?) ->String?{
        if let id = cardId,id.count > 7{
            var prex = String(id.prefix(4))
            var count = id.count / 4
            var less = id.count % 4
            if less == 0{
                count -= 1
                less = 4
            }
            for _ in 0 ..< (count-1){
                prex.append(" ****")
            }
        
            prex += " " + String(id.suffix(less))
            return prex
        }
        return nil
    }
}


extension VMBankList:BankListViewProtocol{
    func config(cell: BankListCell, indexPath: IndexPath) {
        let bank = bankList![indexPath.row]
        cell.name.text = bank.bankName
        cell.icon.setImage(url:bank.logoUrl, placeholder: UIImage(named: "img_nologo"))
        cell.idCard.text = hide(cardId: bank.cardNumber)
    }
}
