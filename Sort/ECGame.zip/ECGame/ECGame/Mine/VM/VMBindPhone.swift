//
//  VMBindPhone.swift
//  ECGame
//
//  Created by Michale on 2019/12/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class VMBindPhone: VMLoginBase {
    enum Result {
        case success
        case exist(String)
        case wrongCode(String)
        case failed(String)
    }
    
    func bind(mobile:String,code:String,complete:((Result)->Void)?) -> Void {
        Member.provider.request(.bindMobile(mobile:mobile, authCode: code, userID: Account.current?.token?.userID ?? "")) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate:
                complete?(.success)
            case let .failed(code, msg):
                switch code{
                case 5:
                    complete?(.exist(msg))
                default:
                    complete?(.failed(msg))
                }
            default:
                break
            }
        }
    }
}
