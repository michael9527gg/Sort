//
//  VMMessageDetail.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMMessageDetailProtocol:class {
    func success(title:String?,content:String?,date:String?) -> Void
}

class VMMessageDetail: VMBase {
    private var id:String?
    weak var delegate:VMMessageDetailProtocol?
    
    convenience init(id:String) {
        self.init()
        self.id = id
    }
    
    func messageDetail() -> Void {
        Member.provider.request(.messageInfo(mid:id ?? "", userID: Account.current?.token?.userID ?? "")) { (_ result:ECResult<MMessage>) in
            if case let .success(message) = result{
                self.delegate?.success(title:message.title, content: message.content, date: message.sendDate)
            }
        }
    }
    
    override init() {
        super.init()
    }
}
