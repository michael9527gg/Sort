//
//  VMUserInfo.swift
//  ECGame
//
//  Created by Michale on 2020/1/5.
//  Copyright © 2020 EC. All rights reserved.
//

import Foundation


class VMUserInfo: VMBase {
    enum Result {
        case success(MUser)
        case failed(String)
    }
    
    func getUserInfo(_ completion:@escaping (_ result:Result)->Void) -> Void {
        guard let userId = Account.current?.token?.userID else{
            return
        }
        Member.provider.request(.userInfo(userID:userId, connectionID:ECSocket.socket?.connection?.connectionId ?? "")) { (result:ECResult<MUser>) in
                switch result{
                case let .success(user):
                    Account.current?.user = user
                    completion(.success(user))
                case .unreachable:
                    completion(.failed("网络无法连接"))
                case let .failed(_, msg):
                    completion(.failed(msg))
                default:
                    completion(.failed("其他错误"))
                }
        }
    }
}
