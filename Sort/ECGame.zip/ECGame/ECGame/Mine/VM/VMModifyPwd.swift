//
//  VMModifyPwd.swift
//  ECGame
//
//  Created by Michale on 2019/10/18.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMModifyPwdProtocol:class {
    func success() -> Void
    
    func oldPwdWrong(msg:String) -> Void
}

class VMModifyPwd: VMBase {
    
    weak var delegate:VMModifyPwdProtocol?
    
    func modifyPwd(oldPwd:String,newPwd:String) -> Void {
        Member.provider.request(.modifyPwd(userID:Account.current?.token?.userID ?? "", oldPwd: oldPwd.md5.md5, newPwd: newPwd.md5.md5)) { (_ result:ECResult<MAccessToken>) in
            switch result{
            case .untranslate:/// success
                self.delegate?.success()
            case let .failed(code, msg):
                if code == 4{//密码不正确
                    self.delegate?.oldPwdWrong(msg:msg)
                }
            default:
                break
            }
        }
        
    }
}
