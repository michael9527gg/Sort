//
//  VMAddBank.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMBindBankProtocol:class {
    func bindSuccess() -> Void
}

class VMBindBank: VMBase {
    
    weak var delegate:VMBindBankProtocol?
    
    func bind(bank:String,cardNumber:String,subbranch:String) -> Void {
        Member.provider.request(.bindBank(bankID: bank, subbranch: subbranch, cardNumber: cardNumber, userID: Account.current?.token?.userID ?? "")) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate://success
                self.delegate?.bindSuccess()
            default:
                break
            }
        }
    }
    
}
