//
//  VMResetPwd.swift
//  ECGame
//
//  Created by Michale on 2019/12/22.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class VMResetPwd: VMLoginBase {
    enum Result {
        case success
        case failed(String)
    }
    func reset(newPwd:String,code:String,complete:((Result)->Void)?) -> Void {
        Member.provider.request(.resetPwd(mobile:Account.current?.user?.mobile ?? "", authCode:code, newPassword: newPwd.md5.md5, userID:Account.current?.user?.userID ?? "")) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate:
                complete?(.success)
            case let .failed(_, msg):
                complete?(.failed(msg))
            case .unreachable:
                complete?(.failed("网络无法连接"))
            default:
                complete?(.failed("其他错误"))
            }
        }
    }
}
