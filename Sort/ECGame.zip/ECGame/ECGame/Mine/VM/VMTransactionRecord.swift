//
//  VMTransactionRecord.swift
//  ECGame
//
//  Created by Michale on 2019/10/20.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

extension MReturnDetail:TransactionReturnCellProtocol{
    var orderId: String? {
        return rid
    }
    
    var nameText: String? {
        return "返佣比例" + (scale ?? "")
    }
    
    var priceText: String? {
        return  String(format: "¥ %.2f",money ?? 0)
    }
    
    var betMoneyText: String? {
        return String(format: "投注总额 ¥%.2f",betSum ?? 0)
    }
    
    var betCountText: String? {
        return "投注笔数 \(betNumber ?? 0)笔"
    }
    
    var betTimeText: String? {
        return "投注时间 " + (returnDay ?? "")
    }
    
    var sendTimeText: String? {
        return "派发时间 " + (returnDate ?? "")
    }
}

extension MPayDetail:TransactionDefaultCellProtocol{
    var orderId: String? {
        return pdid
    }
    
    var nameText: String? {
        return payTypeName
    }
    
    var priceText: String? {
        return String(format: "¥ %.2f",money ?? 0)
    }
    
    var timeText: String? {
        return payDate
    }
    
    var stateText: (text: String?, textColor: UIColor?) {
        let ck:UIColor = (state != .some(.failed)) ? .marchName : .down
        return (text:stateName, textColor: ck)
    }
}

extension MDistillDetail:TransactionDefaultCellProtocol{
    var orderId: String? {
        return ddid
    }
    
    var nameText: String? {
        return stateName
    }
    
    var priceText: String? {
        return String(format: "¥ %.2f",money)
    }
    
    var timeText: String? {
        return distillDate
    }
    
    var stateText: (text: String?, textColor: UIColor?) {
        let ck:UIColor = .marchName
        return (text:description, textColor:ck)
    }
}

extension MPromotionDetail:TransactionDefaultCellProtocol{
    var orderId: String? {
        return pid
    }
    
    var nameText: String? {
        return title
    }
    
    var priceText: String? {
        return String(format: "¥ %.2f",money ?? 0)
    }
    
    var timeText: String? {
        return distillDate
    }
    
    var stateText: (text: String?, textColor: UIColor?) {
        let ck:UIColor = (state == true) ? .marchName : .down
        return (text:stateName, textColor: ck)
    }
}

class VMTransactionRecord: VMBase {
    
   fileprivate var dataSource: [TransactionCollectionView.CellType]?
    
    @discardableResult
    func getDetailList<T>(view:TransactionRecordView) -> T? {
        guard let userId = Account.current?.token?.userID else{
            return nil
        }
        
        var target:Member
        
        switch T.self {
        case is [MPayDetail].Type:
            target = .payDetailsList(startDate: nil, endDate: nil, state: nil, pageIndex: 0, pageSize: 0, userID:userId)
        case is [MPromotionDetail].Type:
            target = .promotionDetailsList(startDate: nil, endDate: nil, state: nil, pageIndex: 0, pageSize: 0, userID:userId)
        case is [MDistillDetail].Type:
            target = .distillDetailsList(startDate: nil, endDate: nil, state: nil, pageIndex: 0, pageSize: 0, userID:userId)
        case is [MReturnDetail].Type:
            target = .returnDetailsList(startDate: nil, endDate: nil, state: nil, pageIndex: 0, pageSize: 0, userID:userId)
        default:
            return nil
        }
        
        Member.provider.request(target) { (_ result:ECResult<T>) in
            switch result{
            case let .success(array):
                if let list  = array as? [TransactionReturnCellProtocol]{
                    self.dataSource = []
                    for item in list{
                        self.dataSource?.append(.return(item))
                    }
                }else if let list = array as? [TransactionDefaultCellProtocol]{
                    self.dataSource = []
                    for item in list{
                        self.dataSource?.append(.default(item))
                    }
                }
                view.collection.reloadData()
            default:
                break
            }
        }
        return nil
    }
    
}


extension VMTransactionRecord:TransactionRecordProtocol{
    var segementItems: [String] {
        return ["充值记录","提款记录","优惠记录","返水记录"]
    }
    
    func segementValueChanged(index: Int, view: TransactionRecordView) {
        dataSource = nil
        view.collection.reloadData()
        
        switch index {
        case 0:
            let _:[MPayDetail]? = getDetailList(view: view)
        case 1:
            let _:[MDistillDetail]? = getDetailList(view: view)
        case 2:
            let _:[MPromotionDetail]? = getDetailList(view: view)
        case 3:
            let _:[MReturnDetail]? = getDetailList(view: view)
        default:
            break
        }
    }
}


extension VMTransactionRecord:TransactionCollectionViewProtocol{
    func cellForItem(at indexPath: IndexPath) -> TransactionCollectionView.CellType {
        return dataSource![indexPath.row]
    }
    
    func numberOfItems(section: Int) -> Int {
        return dataSource?.count ?? 0
    }
}
