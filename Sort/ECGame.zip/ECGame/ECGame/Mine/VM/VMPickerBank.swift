//
//  VMPickerBank.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMPickerBankProtocol:class {
    func didSelect(bank:MBank) -> Void
}

class VMPickerBank: VMBase {
    weak var delegate:VMPickerBankProtocol?
    var bankList:[MBank]?
    
    func bankList(complete:((_ success:Bool)->Void)?) -> Void {
        BaseInfo.provider.request(.bankList(pageIndex: 0, pageSize: 0)) { (_ result:ECResult<[MBank]>) in
            switch result{
            case let .success(bankList):
                self.bankList = bankList
                complete?(true)
            default:
                complete?(false)
            }
        }
    }
}

extension VMPickerBank:PickerBankViewProtocol{
    func numberOfItems(in section: Int) -> Int {
        return bankList?.count ?? 0
    }
    
    func config(cell: PickerBankCell, indexPath: IndexPath) {
        let m = bankList![indexPath.row]
        cell.name.text = m.name
        cell.icon.setImage(url:m.logoUrl, placeholder: UIImage(named: "img_nologo"))
    }
    
    func didSelect(at indexPath: IndexPath) {
        delegate?.didSelect(bank: bankList![indexPath.row])
    }
}
