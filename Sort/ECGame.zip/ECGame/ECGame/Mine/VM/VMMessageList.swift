//
//  VMMessageList.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMMessageListProtocol:class {
    func success() -> Void
    
    func didSelect(message id:String) -> Void
}

extension MMessage:MessageListCellProtocol{
    var id: String? {
        return mid
    }
    
    var readStatus: Bool {
        get {
            return isRead ?? false
        }
        set {
            isRead = newValue
        }
    }
    
    var titleText: String? {
        return title
    }

    var timeText: String? {
        return sendDate
    }

    var detailText: String? {
        return content
    }
}

class VMMessageList: VMBase {
    weak var delegate:VMMessageListProtocol?
    private var dataSource:[MessageListView.CellType]?
    
    func messageList() -> Void {
        Member.provider.request(.messageList(pageIndex: 0, pageSize: 0, userID: Account.current?.token?.userID ?? "")) { (_ result:ECResult<[MMessage]>) in
            if case let .success(list) = result{
                self.dataSource = []
                for item in list{
                    self.dataSource?.append(.default(item))
                }
                self.delegate?.success()
            }
        }
    }
}

extension VMMessageList:MessageListViewProtocol{
    func didSelectItem(at indexPath: IndexPath) {
        if let m = dataSource?[indexPath.row],case let .default(item) = m{
            var new = item
            new?.readStatus = true
            dataSource?[indexPath.row] = .default(new)
            delegate?.didSelect(message:item?.id ?? "")
        }
    }
    
    func numberOfItems(in section: Int) -> Int {
        return dataSource?.count ?? 0
    }
    
    func cellForItem(at indexPath: IndexPath) -> MessageListView.CellType {
        return dataSource![indexPath.row]
    }
}
