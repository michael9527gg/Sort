//
//  VMBettingRecord.swift
//  ECGame
//
//  Created by Michale on 2019/11/8.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

extension Array where Element == MUserBet{
    func translate(openState:Bool) -> [BetRecordCollection.Section]{
        var array:[BetRecordCollection.Section] = []
        for item in self{
            let s1 = BetRecordCollection.Section()
            s1.header = BetRecordCollection.Section.Header()
            s1.header?.title = item.betTypeName
            s1.header?.orderId = item.bid
            s1.header?.userId = item.userID
            s1.cells = []
            if let deatil = item.betsDetails{
                for (i,d) in deatil.enumerated(){
                    let c = BetRecordCollection.Section.Cell()
                    c.oddName = String(format:"\(d.oddsName ?? "")  @%.2f",d.odds ?? 0)
                    c.teamLogo = d.egameLogo
                    c.teamName = d.team
                    c.playName = (d.playSortName ?? "") + " • " + (d.playName ?? "")
                    c.time = "开赛时间 " + (d.matchDateTime ?? "")
                    if i == 0,item.betState == .canceld{
                        c.stateImage = "cancel_order"
                    }else{
                        c.stateImage = nil
                    }
                    
                    s1.cells?.append(c)
                }
            }
            s1.footer = BetRecordCollection.Section.Footer()
            let dck:UIColor = .note
            let dFont = UIFont(name: "PingFangSC-Regular", size: 12.scale)!
            let betMoney = String(format:"下注金额 ¥%.2f",item.money ?? 0)
            var attr = NSMutableAttributedString(string:betMoney, attributes: [NSAttributedString.Key.font :dFont,NSAttributedString.Key.foregroundColor:UIColor.tintColor])
            attr.addAttributes([NSAttributedString.Key.foregroundColor : dck], range:NSRange(location: 0, length: 4))
            s1.footer?.betMoney = attr
            
            s1.footer?.state = openState ? (((item.winMoney ?? 0) > 0) ? "icon_odds_win" : "icon_odds_lose") : nil
            let winMoney = openState ? String(format:"总盈利 ¥%.2f",item.winMoney ?? 0) : String(format:"预计可赢 ¥%.2f",item.expectedWinMoney ?? 0)
            attr = NSMutableAttributedString(string:winMoney, attributes: [NSAttributedString.Key.font :dFont,NSAttributedString.Key.foregroundColor:UIColor.white])
            attr.addAttributes([NSAttributedString.Key.foregroundColor : dck], range:NSRange(location: 0, length: 4))
            s1.footer?.winMoney = attr
            
            let totalOdd = String(format:"总赔率 %.2f",item.oddsTotal ?? 0)
            attr = NSMutableAttributedString(string:totalOdd, attributes: [NSAttributedString.Key.font :UIFont(name: "PingFangSC-Medium", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.odds])
            attr.addAttributes([NSAttributedString.Key.foregroundColor : dck,NSAttributedString.Key.font:dFont], range:NSRange(location: 0, length: 3))
            s1.footer?.odds = attr
            s1.footer?.time = "下注时间 \(item.betDateTime ?? "")"
            array.append(s1)
        }
        return array
    }
}

protocol VMBettingRecordProtocol:class {
    func success() -> Void
    func failed(msg:String) -> Void
}

class VMBettingRecord: VMBase {
    
    weak var delegate:VMBettingRecordProtocol?
    var section:[BetRecordCollection.Section]?
    
    func getBetsList(openState:Bool) -> Void {
        Member.provider.request(.betsList(startDate: nil, endDate: nil, betState: nil, openState:openState, pageIndex: nil, pageSize:100, userID:Account.current?.token?.userID ?? "")) { (_ result:ECResult<[MUserBet]>) in
            switch result{
            case let .success(list):
                self.section = list.translate(openState: openState)
                self.delegate?.success()
            case let .failed(_, msg):
                self.delegate?.failed(msg: msg)
            case .unreachable:
                self.delegate?.failed(msg: "网络无法连接")
            default:
                self.delegate?.failed(msg: "其他错误")
            }
        }
    }
}

extension VMBettingRecord:BetRecordViewProtocol{
    var segementItems: [String] {
        return ["未结算","已结算"]
    }
    
    func segementValueChanged(index: Int, view: BetRecordView) {
        section = nil
        view.collection.reloadData()
        getBetsList(openState: Bool(truncating: NSNumber(integerLiteral: index)))
    }
}

extension VMBettingRecord:BetRecordCollectionProtocol{
    func numberOfSection() -> Int {
        return section?.count ?? 0
    }
    
    func section(at section: Int) -> BetRecordCollection.Section {
        return self.section![section]
    }
}
