//
//  VMMine.swift
//  ECGame
//
//  Created by Michale on 2019/10/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import SnapKit
import UIKit

protocol VMMineProtocol:class {
    func success(user:MUser) -> Void
    
    func failed() -> Void
}

class VMMine: VMUserInfo {
    weak var delegate:VMMineProtocol?
    weak var navigationController:UINavigationController?
    
    func attr(user:MUser?) -> (balance:NSAttributedString?,lottery:NSAttributedString?)? {
        
        let ck:UIColor = .note
        
        let balance = NSMutableAttributedString(string:String(format: "余额 ¥ %.2f",user?.balance ?? 0), attributes: [NSAttributedString.Key.font :UIFont(name: "DINAlternate-Bold", size:26.scale)!,NSAttributedString.Key.foregroundColor:UIColor.white])
        balance.addAttributes([NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size:12.scale)!,NSAttributedString.Key.foregroundColor:ck], range: NSRange(location: 0, length: 2))
        let giftBalance = String(format: "彩金 ¥ %.2f      ",user?.giftBalance ?? 0)
        let freze = String(format: "冻结金额 ¥ %.2f",user?.freeze ?? 0)
        let lottery = NSMutableAttributedString(string:giftBalance + freze, attributes: [NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size:12.scale)!,NSAttributedString.Key.foregroundColor:ck])
        lottery.addAttributes([NSAttributedString.Key.font:UIFont(name: "DINAlternate-Bold", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.tintColor], range: NSRange(location:3, length:giftBalance.count - 3))
        lottery.addAttributes([NSAttributedString.Key.font:UIFont(name: "DINAlternate-Bold", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.marchName], range: NSRange(location:giftBalance.count + 4, length:freze.count - 4))
        return (balance:balance,lottery:lottery)
    }
   
    
    func cells(for user: MUser?) -> [MineView.CellType]? {
        var rows:[MineView.CellType] = []
        let h = attr(user:user)
        rows.append(.header(balance:h?.balance, lottery:h?.lottery))
        rows.append(.titleDes(img:"icon_sheet", title:"交易记录", des:"存款记录、提款记录、优惠记录、反水记录", didSelect: {[weak self] in
            let transaction = TransactionRecordController()
            transaction.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(transaction, animated: true)
        }))
        rows.append(.centerTitle(img: "icon_bet", title: "投注记录", didSelect: {[weak self] in
            let bet = BettingRecordController()
            bet.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(bet, animated: true)
        }))
        rows.append(.centerTitle(img: "icon_letter", title: "我的消息", didSelect: {[weak self] in
            let msg = MessageListController()
            msg.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(msg, animated: true)
        }))
        rows.append(.centerTitle(img: "icon_recommend", title: "我的推荐", didSelect: {[weak self] in
            let recommend = RecommendController()
            recommend.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(recommend, animated: true)
            
        }))
        rows.append(.centerTitle(img: "icon_partner", title: "合营伙伴", didSelect: {
            
        }))
        if Account.current?.user?.isUion == true{
            rows.append(.centerTitle(img:"icon_partner_big", title: "代理商中心", didSelect: {[weak self] in
                let agent = AgentCenterController()
                agent.hidesBottomBarWhenPushed = true
                self?.navigationController?.pushViewController(agent, animated: true)
            }))
        }
        rows.append(.titleDes(img:"Icon_setting", title:"资料设置",des:"个人资料、绑定手机、银行卡管理", didSelect: {[weak self] in
            let set = SettingController()
            set.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(set, animated: true)
        }))
        rows.append(.centerTitle(img: "icon_download", title: "下载APP", didSelect: {
            
        }))
        rows.append(.footer)
        return rows
    }
    
    func getUserInfo() -> Void {
        getUserInfo { (result) in
            switch result{
            case let .success(m):
                self.delegate?.success(user: m)
            default:
                self.delegate?.failed()
            }
        }
    }
    
    func logout(_ completion:@escaping (_ success:Bool)->Void) -> Void {
        Member.provider.request(.logout) { (_ result: ECResult<Any>) in
            if case .untranslate(_) = result{
                completion(true)
            }else{
                completion(false)
            }
        }
    }
}


