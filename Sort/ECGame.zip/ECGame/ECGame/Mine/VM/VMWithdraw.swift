//
//  VMWithdraw.swift
//  ECGame
//
//  Created by Michale on 2019/12/22.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class VMWithdraw: VMBase {
    enum Result {
        case success
        case failed(String)
    }
    func withdraw(money:String,ubid:String,complete:((Result)->Void)?) -> Void {
        Member.provider.request(.distill(ubid:ubid, money:money, userID: Account.current?.token?.userID ?? "")) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate:
                complete?(.success)
            case let .failed(_, msg):
                complete?(.failed(msg))
            case .unreachable:
                complete?(.failed("网络无法连接"))
            default:
                complete?(.failed("其他错误"))
            }
        }
    }
}
