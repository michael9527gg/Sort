//
//  WithdrawSuccessController.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class WithdrawSuccessController: BaseController {
    typealias Complete = ()->Void
    fileprivate var finish:Complete?
    fileprivate var record:Complete?
    fileprivate var money:String?
    
    class func show(ctr:UIViewController,money:String,
                     finish:Complete?,record:Complete?) -> Void {
        let success = WithdrawSuccessController()
        success.finish = finish
        success.record = record
        success.money = money
        ctr.present(success, animated: true, completion: nil)
    }
    override func loadView() {
        super.loadView()
        view.backgroundColor = .notify
        
        let icon = UIImageView()
        icon.backgroundColor = .clear
        icon.image = UIImage(named: "img_succeed")
        view.addSubview(icon)
        icon.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(100.scale)
        }
        
        let title = UILabel()
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Medium", size:17.scale)
        title.text = "提现请求成功"
        view.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(icon.snp.bottom).offset(30.scale)
        }
        
        let price = UILabel()
        price.backgroundColor = .clear
        price.textColor = .note
        price.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        price.text = "提现金额 ¥\(money ?? "")"
        view.addSubview(price)
        price.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(20.scale)
        }
        
        let btn = UIButton()
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 26.scale
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size:16.scale)
        btn.setTitle("完成", for: .normal)
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.setTitleColor(.white, for: .normal)
        btn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
        view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(37.scale)
            make.centerX.equalToSuperview()
            make.height.equalTo(52.scale)
            make.top.equalTo(price.snp.bottom).offset(60.scale)
        }
        
        let note = UILabel()
        note.backgroundColor = .clear
        note.textColor = .note
        note.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        note.text = "需稍等片刻，成功后会收到系统通知"
        view.addSubview(note)
        note.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(btn.snp.bottom).offset(12.scale)
        }
        
//        let recordBtn = UIButton()
//        recordBtn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
//        recordBtn.setTitle("查询交易记录", for: .normal)
//        recordBtn.addTarget(self, action: #selector(recordClick), for: .touchUpInside)
//        recordBtn.setTitleColor(.loginBtn, for: .normal)
//        view.addSubview(recordBtn)
//        recordBtn.snp.makeConstraints { (make) in
//            make.centerX.equalToSuperview()
//            make.bottom.equalTo(view.snp.bottomMargin).offset(-25.scale)
//        }
    }
    
    @objc func recordClick()->Void{
        dismiss(animated:true) {
            self.record?()
        }
    }
    
    @objc func btnClick()->Void{
        dismiss(animated:true) {
            self.finish?()
        }
    }
}
