//
//  MineController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit



class MineViewController: BaseController {
    private var rows:[MineView.CellType]!
    let leftTitle = MineTitleView()
    let ctView = MineView()
    let vm = VMMine()
    
    init() {
        super.init(nibName: nil, bundle: nil)
        rows = vm.cells(for: Account.current?.user)
        ctView.reloadData()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
    }
    
    func setupNavigation() -> Void {
        let user = Account.current?.user
        leftTitle.nickName.text = user?.userID //?? (user?.mobile ?? "新用户")
        leftTitle.realName.text = user?.realityName
        leftTitle.vip.image = user?.isUion == true ? UIImage(named: "icon_partner-1") : nil
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView:leftTitle)
    }
    
    override func loadView() {
        view = ctView
        ctView.csDelegate = self
        vm.delegate = self
        vm.navigationController = navigationController
        ctView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        vm.getUserInfo()
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? MineHeaderCell.Event {
        case .charge?:
            print("=--charge")
        case .withdraw?:
            let withdraw = WithdrawController()
            withdraw.hidesBottomBarWhenPushed = true
            navigationController?.pushViewController(withdraw, animated:true)
        default:
            break
        }
        
        if case .exit? = event as? MineFooterCell.Event {
            vm.logout { (success) in
                Account.clear()
                TabBarController.current?.selectedIndex = 0
            }
        }
    }
}

extension MineViewController:MineViewProtocol{
    func numberOfItems() -> Int {
        return rows.count
    }
    
    func cellForItem(at indexPath: IndexPath) -> MineView.CellType {
        return rows[indexPath.row]
    }
}

extension MineViewController:VMMineProtocol{
    func success(user: MUser) {
        rows = vm.cells(for: user)
        ctView.reloadData()
        setupNavigation()
    }
    
    func failed() {
    }
}
