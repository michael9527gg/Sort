//
//  TransactionRecordController.swift
//  ECGame
//
//  Created by Michale on 2019/10/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class TransactionRecordController: BaseController {
    
    private let vm = VMTransactionRecord()
    let ctView = TransactionRecordView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "交易记录"
        setBackButton()
        ctView.setSegementIndex(index: 0) //By default
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func loadView() {
        ctView.delegate = vm
        ctView.collection.csDelegate = vm
        ctView.updateSegement()
        view = ctView
    }
    
}
