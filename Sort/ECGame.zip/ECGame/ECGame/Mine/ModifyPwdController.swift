//
//  ModifyPwdController.swift
//  ECGame
//
//  Created by Michale on 2019/10/18.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class ModifyPwdController: BaseController {
    let mainView = ModifyPwdView()
    let vm = VMModifyPwd()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "修改密码"
        setNavigation()
    }
    
    func setNavigation() -> Void {
        setBackButton()
        
        let btn = UIButton()
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(rightClick), for: .touchUpInside)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        btn.setTitle("重置密码", for: .normal)
        btn.setTitleColor(.white, for:.normal)
        let right = UIBarButtonItem(customView:btn)
        navigationItem.rightBarButtonItem = right
    }
    
    @objc func rightClick() ->Void{
        let mobile = Account.current?.user?.mobile
        let hasMobile = (mobile?.count ?? 0) > 0
        if hasMobile {
            let reset = ResetPwdController()
            navigationController?.pushViewController(reset, animated: true)
        }else{
            let alert = WhiteAlertController(title: "您目前没有绑定手机号", message: "必须绑定手机号才可以重置密码", buttons:[.default(title:"取消", action:nil),.hilight(title: "绑定手机号", action: {[weak self] in
                self?.navigationController?.popViewController(animated: true)
            })])
            present(alert, animated: true, completion: nil)
        }
    }
    
    override func loadView() {
        view = mainView
        vm.delegate = self
    }
    
    override func routerEvent(_ event: Any) {
        if case let .save(oldPwd,newPwd)? = event as? ModifyPwdView.Event{
            vm.modifyPwd(oldPwd: oldPwd, newPwd: newPwd)
        }
    }
}

extension ModifyPwdController:VMModifyPwdProtocol{
    func oldPwdWrong(msg: String) {
        mainView.oldPwd.currentState = .error(msg)
    }
    func success() {
        let alert = WhiteAlertController(title: "密码修改成功", message:"下次请使用新密码登陆", buttons:[.default(title:"我知道了", action: {[weak self] in
            self?.navigationController?.popViewController(animated: true)
        })])
        present(alert, animated: true, completion: nil)
    }
}
