//
//  RecommendListController.swift
//  ECGame
//
//  Created by Michale on 2019/12/25.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class RecommendListController: BaseController {
    let ctView = SubUserListView(type:.state)
    let vm = VMSubUserList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的好友"
        setBackButton()
    }
    
    override func loadView() {
        let scroll = UIScrollView()
        view = scroll
        view.backgroundColor = .navigatonBar
        ctView.csDelegate = vm
        view.addSubview(ctView)
        
        ctView.snp.makeConstraints { (make) in
            make.top.equalTo(view.snp.topMargin).offset(15.scale)
            make.leading.equalToSuperview().offset(SubUserListView.leading)
            make.centerX.equalToSuperview()
            make.width.equalToSuperview().offset(-2 * SubUserListView.leading)
            make.bottom.equalToSuperview().offset(-30.scale)
        }
        vm.getUserList {[weak self] (result) in
            switch result{
            case .success:
                self?.ctView.reloadData()
            case let .failed(msg):
                print(msg)
            }
        }
    }
}
