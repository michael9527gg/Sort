//
//  WithdrawController.swift
//  ECGame
//
//  Created by Michale on 2019/12/15.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class WithdrawController:BaseController {
    let ctView = WithdrawView()
    fileprivate let vm = VMWithdraw()
    fileprivate let vmUserBank = VMPickerUserBank()
    fileprivate var bank:MUserBank?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "提现"
        setBackButton()
    }
    
    override func loadView() {
        view = ctView
        let balance = Account.current?.user?.balance ?? 0
        let money = String(format:"%.2f",balance)
        ctView.banlance.price.text = "¥ " + money
        ctView.input.updateState = {[weak self] (text) in
            var isEnable = false
            if let t = text,t.count > 0{
                if let d = Double(t){
                     isEnable = d > 0
                    if d > balance{
                        self?.ctView.input.textField.text = money
                    }
                }
            }
            self?.ctView.nextBtn.isEnabled = isEnable
            return .default("提现金额")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getDefaultBank()
    }
    
    func getDefaultBank() -> Void {
        vmUserBank.userBankList {[weak self] (result) in
            switch result{
            case let .success(banks):
                if let b = self?.vmUserBank.defaultBank(bankList: banks){
                    self?.bank = b
                    self?.updateBankUI()
                    break
                }
                fallthrough
            case .noBank:
                let alert = WhiteAlertController(title:"您目前还没有绑定过银行卡", message:"请绑定银行卡后再来提现", buttons:[.default(title: "取消", action: {
                    self?.navigationController?.popViewController(animated: true)
                }),.hilight(title:"去绑定", action: {
                    let bank = BankListController()
                    self?.navigationController?.pushViewController(bank, animated: true)
                })])
                self?.present(alert, animated: true, completion: nil)
            case let .failed(msg):
                self?.ctView.error.text = msg
            }
        }
    }
    
    func updateBankUI() -> Void {
        guard let b = self.bank else {
            return
        }
        let row = self.ctView.bank
        row.icon.setImage(url:b.logoUrl,placeholder:UIImage(named: "img_nologo"))
        row.title.text = b.bankName
        row.type.text = "尾号 " + String(b.cardNumber?.suffix(4) ?? "")
    }
    
    override func routerEvent(_ event: Any) {
        
        switch event as? WithdrawView.Event {
        case .some(.all):
            let balance = Account.current?.user?.balance ?? 0
            ctView.nextBtn.isEnabled = balance > 0
            ctView.input.textField.text = String(format:"%.2f",balance)
        case let .some(.next(money)):
            withdraw(money: money)
        case .some(.switch):
            PickerUserBankController.show(ctr: self) {[weak self] (type) in
                switch type{
                case .add:
                    let add = BindBankController()
                    self?.navigationController?.pushViewController(add, animated: true)
                case .canceld:
                    break
                case let .selected(bank):
                    self?.bank = bank
                    self?.updateBankUI()
                }
            }
        default:
            break
        }
    }
    
    func withdraw(money:String) -> Void {
        vm.withdraw(money: money, ubid:bank?.ubid ?? "") {[weak self] (result) in
            switch result{
            case .success:
                WithdrawSuccessController.show(ctr: self!, money: money, finish: {
                    self?.navigationController?.popToRootViewController(animated: true)
                }, record: {
                })
            case let .failed(msg):
                self?.ctView.error.text = msg
            }
        }
    }
    
}
