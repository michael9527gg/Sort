//
//  WhiteAlertController.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class WhiteAlertController: BaseController {
    
    enum ButtonType {
        case `default`(title:String?,action:(()->Void)?)
        case hilight(title:String?,action:(()->Void)?)
    }
    
    private var titleStr:String?
    private var message:String?
    private var buttons:[ButtonType]?
    
    convenience init(title:String?,message:String?,buttons:[ButtonType]?) {
        self.init(nibName: nil, bundle: nil)
        self.titleStr = title
        self.message = message
        self.buttons = buttons
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle:nibBundleOrNil)
        modalPresentationStyle = .custom
        modalTransitionStyle = .crossDissolve
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .init(red: 0, green: 0, blue: 0, alpha: 0.65)
        
        let ctView = CenterView(title:titleStr, message: message, buttons: buttons)
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.leading.equalToSuperview().offset(30.scale)
        }
    }
    
    override func routerEvent(_ event: Any) {
        if case let .click(tag)? = event as? CenterView.Event{
            dismiss(animated: true, completion: {[weak self] in
                if let btn = self?.buttons,btn.count > tag {
                    switch btn[tag]{
                    case let .default(_,action):
                        action?()
                    case let .hilight(_,action):
                        action?()
                    }
                }
            })
        }
    }
}

extension WhiteAlertController{
    class CenterView: UIView {
        
        enum Event {
            case click(tag:Int)
        }
        
        let titleLable = UILabel()
        let subTitle = UILabel()
        
        convenience init(title:String?,message:String?,buttons:[ButtonType]?) {
            self.init(frame:.zero)
            
            titleLable.font = UIFont(name: "PingFangSC-Medium", size:18.scale)
            titleLable.textColor = .black
            titleLable.numberOfLines = 0
            titleLable.text = title
            titleLable.textAlignment = .left
            titleLable.backgroundColor = .clear
            addSubview(titleLable)
            titleLable.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.leading.equalToSuperview().offset(20.scale)
                make.top.equalToSuperview().offset(20.scale)
            }
            
            
            subTitle.font = UIFont(name: "PingFangSC-Regular", size:15.scale)
            subTitle.textColor = .note
            subTitle.numberOfLines = 0
            subTitle.text = message
            subTitle.textAlignment = .left
            subTitle.backgroundColor = .clear
            addSubview(subTitle)
            subTitle.snp.makeConstraints { (make) in
                make.leading.centerX.equalTo(titleLable)
                make.top.equalTo(titleLable.snp.bottom).offset(15.scale)
            }
            
            let leading = 10.scale
            var pre:UIView?
            if let btns = buttons{
                for (tag,item) in btns.enumerated(){
                    let btn = UIButton()
                    btn.titleLabel?.font = UIFont(name:"PingFangSC-Medium", size: 16.scale)
                    btn.tag = tag
                    btn.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
                    btn.layer.cornerRadius = 6.scale
                    btn.clipsToBounds = true
                    btn.backgroundColor = .clear
                    switch item{
                    case let .default(title,_):
                        btn.layer.borderColor = UIColor.marchName.cgColor
                        btn.layer.borderWidth = 1
                        btn.setTitleColor(.placeHolder, for: .normal)
                        btn.setTitle(title, for: .normal)
                    case let .hilight(title,_):
                        btn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
                        btn.setTitleColor(.white, for: .normal)
                        btn.setTitle(title, for: .normal)
                    }
                    
                    addSubview(btn)
                    btn.snp.makeConstraints { (make) in
                        if pre == nil{
                            make.leading.equalToSuperview().offset(leading)
                        }else{
                            make.leading.equalTo(pre!.snp.trailing).offset(leading)
                        }
                        make.height.equalTo(48.scale)
                        make.top.equalTo(subTitle.snp.bottom).offset(25.scale)
                        make.width.equalToSuperview().multipliedBy(1.0/Double(buttons!.count)).offset(-leading / CGFloat(buttons!.count) - leading)
                    }
                    pre = btn
                }
            }
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            layer.cornerRadius = 4.scale
            clipsToBounds = true
            backgroundColor = .white
        }
        
        @objc func btnClick(sender:UIButton)->Void{
            let event:Event = .click(tag: sender.tag)
            routerEvent(event)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            invalidateIntrinsicContentSize()
        }
        
        override var intrinsicContentSize: CGSize{
            var h :CGFloat = 0
            if let last = subviews.last{
                h = last.y + last.height + 15.scale
            }
            return CGSize(width: UIView.noIntrinsicMetric, height:h)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
