//
//  BindBankController.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class BindBankController: BaseController {
    let ctView = BindBankView()
    let vm = VMBindBank()
    var bank:MBank?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "绑定银行卡"
        setBackButton()
    }
    
    override func routerEvent(_ event: Any) {
        if case .tap? = event as? BindBankView.BankNameView.Action{
            PickerBankController.show(ctr: self) {[weak self] (type) in
                switch type{
                case .canceld:
                    break
                case let .selected(bank):
                    self?.bank = bank
                    self?.ctView.bankName.textField.text = bank.name
                    self?.ctView.check()
                }
            }
            return
        }
        
        if case let .bind(bankId, branchName)? = event as? BindBankView.Event{
            vm.bind(bank:bank?.bid ?? "", cardNumber:bankId, subbranch:branchName)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let user = Account.current?.user
        if let realityName = user?.realityName,realityName.count > 0{
            ctView.realName.textField.text = "***\(realityName.last!)"
            ctView.realName.textField.isUserInteractionEnabled = false
            let image = UIImage(named: "warning-circle")
            let btn = UIButton()
            btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
            btn.setBackgroundImage(image, for: .normal)
            btn.frame = CGRect(origin: .zero, size: image?.size ?? .zero)
            ctView.realName.rightView = btn
            ctView.realName.addSubview(btn)
        }else{
            toAddName()
        }
    }
    
    func toAddName() -> Void {
        let alert = WhiteAlertController(title:"马上完善我的资料吧", message:"必须先完善真实姓名才能绑定银行卡", buttons: [.default(title: "不需要", action:{[weak self] in
            self?.navigationController?.popViewController(animated: true)
        }),.hilight(title:"去完善", action: {[weak self] in
            let profile = ProfileController()
            self?.navigationController?.pushViewController(profile, animated: true)
        })])
        present(alert, animated: true, completion: nil)
    }
    
    @objc func btnClick()->Void{
        let alert = WhiteAlertController(title:"如需修改持卡人姓名请联系客服", message:"持卡人名称必须与卡号一致，否则可能导致提款失败", buttons: [.default(title: "好的", action: nil)])
        present(alert, animated: true, completion: nil)
    }
    
    override func loadView() {
        view = ctView
        vm.delegate = self
    }
}

extension BindBankController:VMBindBankProtocol{
    func bindSuccess() {
        let alert = WhiteAlertController(title: "绑定成功", message:"下次可以使用此账号收款啦", buttons: [.default(title: "我知道了", action: {[weak self] in
            self?.navigationController?.popViewController(animated: true)
        })])
        present(alert, animated: true, completion: nil)
    }
}
