//
//  AgentCenterController.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class AgentCenterController: BaseController {
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        navigationType = .color(UIColor(hexString:"#111111"))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNavigation()
    }
    
    func setNavigation() -> Void {
        let left = UIBarButtonItem(image: UIImage(named:"icon_back_brown")?.withRenderingMode(.alwaysOriginal), style: .done, target: self, action: #selector(leftClick))
        navigationItem.leftBarButtonItem = left
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? AgentCenterView.Event {
        case .some(.betRecord):
            let record = SubUserBetController()
            navigationController?.pushViewController(record, animated: true)
        case .some(.commission):
            let commisson = CommissionController()
            navigationController?.pushViewController(commisson, animated: true)
        case .some(.member):
            let sub = SubUserListController()
            navigationController?.pushViewController(sub, animated: true)
        case .some(.btnClick):
            let invite = InviteMemberController()
            navigationController?.pushViewController(invite, animated: true)
        default:
            break
        }
    }
    
    override func loadView() {
        view = AgentCenterView()
    }
    
}
