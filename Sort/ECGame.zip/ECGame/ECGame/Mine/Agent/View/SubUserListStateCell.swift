//
//  SubUserListStateCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/25.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class SubUserListStateCell: UICollectionViewCell {
    let name = UILabel()
    let money = UILabel()
    let time = UILabel()
    var action:UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        name.backgroundColor = .navigatonBar
        name.textColor = .marchName
        name.textAlignment = .center
        //        name.text = "欧元打\nwangdang"
        name.font = UIFont(name: "PingFangSC-Medium", size:13.scale)
        name.numberOfLines = 0
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.275)
        }
        
        money.backgroundColor = .navigatonBar
        //        money.text = "332"
        money.textAlignment = .center
        money.textColor = .white
        money.font = UIFont(name: "DINAlternate-Bold", size:14.scale)
        contentView.addSubview(money)
        money.snp.makeConstraints { (make) in
            make.leading.equalTo(name.snp.trailing).offset(1)
            make.top.bottom.width.equalTo(name)
        }
        
        time.backgroundColor = .navigatonBar
        time.textColor = .marchName
        time.textAlignment = .center
        //        time.text = "2019-12-21\n10:12:12"
        time.font = UIFont(name: "PingFangSC-Medium", size:13.scale)
        time.numberOfLines = 0
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.leading.equalTo(money.snp.trailing).offset(1)
            make.top.bottom.width.equalTo(money)
        }
        
        action = actionView()
        contentView.addSubview(action)
        action.snp.makeConstraints { (make) in
            make.leading.equalTo(time.snp.trailing).offset(1)
            make.top.bottom.trailing.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func actionView() -> UIView {
        let lable = UILabel()
        lable.backgroundColor = .navigatonBar
        lable.textAlignment = .center
        lable.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        return lable
    }
    
    
    static var height: CGFloat{
        return 60.scale
    }
}
