//
//  SubUserListHeader.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class SubUserListChargeHeader: UICollectionReusableView {
    
    let action = Lable()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .subUser
        
        let name = Lable()
        name.text = "姓名/账号"
        addSubview(name)
        name.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.275)
        }
        
        let money = Lable()
        money.text = "总金额"
        addSubview(money)
        money.snp.makeConstraints { (make) in
            make.leading.equalTo(name.snp.trailing).offset(1)
            make.top.bottom.width.equalTo(name)
        }
        
        let time = Lable()
        time.text = "注册时间"
        addSubview(time)
        time.snp.makeConstraints { (make) in
            make.leading.equalTo(money.snp.trailing).offset(1)
            make.top.bottom.width.equalTo(money)
        }
        
       
        action.text = "充值"
        addSubview(action)
        action.snp.makeConstraints { (make) in
            make.leading.equalTo(time.snp.trailing).offset(1)
            make.top.bottom.trailing.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static var height: CGFloat{
        return  50.scale
    }
    
}

extension SubUserListChargeHeader{
    class Lable: UILabel {
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            font = UIFont(name: "PingFangSC-Medium", size:14.scale)
            textColor = .white
            textAlignment = .center
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
