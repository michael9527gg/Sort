//
//  SubUserListCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class SubUserListChargeCell: SubUserListStateCell {

    var chargeAcion:(()->Void)?
    
    override func actionView() -> UIView {
        let action = UIButton()
        action.addTarget(self, action: #selector(toCharge(sender:)), for: .touchUpInside)
        action.setTitle("去充值", for: .normal)
        action.setTitleColor(.tintColor, for: .normal)
        action.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        action.backgroundColor = .navigatonBar
        return action
    }
    
    @objc func toCharge(sender:UIButton)->Void{
        chargeAcion?()
    }
    
}
