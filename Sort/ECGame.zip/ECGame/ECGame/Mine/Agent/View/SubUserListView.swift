//
//  SubUserListView.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol SubUserListViewProtocol:class {
    func numberOfItems(section:Int) -> Int
    func config(cell:UICollectionViewCell,at indexPath:IndexPath) -> Void
}

class SubUserListView: UICollectionView {
    
    weak var csDelegate:SubUserListViewProtocol?
    private var type:`Type`
   
    convenience init(type:`Type`) {
        self.init()
        self.type = type
        register(type.headerType, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier:type.reuseId)
        register(type.cellType, forCellWithReuseIdentifier: type.reuseId)
    }
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 1
        flow.sectionHeadersPinToVisibleBounds = true
        let w = kScreenWidth-2*SubUserListView.leading
        flow.headerReferenceSize = CGSize(width: w, height:SubUserListChargeHeader.height)
        flow.itemSize = CGSize(width:w, height:SubUserListChargeCell.height)
        type = .charge
        super.init(frame: frame, collectionViewLayout: flow)
        delegate = self
        dataSource = self
        backgroundColor = .subUser
        clipsToBounds = true
        layer.cornerRadius = 5
        layer.borderWidth = 1
        layer.borderColor = backgroundColor?.cgColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        invalidateIntrinsicContentSize()
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height:contentSize.height)
    }
    
    static var leading:CGFloat{
        return 16.scale
    }
}

extension SubUserListView:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(section: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:type.reuseId, for: indexPath)
        csDelegate?.config(cell: cell, at: indexPath)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        return collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier:type.reuseId, for: indexPath)
    }
}

extension SubUserListView{
    enum `Type` {
        case state
        case charge
        
        var reuseId:String{
            return "id"
        }
        
        var cellType:UICollectionViewCell.Type{
            switch self {
            case .state:
               return SubUserListStateCell.self
            case .charge:
                return SubUserListChargeCell.self
            }
        }
        
        var headerType:UICollectionReusableView.Type{
            switch self {
            case .state:
                return SubUserListStateHeader.self
            case .charge:
                return SubUserListChargeHeader.self
            }
        }
    }
}
