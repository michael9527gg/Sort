//
//  SubBetRecordCollection.swift
//  ECGame
//
//  Created by Michale on 2019/12/27.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class SubBetRecordCollection: BetRecordCollection {
    override var headerClass: UICollectionReusableView.Type{
        return SubBetRecordHeader.self
    }
    
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let view = super.collectionView(collectionView, viewForSupplementaryElementOfKind: kind, at: indexPath)
        if let header = view as? SubBetRecordHeader,let s = csDelegate?.section(at: indexPath.section){
            header.userId.text = s.header?.userId
        }
        return view
    }
}
