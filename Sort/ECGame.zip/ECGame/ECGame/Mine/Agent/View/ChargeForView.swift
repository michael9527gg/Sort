//
//  ChargeForView.swift
//  ECGame
//
//  Created by Michale on 2019/12/25.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class ChargeForView: UIView {
    let bottom = Bottom()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .init(red: 0, green: 0, blue: 0, alpha: 0.65)
        
        addSubview(bottom)
        bottom.snp.makeConstraints { (make) in
            make.bottomMargin.left.right.equalToSuperview()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension ChargeForView{
    class Bottom: UIView,UITextFieldDelegate,KeyboardMoverProtocol {
        enum Event {
            case close
            case next(money:String,note:String?)
        }
        let keyboard = KeyboardMover()
        let title = UILabel()
        let money = BindBankView.Row()
        let note  = BindBankView.Row()
        let nextBtn   = UIButton()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .navigatonBar
            keyboard.delegate = self
//            title.text = "充值到账户"
            title.backgroundColor = .clear
            title.textColor = .white
            title.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
            title.textAlignment = .center
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.top.equalToSuperview().offset(15.scale)
            }
            
            let btn = UIButton()
            btn.addTarget(self, action: #selector(closeBtnClick), for: .touchUpInside)
            btn.setBackgroundImage(UIImage(named: "system-cancel-bold"), for: .normal)
            addSubview(btn)
            btn.snp.makeConstraints { (make) in
                make.centerY.equalTo(title)
                make.trailing.equalToSuperview().offset(-15.scale)
            }
            
            let line = UIView()
            line.backgroundColor = .line
            addSubview(line)
            line.snp.makeConstraints { (make) in
                make.height.equalTo(1)
                make.left.right.equalToSuperview()
                make.top.equalTo(title.snp.bottom).offset(15.scale)
            }
            
            money.textField.keyboardType = .numberPad
            money.textField.delegate = self
            money.textField.keyboardAppearance = .dark
            money.updateState = {(text)  in
                if (text?.count ?? 0) > 0,let d = Double(text!),d>0{
                    return .pass("充值金额")
                }
                return .default("充值金额")
            }
            addSubview(money)
            money.setPlaceholder(str: "请输入")
            money.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.leading.equalToSuperview().offset(15.scale)
                make.top.equalTo(line.snp.bottom).offset(20.scale)
            }
            
            note.updateState = {(text)  in
                return .default("备注")
            }
            note.textField.delegate = self
            note.textField.returnKeyType = .done
            addSubview(note)
            note.setPlaceholder(str: "请输入")
            note.snp.makeConstraints { (make) in
                make.leading.centerX.equalTo(money)
                make.top.equalTo(money.snp.bottom).offset(10.scale)
            }
            
            nextBtn.isEnabled = false
            nextBtn.backgroundColor = .clear
            nextBtn.addTarget(self, action: #selector(nextBtnClick), for: .touchUpInside)
            nextBtn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
            nextBtn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
            nextBtn.setBackgroundImage(UIColor.inactivate.image, for: .disabled)
            nextBtn.setTitleColor(.note, for: .disabled)
            nextBtn.setTitleColor(.white, for: .normal)
            nextBtn.setTitle("提交", for: .normal)
            addSubview(nextBtn)
            nextBtn.snp.makeConstraints { (make) in
                make.leading.trailing.equalToSuperview()
                make.top.equalTo(note.snp.bottom)//.offset(5.scale)
                make.height.equalTo(52.scale)
            }
        }
        
        override func routerEvent(_ event: Any) {
            if case .valueChanged? = event as? InputRowView.Event{
                check()
                return
            }
            next?.routerEvent(event)
        }
        
        @objc func closeBtnClick()->Void{
            endEditing(true)
            let event:Event = .close
            routerEvent(event)
        }
        
        @objc func nextBtnClick()->Void{
            endEditing(true)
            let event:Event = .next(money:money.textField.text!, note:note.textField.text)
            routerEvent(event)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            invalidateIntrinsicContentSize()
        }
        
        @discardableResult
        func check() -> Bool {
            if case .pass? = money.currentState {
                nextBtn.isEnabled = true
            }else{
                nextBtn.isEnabled = false
            }
            return nextBtn.isEnabled
        }
        
        override var intrinsicContentSize: CGSize{
            var h :CGFloat = 0
            if let last = subviews.last{
                h = last.y + last.height + 10.scale
            }
            return CGSize(width: UIView.noIntrinsicMetric, height:h)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            if textField === note.textField{
                if check(){
                    nextBtnClick()
                }else{
                    endEditing(true)
                }
            }
            return true
        }
        
        var movingViewWithKeyboard: UIView{
            return self
        }
    }
}
