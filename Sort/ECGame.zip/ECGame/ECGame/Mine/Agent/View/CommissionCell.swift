//
//  CommissionCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class CommissionCell: UICollectionViewCell {
    let name     = UILabel()
    let state    = UILabel()
    let price    = UILabel()
    let winMoney = TransactionReturnCell.Lable()
    let count = TransactionReturnCell.Lable()
    let sendTime = TransactionReturnCell.Lable()
    let btn      = TransactionDefaultCell.CopyButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        
        name.backgroundColor = .clear
        name.textColor = .white
        name.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
//               name.text = "返水比例1%"
        name.textAlignment = .left
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(16.scale)
            make.top.equalToSuperview().offset(10.scale)
        }
        
        
        state.backgroundColor = .clear
        state.textColor = .error
        state.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        //               name.text = "返水比例1%"
        state.textAlignment = .left
        contentView.addSubview(state)
        state.snp.makeConstraints { (make) in
            make.centerY.equalTo(name)
            make.leading.equalTo(name.snp.trailing).offset(8.scale)
        }
        
        price.font = UIFont(name: "DIN-Regular", size: 16.scale)
        price.backgroundColor = .clear
        price.textColor = .white
        price.textAlignment = .right
        //        price.text = "¥ 2000.00"
        contentView.addSubview(price)
        price.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-16.scale)
            make.centerY.equalTo(name)
        }
        
        //        betMoney.text = "投注总额¥2000"
        contentView.addSubview(winMoney)
        winMoney.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(price.snp.bottom).offset(5.scale)
        }
        
        //        betCount.text = "投注比数:5比"
        contentView.addSubview(count)
        count.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(winMoney.snp.bottom).offset(5.scale)
        }
        
        contentView.addSubview(sendTime)
        sendTime.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(count.snp.bottom).offset(5.scale)
        }
        
        
        contentView.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.trailing.equalTo(price)
            make.centerY.equalTo(sendTime)
        }
        
        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.trailing.equalTo(price)
            make.bottom.equalToSuperview().offset(-1)
            make.height.equalTo(1)
        }
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    static var height: CGFloat{
        return 110.scale
    }
}
