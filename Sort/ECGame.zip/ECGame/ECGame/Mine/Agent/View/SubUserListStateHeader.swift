//
//  SubUserListStateHeader.swift
//  ECGame
//
//  Created by Michale on 2019/12/25.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

class SubUserListStateHeader: SubUserListChargeHeader {
    override init(frame: CGRect) {
        super.init(frame: frame)
        action.text = "状态"
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
