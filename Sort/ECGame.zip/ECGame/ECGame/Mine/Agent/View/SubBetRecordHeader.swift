//
//  SubBetRecordHeader.swift
//  ECGame
//
//  Created by Michale on 2019/12/27.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class SubBetRecordHeader: BetRecordHeader {
    let userId = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        btn.snp.remakeConstraints { (make) in
            make.leading.equalTo(title.snp.trailing).offset(15.scale)
            make.centerY.equalTo(title)
            make.size.equalTo(CGSize(width:68.scale, height:22.scale))
        }
        
        userId.backgroundColor = .clear
        userId.font = title.font
        userId.textColor = .white
        addSubview(userId)
        userId.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-20.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
