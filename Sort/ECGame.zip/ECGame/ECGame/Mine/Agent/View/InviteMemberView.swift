//
//  InviteMemberView.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class InviteMemberView: UIView {
    
    enum Event {
        case submit(userId:String,pwd:String,nickName:String?)
        case checkUserName(String)
    }
    
    let userId  = ProfileView.Row()
    let pwd = ProfileView.Row()
    let nickName = ProfileView.Row()
    let btn = NameLoginView.NextButton()
    let error = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
        UITextField.appearance().tintColor = .white
        
        userId.image.isHidden = false
        userId.setPlaceholder(str: "由字母开头，5-12位字母加数字组成")
        userId.textField.returnKeyType = .next
        userId.textField.delegate = self
        userId.updateState = {(text)  in
            if text == nil || text!.count == 0{
                return .default("会员账号")
            }
            if !(text!.first!.isLetter) {
                return .error("必须以字母开头")
            }
            if text!.count < 5 {
                return .error("至少5位")
            }
            if text!.count > 12 {
                return .error("最多12位")
            }
            if text!.evaluate(nameFormat) == false{
                return .error("不能包含特殊字符")
            }
           
            let event:Event = .checkUserName(text!)
            self.next?.routerEvent(event)
            
            return .pass("会员账号")
        }
        addSubview(userId)
        userId.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
            make.topMargin.equalToSuperview().offset(20.scale)
        }
        
        pwd.image.isHidden = false
        pwd.setPlaceholder(str: "由6-16位字母加数字组成")
        pwd.textField.delegate = self
        pwd.textField.returnKeyType = .next
        pwd.updateState = { (text)  in
            if text == nil || text!.count == 0{
                return .default("会员登录密码")
            }
            if text!.count < 6 {
                return .error("至少6位")
            }
            if text!.count > 16 {
                return .error("最多16位")
            }
            if text!.evaluate(pwdFormat) == false{
                return .error("不能包含特殊字符")
            }
            return .pass("会员登录密码")
        }
        addSubview(pwd)
        pwd.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalTo(userId)
            make.top.equalTo(userId.snp.bottom).offset(10.scale)
        }
        
        
        nickName.setPlaceholder(str: "请输入会员昵称（选填）")
        nickName.textField.delegate = self
        nickName.textField.returnKeyType = .done
        nickName.updateState = { (text)  in
            return .default("会员昵称")
        }
        addSubview(nickName)
        nickName.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalTo(pwd)
            make.top.equalTo(pwd.snp.bottom).offset(10.scale)
        }
        
        let note = UILabel()
        note.backgroundColor = .clear
        note.textColor = .note
        note.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        note.text = "* 标记为必填项目"
        addSubview(note)
        note.snp.makeConstraints { (make) in
            make.leading.equalTo(nickName)
            make.top.equalTo(nickName.snp.bottom).offset(15.scale)
        }
        
        error.backgroundColor = .clear
        error.textAlignment = .left
        error.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        error.textColor = .error
        addSubview(error)
        error.snp.makeConstraints { (make) in
            make.leading.equalTo(note)
            make.top.equalTo(note.snp.bottom).offset(10.scale)
        }
        
        btn.isEnabled = false
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.setTitle("提交", for: .normal)
        btn.setBackgroundImage(UIColor.inactivate.image, for: .disabled)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.height.equalTo(52.scale)
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.snp.bottomMargin)
        }
    }
    
    @objc func btnClick()->Void{
        endEditing(true)
        let event:Event = .submit(userId:userId.textField.text!, pwd: pwd.textField.text!, nickName: nickName.textField.text)
        next?.routerEvent(event)
    }
    
    @discardableResult
    func check() -> Bool {
        if case .pass? = userId.currentState,case .pass? = pwd.currentState{
            btn.isEnabled = true
        }else{
            btn.isEnabled = false
        }
        return btn.isEnabled
    }
    
    override func routerEvent(_ event: Any) {
        error.text = nil
        if case .valueChanged? = event as? InputRowView.Event{
            check()
            return
        }
        next?.routerEvent(event)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension InviteMemberView:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        endEditing(true)
        switch textField {
        case userId.textField:
            _ = pwd.textField.becomeFirstResponder()
        case pwd.textField:
            _ = nickName.textField.becomeFirstResponder()
        case nickName.textField:
            if check(){
                btnClick()
            }else{
                endEditing(true)
            }
        default:
            break
        }
        return true
    }
}
