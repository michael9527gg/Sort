//
//  AgentCenterView.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class AgentCenterView: UIScrollView {
    enum Event {
        case btnClick
        
        case member
        case betRecord
        case commission
    }
    
    let row1 = Row()
    let row2 = Row()
    let row3 = Row()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(hexString: "#3C3C3B")
        let bk = UIImageView()
        let img = UIImage(named: "agent_bk_img")
        bk.image = img
        addSubview(bk)
        bk.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.width.equalToSuperview()
            make.height.equalTo(self.snp.width).multipliedBy(img!.size.height/img!.size.width)
        }
        
        row1.title.text = "我的佣金"
        row1.tag = 1
        row1.icon.image = UIImage(named: "icon_money_grey")
        addSubview(row1)
        row1.snp.makeConstraints { (make) in
            let leading = 20.scale
            make.leading.equalTo(bk).offset(leading)
            make.centerX.equalTo(bk)
            make.top.equalTo(bk.snp.bottom)
        }
        let vSpace = 20.scale
        
        
        row2.title.text = "会员投注记录"
        row2.tag = 2
        row2.icon.image = UIImage(named: "icon_record_grey")
        addSubview(row2)
        row2.snp.makeConstraints { (make) in
            make.leading.width.equalTo(row1)
            make.top.equalTo(row1.snp.bottom).offset(vSpace)
        }
        
        row3.title.text = "我的会员"
        row3.tag = 3
        row3.icon.image = UIImage(named: "icon_member_grey")
        addSubview(row3)
        row3.snp.makeConstraints { (make) in
            make.leading.width.equalTo(row2)
            make.top.equalTo(row2.snp.bottom).offset(vSpace)
        }
        
        let btn = UIButton()
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.setBackgroundImage(UIColor(hexString: "#C7A780").image, for: .normal)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:18.scale)
        btn.setTitleColor(UIColor(hexString: "#2B2B2B"), for:.normal)
        btn.setTitle("立即推荐会员", for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(row3)
            make.height.equalTo(50.scale)
            make.top.equalTo(row3.snp.bottom).offset(40.scale)
            make.bottom.equalToSuperview().offset(-30.scale)
        }
    }
    
    override func routerEvent(_ event: Any) {
        if case let .tap(tag)? = event as? Row.Event{
            switch tag{
            case 1:
                let event:Event = .commission
                next?.routerEvent(event)
            case 2:
                let event:Event = .betRecord
                next?.routerEvent(event)
            case 3:
                let event:Event = .member
                next?.routerEvent(event)
            default:
                break
            }
            return
        }
        next?.routerEvent(event)
    }
    
    @objc func btnClick()->Void{
        let event:Event = .btnClick
        next?.routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension AgentCenterView{
    class Row: UIView {
        
        enum Event {
            case tap(Int)
        }
        
        let icon = UIImageView()
        let title = UILabel()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = UIColor(hexString: "#292929")
            
            let bk = UIView()
            let w = 40.scale
            bk.layer.cornerRadius = w/2
            bk.clipsToBounds = true
            bk.backgroundColor = UIColor(hexString: "#3E3E3E")
            addSubview(bk)
            bk.snp.makeConstraints { (make) in
                make.size.equalTo(CGSize(width: w, height: w))
                make.centerY.equalToSuperview()
                make.leading.equalToSuperview().offset(15.scale)
            }
            
            icon.backgroundColor = .clear
            bk.addSubview(icon)
            icon.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
                make.size.equalTo(CGSize(width: w, height: w))
            }
            
            title.backgroundColor = .clear
            title.font = UIFont(name: "PingFangSC-Regular", size:16.scale)
            title.textColor = UIColor(hexString: "#C7A780")
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.leading.equalTo(bk.snp.trailing).offset(12.scale)
            }
            
            let arrow = UILabel()
            arrow.backgroundColor = .clear
            arrow.text = ">"
            arrow.font = UIFont(name: "PingFangSC-Regular", size:16.scale)
            arrow.textColor = UIColor(hexString: "#8F8F8F")
            addSubview(arrow)
            arrow.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.trailing.equalToSuperview().offset(-15.scale)
            }
        }
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            super.touchesBegan(touches, with: event)
            let event:Event = .tap(tag)
            routerEvent(event)
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height: 70.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
