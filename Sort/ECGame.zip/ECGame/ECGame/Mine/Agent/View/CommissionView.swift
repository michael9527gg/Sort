//
//  CommissionView.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

private let id = "id"

protocol CommissionViewProtocol:class {
    func numberOfItems(section:Int) -> Int
    func config(cell:CommissionCell,at indexPath:IndexPath) -> Void
}

class CommissionView: UICollectionView {
    
    weak var csDelegate:CommissionViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 0
        flow.itemSize = CGSize(width:kScreenWidth, height:CommissionCell.height)
        flow.sectionInset = UIEdgeInsets(top: 10.scale, left:0, bottom: 10.scale, right:0)
        super.init(frame: frame, collectionViewLayout: flow)
        register(CommissionCell.self, forCellWithReuseIdentifier: id)
        delegate = self
        dataSource = self
        backgroundColor = .navigatonBar
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}



extension CommissionView:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(section: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: id, for: indexPath) as! CommissionCell
        csDelegate?.config(cell: cell, at: indexPath)
        return cell
    }
}
