//
//  SubUserBetView.swift
//  ECGame
//
//  Created by Michale on 2019/12/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol SubUserBetViewProtocol:class {
    var countOfSegementItems:Int{
        get
    }
    func titleOfSegementItem(index:Int) -> String
    func segementValueChanged(index:Int,view:SubUserBetView) -> Void
}



class SubUserBetView: UIView {
    
    let collection = SubBetRecordCollection()
    let segement = TransactionSegement()
    
    weak var delegate:SubUserBetViewProtocol?
    
    func updateSegement() -> Void {
        segement.removeAllSegments()
        
        for i in (0 ..< (delegate?.countOfSegementItems ?? 0)).reversed(){
            segement.insertSegment(withTitle:delegate?.titleOfSegementItem(index: i), at: 0, animated: false)
        }
    }
    
    @discardableResult
    func setSegementIndex(index:Int) -> Bool {
        if index > segement.numberOfSegments-1 {
            return false
        }
        
        segement.selectedSegmentIndex = index
        valueChange(segement: segement)
        return true
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .notify
        segement.addTarget(self, action: #selector(valueChange(segement:)), for: UIControl.Event.valueChanged)
        addSubview(segement)
        segement.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.topMargin)
            make.centerX.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
            make.height.equalTo(45.scale)
        }
        
        
        addSubview(collection)
        collection.snp.makeConstraints { (make) in
            make.top.equalTo(segement.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
    
    @objc func valueChange(segement:TransactionSegement) -> Void {
        delegate?.segementValueChanged(index: segement.selectedSegmentIndex, view: self)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
