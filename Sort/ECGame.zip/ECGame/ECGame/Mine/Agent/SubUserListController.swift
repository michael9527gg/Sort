//
//  SubUserListController.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class SubUserListController: BaseController {
    let ctView = SubUserListView(type:.charge)
    let vm = VMSubUserList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的下级会员"
        setBackButton()
    }
    
    override func loadView() {
        let scroll = UIScrollView()
        view = scroll
        view.backgroundColor = .navigatonBar
        ctView.csDelegate = vm
        vm.delegate = self
        view.addSubview(ctView)
        
        ctView.snp.makeConstraints { (make) in
            make.top.equalTo(view.snp.topMargin).offset(15.scale)
            make.leading.equalToSuperview().offset(SubUserListView.leading)
            make.centerX.equalToSuperview()
            make.width.equalToSuperview().offset(-2 * SubUserListView.leading)
            make.bottom.equalToSuperview().offset(-30.scale)
        }
        vm.getUserList {[weak self] (result) in
            switch result{
            case .success:
                self?.ctView.reloadData()
            case let .failed(msg):
                print(msg)
            }
        }
    }
}

extension SubUserListController:VMSubUserListProtocol{
    func didClickCharge(user: MSubUser) {
        let toCharge = ChargeForController(user: user) { (result) in
            
        }
        present(toCharge, animated: true, completion: nil)
    }
}
