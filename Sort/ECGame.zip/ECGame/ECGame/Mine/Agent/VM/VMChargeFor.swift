//
//  VMChargeFor.swift
//  ECGame
//
//  Created by Michale on 2019/12/25.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMChargeForProtocol:class {
    func chargeSuccess() -> Void
    func charge(failed msg:String) -> Void
}


class VMChargeFor: VMBase {
    enum PayType:Int {
        case wechat = 1
        case alipay = 2
        case onlineBank = 3
        case manual = 4
    }
    
    weak var delegate:VMChargeForProtocol?
    
    func charge(subUserID:String,money:String,note:String?) -> Void {
        let payType:PayType = .manual
        Member.provider.request(.rechargeSub(subUserID: subUserID, payType:payType.rawValue, money: money, description:note ?? "", userID:Account.current?.token?.userID ?? "")) { (_ result:ECResult<Any>) in
            
            switch result{
            case .untranslate:
                self.delegate?.chargeSuccess()
            case let .failed(_, msg):
                self.delegate?.charge(failed: msg)
            case .unreachable:
                self.delegate?.charge(failed: "网络无法连接")
            default:
                self.delegate?.charge(failed: "其他错误")
            }
        }
    }
}
