//
//  VMCommission.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMCommissionProtocol:class {
    func success() -> Void
    func failed(msg:String) -> Void
}

class VMCommission: VMBase {
    weak var delegate:VMCommissionProtocol?
    
    var bonus:[MBonus]?
    
    func getBonus() -> Void {
        Member.provider.request(.bonusList(pageIndex: 0, pageSize: 0, userID:Account.current?.token?.userID ?? "")) { (_ result:ECResult<[MBonus]>) in
            switch result{
            case let .success(bonus):
                self.bonus = bonus
                self.delegate?.success()
            case let .failed(_, msg):
                self.delegate?.failed(msg: msg)
            case .unreachable:
                self.delegate?.failed(msg: "网络无法连接")
            default:
                self.delegate?.failed(msg: "其他错误")
            }
        }
    }
}

extension VMCommission:CommissionViewProtocol{
    func numberOfItems(section: Int) -> Int {
        return self.bonus?.count ?? 0
    }
    
    func config(cell: CommissionCell, at indexPath: IndexPath) {
        let m = self.bonus![indexPath.row]
        cell.name.text = String(format: "返水比例%.2f%%",m.scale ?? 0)
        cell.price.text = String(format: "¥ %.2f%",m.bonus ?? 0)
        cell.winMoney.text = String(format: "负盈利 ¥ %.2f%",m.profit ?? 0)
        cell.count.text = "活跃会员数 \(m.usersCount ?? 0)位"
        cell.sendTime.text = "返佣时间 \(m.returnMonth ?? "")"
        cell.state.text = m.state == true ? nil : m.stateName
        let id = m.bid
        cell.btn.touchUpInside = {[weak cell] in
            let event:BaseController.Event = .copy(id)
            cell?.routerEvent(event)
        }
    }
    
}
