//
//  VMSubUserBet.swift
//  ECGame
//
//  Created by Michale on 2019/12/26.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMSubUserBetProtocol:class {
    func success() -> Void
}


class VMSubUserBet: VMBase {
    struct Segement {
        var title:String
        var id:Bool
    }
    weak var delegate:VMSubUserBetProtocol?
    var subUserId:String?
    var openState:Bool = false
    var startDate:String?
    var endDate:String?
    let segements:[Segement] = [Segement(title: "已开奖", id:true),Segement(title: "未开奖", id:false)]
    fileprivate var betsRecord:[BetRecordCollection.Section]?
    
    func getBetList() -> Void {
        Member.provider.request(.subBetRecord(subUserID:subUserId, startDate:startDate, endDate:endDate, betState: nil, openState:openState, pageIndex: 0, pageSize: 100, userID:Account.current?.token?.userID ?? "")) { (_ result:ECResult<[MSubUserBet]>) in
            switch result{
            case let .success(list):
                self.betsRecord = (list as [MUserBet]).translate(openState: self.openState)
                self.delegate?.success()
            default:
                break
            }
        }
    }
}

extension VMSubUserBet:SubUserBetViewProtocol{
    var countOfSegementItems: Int {
        return segements.count
    }
    
    func titleOfSegementItem(index: Int) -> String {
        return segements[index].title
    }
    
    func segementValueChanged(index: Int, view: SubUserBetView) {
        openState = segements[index].id
        getBetList()
    }
}

extension VMSubUserBet:BetRecordCollectionProtocol{
    func numberOfSection() -> Int {
        return betsRecord?.count ?? 0
    }
    
    func section(at section: Int) -> BetRecordCollection.Section {
        return betsRecord![section]
    }
}
