//
//  VMSubUserList.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import SnapKit

protocol VMSubUserListProtocol:class {
    func didClickCharge(user:MSubUser) -> Void
}

class VMSubUserList: VMBase {
    enum Result {
        case success
        case failed(String)
    }
    weak var delegate:VMSubUserListProtocol?
    var users:[MSubUser]?
    
    func getUserList(complete:@escaping (_ result:Result)->Void) -> Void {
        Member.provider.request(.subUserList(pageIndex: 0, pageSize: 0, userID: Account.current?.token?.userID ?? "")) { (_ result:ECResult<[MSubUser]>) in
            switch result{
            case let .success(users):
                self.users = users
                complete(.success)
            case let .failed(_, msg):
                complete(.failed(msg))
            case .unreachable:
                complete(.failed("网络无法连接"))
            default:
                complete(.failed("其他错误"))
            }
        }
    }
}

extension VMSubUserList:SubUserListViewProtocol{
    func numberOfItems(section: Int) -> Int {
        return users?.count ?? 0
    }
    
    func config(cell: UICollectionViewCell, at indexPath: IndexPath) {
        let m = users![indexPath.row]
        
        if let state = cell as? SubUserListStateCell{
            let h = ((m.realityName?.count ?? 0) > 0 && (m.userID?.count ?? 0) > 0) ? "\n" : ""
            state.name.text = (m.realityName ?? "") + h + (m.userID ?? "")
            state.money.text = String(format: "%.2f",m.balance ?? 0)
            state.time.text = m.registerTime
            if let lable = state.action as? UILabel{
                lable.text = m.stateName
                lable.textColor = m.state == true ? .up : .error
            }
        }
        
        if let charge = cell as? SubUserListChargeCell{
            charge.chargeAcion = {[weak self] in
                self?.delegate?.didClickCharge(user: m)
            }
        }
    }
}
