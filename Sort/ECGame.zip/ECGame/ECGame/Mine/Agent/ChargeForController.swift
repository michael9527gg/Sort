//
//  ChargeForController.swift
//  ECGame
//
//  Created by Michale on 2019/12/25.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class ChargeForController: BaseController {
    typealias Complete = (`Type`)->Void
    
    enum `Type` {
        case canceld
        case success
    }
    
    let ctView = ChargeForView()
    let vm = VMChargeFor()
    
    private var user:MSubUser?
    private var complete:Complete?
    
    convenience init(user:MSubUser,complete:Complete?) {
        self.init(nibName: nil, bundle: nil)
        self.user = user
        self.complete = complete
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle:nibBundleOrNil)
        modalPresentationStyle = .custom
        modalTransitionStyle = .crossDissolve
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ctView.bottom.money.textField.becomeFirstResponder()
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? ChargeForView.Bottom.Event {
        case .some(.close):
            dismiss(animated:true, completion: {
                self.complete?(.canceld)
            })
        case let .some(.next(money, note)):
            vm.charge(subUserID:user?.userID ?? "", money:money, note: note)
        default:
            break
        }
    }
    
    override func loadView() {
        view = ctView
        vm.delegate = self
        ctView.bottom.title.text = "充值到账户“\((user?.realityName?.count ?? 0) > 0 ? user!.realityName! : user?.userID ?? "")”"
    }
}

extension ChargeForController:VMChargeForProtocol{
    func chargeSuccess() {
        dismiss(animated: true) {
            self.complete?(.success)
        }
    }
    
    func charge(failed: String) {
        print(failed)
    }
}
