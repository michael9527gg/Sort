//
//  InviteMemberController.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class InviteMemberController: BaseController {
    let ctView = InviteMemberView()
    let vm = VMInviteMember()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "推荐会员"
        setBackButton()
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? InviteMemberView.Event {
        case let .some(.checkUserName(userId)):
            vm.userExist(userId:userId) {[weak self] (exist,msg)  in
                if exist == true,userId == self?.ctView.userId.textField.text{
                    self?.ctView.userId.currentState = .error(msg)
                }
            }
        case let .some(.submit(userId, pwd, nickName)):
            vm.invite(userId:userId, pwd: pwd, nickName: nickName) {[weak self] (result) in
                switch result{
                case .success:
                    let alert = WhiteAlertController(title: "操作成功", message: "会员账号已成功创建", buttons: [.default(title: "返回", action: {
                        self?.navigationController?.popViewController(animated: true)
                    }),.hilight(title: "继续", action:nil)])
                    self?.present(alert, animated: true, completion: nil)
                case let .failed(msg):
                    self?.ctView.error.text = msg
                }
            }
        default:
            break
        }
    }
    
    override func loadView() {
        view = ctView
    }
}
