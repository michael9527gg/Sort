//
//  CommissionController.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class CommissionController: BaseController {
    let ctView = CommissionView()
    let vm = VMCommission()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的佣金"
        setBackButton()
    }
    
    override func loadView() {
        view = ctView
        vm.delegate = self
        ctView.csDelegate = vm
        vm.getBonus()
    }
}

extension CommissionController:VMCommissionProtocol{
    func success() {
        ctView.reloadData()
    }
    
    func failed(msg: String) {
        
    }
}
