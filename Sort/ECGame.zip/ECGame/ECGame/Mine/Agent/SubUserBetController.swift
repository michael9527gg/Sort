//
//  SubUserBetController.swift
//  ECGame
//
//  Created by Michale on 2019/12/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class SubUserBetController: BaseController {
    let ctView = SubUserBetView()
    let vm = VMSubUserBet()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        navigationType = .color(.notify)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "会员投注记录"
        setBackButton()
    }
    
    override func loadView() {
        view = ctView
        ctView.collection.csDelegate = vm
        ctView.delegate = vm
        vm.delegate = self
        ctView.updateSegement()
        ctView.setSegementIndex(index: 0)
    }
    
}

extension SubUserBetController:VMSubUserBetProtocol{
    func success() {
        ctView.collection.reloadData()
    }
}
