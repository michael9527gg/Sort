//
//  RecommendView.swift
//  ECGame
//
//  Created by Michale on 2019/12/11.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class RecommendView: UIView {
    
    enum Event {
        case friendList
    }
    
    class CodeLable: UILabel {
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .selected
            textColor = .white
            layer.cornerRadius = 4.scale
            clipsToBounds = true
            textAlignment = .center
            font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        override var intrinsicContentSize: CGSize{
            let s = super.intrinsicContentSize
            return CGSize(width:s.width + 40.scale, height:34.scale)
        }
    }
    
    let qrCodeSize = CGSize(width: 114.scale, height: 114.scale)
    let qrCode = UIImageView()
    let link = UILabel()
    let inviteCode = CodeLable()
    let btn = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
        let step1 = UILabel()
        step1.backgroundColor = .clear
        step1.textColor = .white
        step1.text = "步骤一 打开注册页面"
        step1.font = UIFont(name: "PingFangSC-Regular", size:16.scale)
        addSubview(step1)
        step1.snp.makeConstraints { (make) in
            let leading = 17.scale
            make.leading.equalToSuperview().offset(leading)
            make.width.equalToSuperview().offset(-2 * leading)
            make.top.equalTo(self.snp.topMargin).offset(20.scale)
        }
        
        let method1 = UILabel()
        method1.backgroundColor = .clear
        method1.textColor = .marchName
        method1.text = "方法一、扫描下面二维码打开注册页面"
        method1.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        addSubview(method1)
        method1.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(step1.snp.bottom).offset(10.scale)
        }
        
        
        qrCode.backgroundColor = .clear
        addSubview(qrCode)
        qrCode.snp.makeConstraints { (make) in
            make.size.equalTo(qrCodeSize)
            make.centerX.equalToSuperview()
            make.top.equalTo(method1.snp.bottom).offset(15.scale)
        }
        
        let method2 = UILabel()
        method2.backgroundColor = .clear
        method2.textColor = .marchName
        method2.text = "方法二、复制下面的链接"
        method2.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        addSubview(method2)
        method2.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(qrCode.snp.bottom).offset(15.scale)
        }
        
       
        link.backgroundColor = .clear
        link.textColor = .white
        link.textAlignment = .center
        link.numberOfLines = 0
        link.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        addSubview(link)
        link.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalTo(step1)
            make.top.equalTo(method2.snp.bottom).offset(10.scale)
        }
        
        let copyLinkBtn = UIButton()
        copyLinkBtn.backgroundColor = .clear
        copyLinkBtn.setTitle("点击复制链接", for: .normal)
        copyLinkBtn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        copyLinkBtn.setTitleColor(.tintColor, for: .normal)
        addSubview(copyLinkBtn)
        copyLinkBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
             make.top.equalTo(link.snp.bottom).offset(10.scale)
        }
        
        let note = UILabel()
        note.backgroundColor = .clear
        note.textColor = .note
        note.text = "需要在浏览器中打开"
        note.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        addSubview(note)
        note.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(copyLinkBtn.snp.bottom).offset(10.scale)
        }
        
        let step2 = UILabel()
        step2.backgroundColor = .clear
        step2.textColor = .white
        step2.text = "步骤二 使用推荐码注册"
        step2.font = UIFont(name: "PingFangSC-Regular", size:16.scale)
        addSubview(step2)
        step2.snp.makeConstraints { (make) in
            make.top.equalTo(note.snp.bottom).offset(20.scale)
            make.leading.equalTo(step1)
        }
        
        let inviteDes = UILabel()
        inviteDes.backgroundColor = .clear
        inviteDes.textColor = .marchName
        inviteDes.text = "使用专属推荐码在下载的APP内注册"
        inviteDes.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        addSubview(inviteDes)
        inviteDes.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(step2.snp.bottom).offset(10.scale)
        }
        
        
        addSubview(inviteCode)
        inviteCode.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(inviteDes.snp.bottom).offset(15.scale)
        }
        
        let copyBtn = UIButton()
        copyBtn.backgroundColor = .clear
        copyBtn.setTitle("点击复制", for: .normal)
        copyBtn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        copyBtn.setTitleColor(.tintColor, for: .normal)
        addSubview(copyBtn)
        copyBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(inviteCode.snp.bottom).offset(10.scale)
        }
        
        
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.backgroundColor = .clear
        btn.setTitle("查看我的好友", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 16.scale)
        btn.setBackgroundImage(UIColor.selected.image, for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(self.snp.bottomMargin)
            make.height.equalTo(52.scale)
        }
    }
    
    @objc func btnClick()->Void{
        let event:Event = .friendList
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
