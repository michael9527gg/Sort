//
//  MessageListView.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol MessageListViewProtocol:class {
    func numberOfItems(in section:Int) -> Int
    func cellForItem(at indexPath:IndexPath) -> MessageListView.CellType
    func didSelectItem(at indexPath:IndexPath) -> Void
}

class MessageListView: UICollectionView {
    weak var csDelegate:MessageListViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        let leading = 16.scale
        flow.itemSize = CGSize(width:kScreenWidth - 2*leading, height: MessageListCell.cellHeight)
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 0
        flow.sectionInset = UIEdgeInsets(top: 10.scale, left:leading, bottom: 10.scale, right:leading)
        super.init(frame: frame, collectionViewLayout: flow)
        let t:CellType = .default(nil)
        register(t.cellClass, forCellWithReuseIdentifier: t.reuseId)
        delegate = self
        dataSource = self
        backgroundColor = .navigatonBar
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension MessageListView:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = csDelegate?.cellForItem(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:type!.reuseId, for: indexPath) as! MessageListCell
        if case let .default(delegate)? = type {
            cell.updateUI(delegate)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        csDelegate?.didSelectItem(at: indexPath)
    }
}

extension MessageListView{
    enum CellType {
        case `default`(_ delegate:MessageListCellProtocol?)
        
        var reuseId:String{
            return "id"
        }
        
        var cellClass:UICollectionViewCell.Type{
            return MessageListCell.self
        }
    }
}
