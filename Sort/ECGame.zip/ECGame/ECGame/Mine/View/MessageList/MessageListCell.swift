//
//  MessageListCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol MessageListCellProtocol {
    var titleText:String?{
        get
    }
    
    var readStatus:Bool{
        get set
    }
    
    var timeText:String?{
        get
    }
    var detailText:String?{
        get
    }
    
    var id:String?{
        get
    }
}

class MessageListCell: UICollectionViewCell {
    
    let view = MessageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        
        contentView.addSubview(view)
        view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func updateUI(_ delegate:MessageListCellProtocol?) -> Void {
        let isRead = delegate?.readStatus ?? false
        
        view.spotImg.image = isRead ? nil : UIImage(named: "icon_noreaded")
        view.title.textColor = isRead ? .note : .white
        view.title.text = delegate?.titleText
        view.time.text = delegate?.timeText

        let ck = isRead ? view.time.textColor : .marchName
        let style = NSMutableParagraphStyle()
        style.lineSpacing = 8.scale
        let attr = NSMutableAttributedString(string:delegate?.detailText ?? "", attributes: [NSAttributedString.Key.font :view.detail.font!,NSAttributedString.Key.foregroundColor:ck!,NSAttributedString.Key.paragraphStyle:style])
        view.detail.attributedText = attr
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static var cellHeight:CGFloat{
        return 104.scale
    }
}

extension MessageListCell{
    class MessageView: UIView {
        let spotImg = UIImageView()
        let title   = UILabel()
        let time    = UILabel()
        let detail  = UILabel()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            
            spotImg.backgroundColor = .clear
            addSubview(spotImg)
            spotImg.setContentHuggingPriority(.defaultHigh + 1, for: .horizontal)
            spotImg.snp.makeConstraints { (make) in
                make.leading.equalToSuperview()
            }
            
            title.backgroundColor = .clear
            title.textColor = .white
            title.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
            title.textAlignment = .left
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.leading.equalTo(spotImg.snp.trailing)
                make.top.equalToSuperview().offset(18.scale)
                make.centerY.equalTo(spotImg)
            }
            
            time.backgroundColor = .clear
            time.textColor = .forgetPwd
            time.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
            //        time.text = "今天 16:20"
            time.textAlignment = .right
            addSubview(time)
            time.snp.makeConstraints { (make) in
                make.trailing.equalToSuperview()
                make.centerY.equalTo(title)
            }
            
            detail.backgroundColor = .clear
            detail.numberOfLines = 2
            detail.textColor = .marchName
            detail.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
            addSubview(detail)
            detail.snp.makeConstraints { (make) in
                make.left.right.equalToSuperview()
                make.top.equalTo(title.snp.bottom).offset(9.scale)
            }
            
            let line = UIView()
            line.backgroundColor = .line
            addSubview(line)
            line.snp.makeConstraints { (make) in
                make.left.right.equalToSuperview()
                make.bottom.equalToSuperview().offset(-1)
                make.height.equalTo(1)
            }
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            let hspace = 10.scale
            if title.x + title.width + hspace > time.x{
                title.width = time.x - hspace - title.x
            }
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
