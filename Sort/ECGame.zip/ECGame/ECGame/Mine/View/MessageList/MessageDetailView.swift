//
//  MessageDetailView.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MessageDetailView: UIScrollView {
    let title = UILabel()
    let detail = UILabel()
    let time = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
        title.textAlignment = .left
        addSubview(title)
        title.snp.makeConstraints { (make) in
            let leading = 17.scale
            make.leading.equalToSuperview().offset(leading)
            make.width.equalToSuperview().offset(-2 * leading)
            make.centerX.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(20.scale)
            
        }
        
        detail.backgroundColor = .clear
        detail.textColor = .marchName
        detail.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        detail.textAlignment = .right
        detail.numberOfLines = 0
        addSubview(detail)
        detail.snp.makeConstraints { (make) in
            make.left.right.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(20.scale)
        }
        
        time.backgroundColor = .clear
        time.textColor = .forgetPwd
        time.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        addSubview(time)
        time.snp.makeConstraints { (make) in
            make.left.right.equalTo(title)
            make.top.equalTo(detail.snp.bottom).offset(20.scale)
            make.bottom.equalToSuperview()
        }
    }
    
    func set(title:String?,detail:String?,time:String?) -> Void {
        self.title.text = title
        let style = NSMutableParagraphStyle()
        style.lineSpacing = 8.scale
        let attr = NSMutableAttributedString(string:detail ?? "", attributes: [NSAttributedString.Key.font :self.detail.font!,NSAttributedString.Key.foregroundColor:self.detail.textColor!,NSAttributedString.Key.paragraphStyle:style])
        self.detail.attributedText = attr
        self.time.text = time
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
