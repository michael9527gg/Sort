//
//  BankListView.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol BankListViewProtocol:class {
    func numberOfItems(in section:Int) -> Int
    func config(cell:BankListCell, indexPath:IndexPath) ->Void
}

private let reuseId = "id"

class BankListView: UICollectionView {
    weak var csDelegate:BankListViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        let leading = 21.scale
        flow.itemSize = CGSize(width:kScreenWidth - 2*leading, height:110.scale)
        flow.footerReferenceSize = flow.itemSize
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 20.scale
        flow.sectionInset = UIEdgeInsets(top: 10.scale, left:leading, bottom: 10.scale, right:leading)
        super.init(frame: frame, collectionViewLayout: flow)
        register(BankListCell.self,forCellWithReuseIdentifier: reuseId)
        register(BankListFooter.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier:reuseId)
        delegate = self
        dataSource = self
        backgroundColor = .navigatonBar
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension BankListView:UICollectionViewDelegate{
}

extension BankListView:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseId, for: indexPath) as! BankListCell
        csDelegate?.config(cell: cell, indexPath: indexPath)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let footer = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: reuseId, for: indexPath)
        return footer
    }
}

