//
//  MineTitleView.swift
//  ECGame
//
//  Created by Michale on 2019/12/10.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MineTitleView: UIView {
    let icon = UIImageView(image: UIImage(named: "icon_user"))
    let nickName = UILabel()
    let realName = UILabel()
    let vip = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        
        addSubview(icon)
        icon.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        
        nickName.backgroundColor = .clear
        nickName.textColor = .note
        nickName.font = UIFont(name: "PingFangSC-Regular", size: 15.scale)
        addSubview(nickName)
        nickName.snp.makeConstraints { (make) in
            make.leading.equalTo(icon.snp.trailing).offset(5.scale)
            make.centerY.equalToSuperview()
        }
        
        realName.backgroundColor = .clear
        realName.textColor = .white
        realName.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
        addSubview(realName)
        realName.snp.makeConstraints { (make) in
            make.leading.equalTo(nickName.snp.trailing).offset(8.scale)
            make.centerY.equalToSuperview()
        }
        
        vip.backgroundColor = .clear
        addSubview(vip)
        vip.snp.makeConstraints { (make) in
            make.centerY.equalTo(icon)
            make.leading.equalTo(realName.snp.trailing).offset(5.scale)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        invalidateIntrinsicContentSize()
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width:vip.x+vip.width, height:icon.height)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
