//
//  MinCollectionHeader.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MineHeaderCell: UICollectionViewCell {
    
    enum Event {
        case charge
        case withdraw
    }
    
    let balance = UILabel()
    let lottery = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        let bk = UIImageView()
        bk.backgroundColor = .clear
        bk.isUserInteractionEnabled = true
        bk.image = UIImage(named: "account_shape")
        contentView.addSubview(bk)
        bk.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(166.scale)
        }
        

        balance.backgroundColor = .clear
        bk.addSubview(balance)
        balance.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(23.scale)
        }
        
//        let arrow = UIImageView()
//        arrow.backgroundColor = .clear
//        arrow.image = UIImage(named: "icon_account_ne")
//        bk.addSubview(arrow)
//        arrow.snp.makeConstraints { (make) in
//            make.centerY.equalTo(balance)
//            make.leading.equalTo(balance.snp.trailing).offset(8.scale)
//        }
        
        lottery.backgroundColor = .clear
        bk.addSubview(lottery)
        lottery.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(balance.snp.bottom).offset(6.scale)
        }
        
        let chargeBtn = UIButton()
        chargeBtn.addTarget(self, action: #selector(chargeAction), for: .touchUpInside)
        chargeBtn.backgroundColor = .clear
        chargeBtn.setTitle("充值", for: .normal)
        chargeBtn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        chargeBtn.setTitleColor(.white, for: .normal)
        chargeBtn.setBackgroundImage(UIImage(named: "bg_charge"), for: .normal)
        bk.addSubview(chargeBtn)
        chargeBtn.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(24.scale)
            make.bottom.equalToSuperview().offset(-20.scale)
            make.size.equalTo(CGSize(width:136.scale, height:48.scale))
        }
        
        let withdrawBtn = UIButton()
        withdrawBtn.addTarget(self, action: #selector(withdraw), for: .touchUpInside)
        withdrawBtn.backgroundColor = .clear
        withdrawBtn.setTitle("提现", for: .normal)
        withdrawBtn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        withdrawBtn.setTitleColor(.white, for: .normal)
        withdrawBtn.setBackgroundImage(UIImage(named: "bg_tixian"), for: .normal)
        bk.addSubview(withdrawBtn)
        withdrawBtn.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-24.scale)
            make.size.bottom.equalTo(chargeBtn)
        }
    }
    
    @objc func chargeAction() ->Void{
        let event:Event = .charge
        next?.routerEvent(event)
    }
    
    @objc func withdraw() ->Void{
        let event:Event = .withdraw
        next?.routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

