//
//  MineView.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol MineViewProtocol:class {
    func numberOfItems() -> Int
    func cellForItem(at indexPath:IndexPath) -> MineView.CellType
}


private let leading = 15.scale

class MineView: UICollectionView {
    
    weak var csDelegate:MineViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 0
        flow.sectionInset = UIEdgeInsets(top: 0, left: leading, bottom: 0, right: leading)
        super.init(frame: frame, collectionViewLayout:flow)
        backgroundColor = .navigatonBar
        showsVerticalScrollIndicator = false
        delegate = self
        dataSource = self
        let cells:[CellType] = [.centerTitle(img: nil, title: nil, didSelect: nil),
                                .titleDes(img: nil, title: nil, des: nil, didSelect:nil),
                                .header(balance: nil, lottery: nil),
                                .footer]
        for item in cells {
            register(item.cellClass, forCellWithReuseIdentifier: item.reuseId)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension MineView:UICollectionViewDelegate{
}

extension MineView:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return csDelegate?.cellForItem(at: indexPath).itemSize ?? .zero
    }
}

extension MineView:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = csDelegate!.cellForItem(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: type.reuseId, for: indexPath)
        
        switch type {
        case let .centerTitle(img,title,_):
            if let c = cell as? MineCenterTitleCell{
                c.title.text = title
                c.image.image = UIImage(named:img ?? "")
            }
        case let .titleDes(img, title, des,_):
            if let c = cell as? MineTitleDesCell{
                c.title.text = title
                c.image.image = UIImage(named:img ?? "")
                c.des.text = des
            }
        case let .header(balance, lottery):
            if let c = cell as? MineHeaderCell{
                c.balance.attributedText = balance
                c.lottery.attributedText = lottery
            }
        default:
            break
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let type = csDelegate!.cellForItem(at: indexPath)
        switch type {
        case let .centerTitle(_,_,didSelect):
            didSelect?()
        case let .titleDes(_,_,_,didSelect):
            didSelect?()
        default:
            break
        }
    }
}

extension MineView{
    enum CellType {
        
        var itemSize:CGSize{
            let width = kScreenWidth - 2 * leading
            switch self {
            case .centerTitle,.titleDes:
                return CGSize(width:width , height: 60.scale)
            case .header:
                return CGSize(width: width, height: 200.scale)
            case .footer:
                return CGSize(width: width, height: 80.scale)
            }
        }
        
        var cellClass:UICollectionViewCell.Type{
            switch self {
            case .centerTitle:
                return MineCenterTitleCell.self
            case .titleDes:
                return MineTitleDesCell.self
            case .header:
                return MineHeaderCell.self
            case .footer:
                return MineFooterCell.self
            }
        }
        
        var reuseId:String{
            switch self {
            case .centerTitle:
                return "center"
            case .titleDes:
                return "des"
            case .header:
                return "h"
            case .footer:
                return "f"
            }
        }
        
        case centerTitle(img:String?,title:String?,didSelect:(()->Void)?)
        case titleDes(img:String?,title:String?,des:String?,didSelect:(()->Void)?)
        case header(balance:NSAttributedString?,lottery:NSAttributedString?)
        case footer
    }
}
