//
//  MinCollectionCellBase.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MineBaseCell: UICollectionViewCell {
    
    let image = UIImageView()
    let title = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        image.backgroundColor = .clear
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.centerY.leading.equalToSuperview()
            let w = 26.scale
            make.size.equalTo(CGSize(width:w, height:w))
        }
        
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Regular", size:16.scale)
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.leading.equalTo(image.snp.trailing).offset(14.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
