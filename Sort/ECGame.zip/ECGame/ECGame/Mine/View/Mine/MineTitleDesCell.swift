//
//  MinCollectionTwoLineCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MineTitleDesCell: MineBaseCell {
    let des = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        title.snp.makeConstraints { (make) in
            make.bottom.equalTo(image.snp.centerY)
        }
        
        des.backgroundColor = .clear
        des.textColor = .note
        des.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        contentView.addSubview(des)
        des.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(2.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
