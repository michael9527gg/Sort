//
//  MinCollectionFooter.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MineFooterCell: UICollectionViewCell {
    enum Event {
        case exit
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        let btn = UIButton()
        btn.addTarget(self, action: #selector(exit), for: .touchUpInside)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 6.scale
        btn.backgroundColor = .clear
        btn.setTitle("安全退出", for: .normal)
        btn.setBackgroundImage(UIColor.line.image, for: .normal)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 18.scale)
        btn.setTitleColor(.white, for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.centerY.left.right.equalToSuperview()
            make.height.equalTo(50.scale)
        }
    }
    
    @objc func exit() ->Void{
        let event:Event = .exit
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
