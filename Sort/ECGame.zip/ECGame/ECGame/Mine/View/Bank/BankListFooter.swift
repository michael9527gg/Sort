//
//  BankListFooter.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BankListFooter: UICollectionReusableView {
    
    enum Event {
        case add
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        let bk = UIImageView()
        bk.image = UIImage(named: "add_card")
        addSubview(bk)
        bk.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10.scale)
            make.leading.equalToSuperview().offset(21.scale)
            make.centerX.equalToSuperview()
            make.height.equalTo(68.scale)
        }
        
        let add = UIImageView()
        add.image = UIImage(named: "icon_add_bankcard")
        addSubview(add)
        add.snp.makeConstraints { (make) in
            make.centerY.equalTo(bk)
            make.leading.equalTo(bk).offset(20.scale)
        }
        
        let title = UILabel()
        title.backgroundColor = .clear
        title.text = "添加银行卡"
        title.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        title.textColor = .marchName
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerY.equalTo(bk)
            make.leading.equalTo(add.snp.trailing).offset(8.scale)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        let event:Event = .add
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
