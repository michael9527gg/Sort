//
//  BankListCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BankListCell: UICollectionViewCell {
    let icon = UIImageView()
    let name = UILabel()
    let idCard = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .line
        contentView.layer.cornerRadius = 10
        contentView.clipsToBounds = true
      
        icon.backgroundColor = .clear
//        icon.image = UIImage(named: "img_nologo")
        contentView.addSubview(icon)
        icon.snp.makeConstraints { (make) in
            let w = 30.scale
            make.leading.equalToSuperview().offset(11.scale)
            make.top.equalToSuperview().offset(11.scale)
            make.size.equalTo(CGSize(width: w, height: w))
        }
        
       
//        name.text = "工商银行"
        name.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        name.textColor = .white
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.centerY.equalTo(icon)
            make.leading.equalTo(icon.snp.trailing).offset(7.scale)
        }
        
       
        idCard.font = UIFont(name: "DINAlternate-Bold", size:26.scale)
        idCard.textColor = .white
//        idCard.text = "6214 **** **** 7788"
        contentView.addSubview(idCard)
        idCard.snp.makeConstraints { (make) in
            make.top.equalTo(icon.snp.bottom).offset(16.scale)
            make.leading.equalTo(icon)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
