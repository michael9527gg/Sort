//
//  BetRecordCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BetRecordCell: UICollectionViewCell {
    let teamLogo = UIImageView()
    let oddName = UILabel()
    let playName = UILabel()
    let teamName = UILabel()
    let time = UILabel()
    let state = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        let cover = UIImageView()
        cover.backgroundColor = .clear
        contentView.addSubview(cover)
        cover.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10.scale)
            let w = 40.scale
            make.size.equalTo(CGSize(width:w, height:w))
            make.leading.equalToSuperview().offset(15.scale)
        }
        
        teamLogo.backgroundColor = .clear
        cover.addSubview(teamLogo)
        teamLogo.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            let w = 32.scale
            make.size.equalTo(CGSize(width:w, height:w))
        }
        
        oddName.backgroundColor = .clear
        oddName.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
        oddName.textColor = .white
        contentView.addSubview(oddName)
        oddName.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(72.scale)
            make.top.equalTo(cover).offset(-3.scale)
            make.centerX.equalToSuperview()
        }
        let vSpace = 4.scale
        playName.backgroundColor = .clear
        playName.textAlignment = .left
        playName.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        playName.textColor = .marchName
        contentView.addSubview(playName)
        playName.snp.makeConstraints { (make) in
            make.left.right.equalTo(oddName)
            make.top.equalTo(oddName.snp.bottom).offset(vSpace)
        }
        
        teamName.backgroundColor = .clear
        teamName.textAlignment = .left
        teamName.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        teamName.textColor = .marchName
        contentView.addSubview(teamName)
        teamName.snp.makeConstraints { (make) in
            make.left.right.equalTo(oddName)
            make.top.equalTo(playName.snp.bottom).offset(vSpace)
        }
        
        time.backgroundColor = .clear
        time.textAlignment = .left
        time.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        time.textColor = .marchName
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.left.right.equalTo(oddName)
            make.top.equalTo(teamName.snp.bottom).offset(vSpace)
        }
        
        state.backgroundColor = .clear
        contentView.addSubview(state)
        state.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-15.scale)
        }
        
        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-1)
            make.height.equalTo(1)
            make.leading.equalTo(time)
            make.trailing.equalToSuperview().offset(-20.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static var cellHeight:CGFloat{
        return 106.scale
    }
}
