//
//  BetRecordFooter.swift
//  ECGame
//
//  Created by Michale on 2019/12/9.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BetRecordFooter: UICollectionReusableView {
    let betMoney = UILabel()
    let odds     = UILabel()
    let winMoney = UILabel()
    let time     = UILabel()
    let state    = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        betMoney.backgroundColor = .clear
        addSubview(betMoney)
        betMoney.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(72.scale)
            make.top.equalToSuperview().offset(15.scale)
            make.centerX.equalToSuperview()
        }
        
        odds.backgroundColor = .clear
        odds.textAlignment = .right
        addSubview(odds)
        odds.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-20.scale)
            make.centerY.equalTo(betMoney)
        }
        
        winMoney.backgroundColor = .clear
        winMoney.textAlignment = .left
//        winMoney.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
//        winMoney.textColor = .marchName
        addSubview(winMoney)
        winMoney.snp.makeConstraints { (make) in
            make.leading.equalTo(betMoney)
            make.trailing.equalTo(odds)
            make.top.equalTo(betMoney.snp.bottom).offset(5.scale)
        }
        
        time.backgroundColor = .clear
        time.textAlignment = .left
        time.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        time.textColor = .marchName
        addSubview(time)
        time.snp.makeConstraints { (make) in
            make.leading.equalTo(betMoney)
            make.trailing.equalTo(odds)
            make.top.equalTo(winMoney.snp.bottom).offset(5.scale)
        }
        
        state.backgroundColor = .clear
        addSubview(state)
        state.snp.makeConstraints { (make) in
            make.top.equalTo(winMoney)
            make.trailing.equalToSuperview().offset(-30.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
