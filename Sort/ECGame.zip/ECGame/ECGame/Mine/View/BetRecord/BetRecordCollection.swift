//
//  BettingRecordCollection.swift
//  ECGame
//
//  Created by Michale on 2019/11/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

private let id = "id"


protocol BetRecordCollectionProtocol:class {
    func numberOfSection() -> Int
    func section(at section:Int) -> BetRecordCollection.Section
}

class BetRecordCollection: UICollectionView {
    
    weak var csDelegate:BetRecordCollectionProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.itemSize = CGSize(width: kScreenWidth, height:BetRecordCell.cellHeight)
        flow.headerReferenceSize = CGSize(width: kScreenWidth, height: 44.scale)
        flow.footerReferenceSize = CGSize(width: kScreenWidth, height: 90.scale)
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 0
        flow.sectionInset = .zero
        super.init(frame: frame, collectionViewLayout: flow)
        register(BetRecordCell.self, forCellWithReuseIdentifier: id)
        register(BetRecordFooter.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier: id)
        register(headerClass, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier: id)
        delegate = self
        dataSource = self
        backgroundColor = .clear
    }
    

    var headerClass:UICollectionReusableView.Type{
        return BetRecordHeader.self
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension BetRecordCollection:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return csDelegate?.numberOfSection() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.section(at:section).cells?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: id, for: indexPath) as! BetRecordCell
        let s = csDelegate?.section(at: indexPath.section).cells?[indexPath.row]
        
        cell.teamLogo.setImage(url: s?.teamLogo, placeholder: nil)
        cell.oddName.text = s?.oddName
        cell.teamName.text = s?.teamName
        cell.time.text = s?.time
        cell.playName.text = s?.playName
        cell.state.image = ((s?.stateImage?.count ?? 0) > 0) ? UIImage(named: s!.stateImage!) : nil
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let view = collectionView.dequeueReusableSupplementaryView(ofKind:kind, withReuseIdentifier:id, for:indexPath)
        let s = csDelegate?.section(at: indexPath.section)
        if let header = view as? BetRecordHeader{
            header.title.text = s?.header?.title
            let id = s?.header?.orderId
            header.btn.touchUpInside = {[weak self] in
                let event:BaseController.Event = .copy(id)
                self?.routerEvent(event)
            }
        }else if let footer = view as? BetRecordFooter{
            footer.betMoney.attributedText = s?.footer?.betMoney
            footer.odds.attributedText = s?.footer?.odds
            footer.winMoney.attributedText = s?.footer?.winMoney
            footer.time.text = s?.footer?.time
            if let name = s?.footer?.state{
                footer.state.image = UIImage(named:name)
            }else{
                footer.state.image = nil
            }
        }
        return view
    }
}

extension BetRecordCollection{
    class Section{
        class Header {
            var title:String?
            var userId:String?
            var orderId:String?
        }
        class Footer {
            var betMoney:NSAttributedString?
            var odds:NSAttributedString?
            var winMoney:NSAttributedString?
            var time:String?
            var state:String?
        }
        
        class Cell {
            var teamLogo:String?
            var oddName:String?
            var playName:String?
            var teamName:String?
            var time:String?
            var stateImage:String?
        }
        
        var header:Header?
        var footer:Footer?
        var cells:[Cell]?
    }
}
