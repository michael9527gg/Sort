//
//  BetRecordHeader.swift
//  ECGame
//
//  Created by Michale on 2019/12/9.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BetRecordHeader: UICollectionReusableView {
    let title = UILabel()
    let btn = TransactionDefaultCell.CopyButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Medium", size:14.scale)
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(21.scale)
            make.centerY.equalToSuperview()
        }
        
    
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-20.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
