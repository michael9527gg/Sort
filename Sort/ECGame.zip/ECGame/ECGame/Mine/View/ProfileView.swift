//
//  ProfileView.swift
//  ECGame
//
//  Created by Michale on 2019/12/10.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class ProfileView: UIScrollView {
    enum Event {
        case save
    }
    
    let realName = Row()
    let nickName = Row()
    let sex = Sex()
    let birthDay = BirthDay()
    let idNumber = Row()
    let address = Row()
    let qq = Row()
    let email = Row()
    let btn = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        keyboardDismissMode = .onDrag
        backgroundColor = .navigatonBar
        let vSpace = 12.scale
        
        realName.image.isHidden = false
        realName.setPlaceholder(str: "需和绑定银行卡的持卡人姓名一致")
        realName.textField.delegate = self
        realName.textField.returnKeyType = .next
        realName.updateState = {(text)  in
            if text == nil || text!.count == 0{
                return .default("真实姓名")
            }
            if text!.count < 2{
                return .error("至少2个字符")
            }
            return .pass("真实姓名")
        }
        addSubview(realName)
        realName.snp.makeConstraints { (make) in
            let leading  = 15.scale
            make.width.equalToSuperview().offset(-2 * leading)
            make.leading.equalToSuperview().offset(leading)
            make.centerX.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(20.scale)
        }
        
        
        nickName.setPlaceholder(str: "请输入昵称")
        nickName.textField.delegate = self
        nickName.textField.returnKeyType = .next
        nickName.updateState = {(text)  in
            return .default("昵称")
        }
        addSubview(nickName)
        nickName.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(realName.snp.bottom).offset(vSpace)
        }
        
        
        addSubview(sex)
        sex.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(nickName.snp.bottom).offset(vSpace)
        }
        
        birthDay.textField.delegate = self
        addSubview(birthDay)
        birthDay.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(sex.snp.bottom).offset(vSpace)
        }
        
        idNumber.setPlaceholder(str: "请输入您的身份证号码")
        idNumber.textField.delegate = self
        idNumber.textField.returnKeyType = .next
        idNumber.updateState = {(text)  in
            return .default("身份证号")
        }
        addSubview(idNumber)
        idNumber.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(birthDay.snp.bottom).offset(vSpace)
        }
        
//        city.setPlaceholder(str: "请输入您所在城市")
//        city.textField.delegate = self
//        city.textField.returnKeyType = .next
//        city.updateState = {(text)  in
//            return .default("所在城市")
//        }
//        addSubview(city)
//        city.snp.makeConstraints { (make) in
//            make.left.right.equalTo(realName)
//            make.top.equalTo(idNumber.snp.bottom).offset(vSpace)
//        }
        
        address.setPlaceholder(str: "请输入您的地址")
        address.textField.delegate = self
        address.textField.returnKeyType = .next
        address.updateState = {(text)  in
            return .default("地址")
        }
        addSubview(address)
        address.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(idNumber.snp.bottom).offset(vSpace)
        }
        
        
        qq.setPlaceholder(str: "请输入您的QQ")
        qq.textField.delegate = self
        qq.textField.keyboardType = .numberPad
        qq.textField.returnKeyType = .next
        qq.updateState = {(text)  in
            return .default("QQ")
        }
        addSubview(qq)
        qq.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(address.snp.bottom).offset(vSpace)
        }
        
        email.setPlaceholder(str: "请输入您的邮箱")
        email.textField.delegate = self
        email.textField.returnKeyType = .done
        email.updateState = {(text)  in
            return .default("邮箱")
        }
        addSubview(email)
        email.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(qq.snp.bottom).offset(vSpace)
        }
        
        let icon = UIImageView()
        icon.backgroundColor = .clear
        icon.image = UIImage(named: "icon_not_null")
        icon.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        addSubview(icon)
        icon.snp.makeConstraints { (make) in
            make.leading.equalTo(realName)
            make.top.equalTo(email.snp.bottom).offset(20.scale)
        }
        
        let note = UILabel()
        note.backgroundColor = .clear
        note.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        note.textColor = .note
        note.text = "标记星号为必填项目"
        addSubview(note)
        note.snp.makeConstraints { (make) in
            make.centerY.equalTo(icon)
            make.leading.equalTo(icon.snp.trailing).offset(5.scale)
            make.trailing.equalTo(realName)
        }
        
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        btn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("保存", for: .normal)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 4.scale
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(realName)
            make.top.equalTo(note.snp.bottom).offset(35.scale)
            make.height.equalTo(52.scale)
            make.bottom.equalToSuperview().offset(-30.scale)
        }
    }
    
    @objc func btnClick()->Void{
        let event:Event = .save
        next?.routerEvent(event)
    }
    
    override func routerEvent(_ event: Any) {
        if case .valueChanged? = event as? InputRowView.Event{
            check()
            return
        }
        next?.routerEvent(event)
    }
    
    @discardableResult
    func check() -> Bool {
        if realName.textField.isEnabled == false{
            btn.isEnabled = true
        }else{
            if case .pass? = realName.currentState{
               btn.isEnabled = true
            }else{
                btn.isEnabled = false
            }
        }
        
        return btn.isEnabled
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension ProfileView:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case realName.textField:
            _ = nickName.textField.becomeFirstResponder()
        case nickName.textField:
            _ = birthDay.textField.becomeFirstResponder()
        case birthDay.textField:
            idNumber.textField.becomeFirstResponder()
        case idNumber.textField:
            address.textField.becomeFirstResponder()
//        case city.textField:
//            address.textField.becomeFirstResponder()
        case address.textField:
            qq.textField.becomeFirstResponder()
        case qq.textField:
            email.textField.becomeFirstResponder()
        case email.textField:
            if !check(){
                endEditing(true)
            }else{
                btnClick()
            }
        default:
            break
        }
        return true
    }
}

extension ProfileView{
    class Row: InputRowView {
        let image = UIImageView()
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            image.backgroundColor = .clear
            image.isHidden = true
            image.image = UIImage(named:"icon_not_null")
            addSubview(image)
            image.snp.makeConstraints { (make) in
                make.centerY.equalTo(title)
                make.leading.equalTo(title.snp.trailing).offset(6.scale)
            }
            textField.textColor = .white
            UITextField.appearance().tintColor = .white
            normalTitleColor = .white
            normalLineColor = .line
            placeHolderColor = .placeHolder
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class Sex: UIView {
        private var _sex:MUser.Sex?
        var sex:MUser.Sex?{
            get{
                return _sex
            }
            set{
                _sex = newValue
                boy.isSelected = false
                girl.isSelected = false
                switch newValue {
                case .boy?:
                    boy.isSelected = true
                case .girl?:
                    girl.isSelected = true
                default:
                    break
                }
            }
        }
        
        let boy = Button()
        let girl = Button()
        
        class Button: UIButton {
            override init(frame: CGRect) {
                super.init(frame: frame)
                backgroundColor = .clear
                imageEdgeInsets = UIEdgeInsets(top: 0, left:0, bottom: 0, right:10.scale)
                setTitleColor(.placeHolder, for: .normal)
                setImage(UIImage(named: "system-circle"), for: .normal)
                setImage(UIImage(named: "system-circle-picked"), for: .selected)
            }
            
            override var intrinsicContentSize: CGSize{
                let s = super.intrinsicContentSize
                return CGSize(width:s.width + 10.scale, height: s.height)
            }
            
            required init?(coder aDecoder: NSCoder) {
                fatalError("init(coder:) has not been implemented")
            }
        }
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            let title = UILabel()
            title.text = "性别"
            title.textColor = .white
            title.backgroundColor = .clear
            title.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.top.leading.equalToSuperview()
            }
            
            var t:MUser.Sex = .boy
            boy.tag = t.rawValue
            boy.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
            boy.setTitle("男", for: .normal)
            addSubview(boy)
            boy.snp.makeConstraints { (make) in
                make.leading.equalToSuperview()
                make.bottom.equalToSuperview().offset(-10.scale)
            }
            
            t = .girl
            girl.tag = t.rawValue
            girl.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
            girl.setTitle("女", for: .normal)
            addSubview(girl)
            girl.snp.makeConstraints { (make) in
                make.centerY.equalTo(boy)
                make.leading.equalTo(boy.snp.trailing).offset(25.scale)
            }
        }
        
        @objc func btnClick(sender:Button) ->Void{
            sex = MUser.Sex(rawValue: sender.tag)
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height:65.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}

extension ProfileView{
    class BirthDay: Row {
        class TextField: UITextField {            
            override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
                return false
            }
        }
        
        override var textFiledClass: UITextField.Type{
            return TextField.self
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            setPlaceholder(str: "YYYY / MM / DD")
            textField.keyboardType = .numberPad
            textField.returnKeyType = .next
            updateState = {[weak self] (text)  in
                switch text?.count {
                case 4,9:
                    self?.textField.text = text! + " / "
                case 5:
                    self?.textField.text = String(text!.prefix(4)) + " / \(text!.last!)"
                case 6:
                    self?.textField.text = String(text!.prefix(4))
                case 10:
                    self?.textField.text = String(text!.prefix(9)) + " / \(text!.last!)"
                case 11:
                    self?.textField.text = String(text!.prefix(9))
                default:
                    break
                }
                
                if (text?.count ?? 0) > 14{
                    self?.textField.text = String(text!.prefix(14))
                }
                
                return .default("生日")
            }
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
