//
//  SettingCollectionCell.swift
//  ECGame
//
//  Created by Michale on 2019/10/18.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class SettingCell: UICollectionViewCell {
    let title = UILabel()
    let content = UILabel()
    let modify = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Medium", size: 18.scale)
        title.textAlignment = .left
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(15.scale)
            make.leading.equalToSuperview()
        }
        
        content.backgroundColor = .clear
        content.textColor = .marchName
        content.font = UIFont(name: "PingFangSC-Medium", size: 16.scale)
        content.textAlignment = .left
        contentView.addSubview(content)
        content.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(16.scale)
        }
        
        modify.backgroundColor = .clear
        modify.textColor = .tintColor
        modify.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        modify.textAlignment = .right
        contentView.addSubview(modify)
        modify.snp.makeConstraints { (make) in
            make.centerY.equalTo(content)
            make.trailing.equalToSuperview()
        }
        
        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.height.equalTo(1)
            make.bottom.equalToSuperview().offset(-1)
            make.leading.equalTo(title)
            make.trailing.equalTo(modify)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
