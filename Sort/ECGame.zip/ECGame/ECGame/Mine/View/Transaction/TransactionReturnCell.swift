//
//  TransactionRecordReturnCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol TransactionReturnCellProtocol {
    var orderId:String?{
        get
    }
    var nameText:String?{
        get
    }
    var priceText:String?{
        get
    }
    var betMoneyText:String?{
        get
    }
    var betCountText:String?{
        get
    }
    var betTimeText:String?{
        get
    }
    var sendTimeText:String?{
        get
    }
}

class TransactionReturnCell: UICollectionViewCell {
    
    let name     = UILabel()
    let price    = UILabel()
    let betMoney = Lable()
    let betCount = Lable()
    let betTime  = Lable()
    let sendTime = Lable()
    let btn      = TransactionDefaultCell.CopyButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        
        name.backgroundColor = .clear
        name.textColor = .white
        name.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
//        name.text = "返水比例1%"
        name.textAlignment = .left
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(16.scale)
            make.top.equalToSuperview().offset(10.scale)
        }
        
        price.font = UIFont(name: "DIN-Regular", size: 16.scale)
        price.backgroundColor = .clear
        price.textColor = .white
        price.textAlignment = .right
//        price.text = "¥ 2000.00"
        contentView.addSubview(price)
        price.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-16.scale)
            make.centerY.equalTo(name)
        }
        
//        betMoney.text = "投注总额¥2000"
        contentView.addSubview(betMoney)
        betMoney.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(price.snp.bottom).offset(5.scale)
        }
        
//        betCount.text = "投注比数:5比"
        contentView.addSubview(betCount)
        betCount.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(betMoney.snp.bottom).offset(5.scale)
        }
        
//        betTime.text = "投注时间¥2000"
        contentView.addSubview(betTime)
        betTime.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(betCount.snp.bottom).offset(5.scale)
        }
        
//        sendTime.text = "派发时间 今天 16:20"
        contentView.addSubview(sendTime)
        sendTime.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(betTime.snp.bottom).offset(5.scale)
        }
        
        
        contentView.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.trailing.equalTo(price)
            make.centerY.equalTo(sendTime)
        }
        
        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.trailing.equalTo(price)
            make.bottom.equalToSuperview().offset(-1)
            make.height.equalTo(1)
        }
    }
    
    func updateUI(delegate:TransactionReturnCellProtocol?) -> Void {
        name.text = delegate?.nameText
        price.text = delegate?.priceText
        betMoney.text = delegate?.betMoneyText
        betCount.text = delegate?.betCountText
        betTime.text = delegate?.betTimeText
        sendTime.text = delegate?.sendTimeText
        let id = delegate?.orderId
        btn.touchUpInside = {[weak self] in
            let event:BaseController.Event = .copy(id)
            self?.routerEvent(event)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static var cellHeight:CGFloat{
        return 134.scale
    }
}

extension TransactionReturnCell{
    class Lable: UILabel {
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
            textColor = .marchName
            textAlignment = .left
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
