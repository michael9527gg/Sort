//
//  TransactionRecordSegement.swift
//  ECGame
//
//  Created by Michale on 2019/10/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class TransactionSegement: UISegmentedControl {
    
    let botomLine = UIView(frame: .zero)
    
    override init(items: [Any]?) {
        super.init(items: items)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        tintColor = .clear
        
        let normalTextColor:UIColor = .marchName
        let normalTextFont = UIFont(name: "PingFangSC-Regular", size: 14.scale)!
        
        setTitleTextAttributes([NSAttributedString.Key.foregroundColor :normalTextColor,NSAttributedString.Key.font:normalTextFont], for: .normal)
        
        let selectedColor = UIColor.white
        let selectedFont = UIFont(name: "PingFangSC-Medium", size: 14.scale)!
        setTitleTextAttributes([NSAttributedString.Key.foregroundColor :selectedColor,NSAttributedString.Key.font:selectedFont], for: .selected)
        
        botomLine.backgroundColor = .tintColor
        addSubview(botomLine)
        
        addObserver(self, forKeyPath: "selectedSegmentIndex", options: NSKeyValueObservingOptions.new, context: nil)
    }
  
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "selectedSegmentIndex" {
            updateLine()
        }
    }
    
    deinit {
        removeObserver(self, forKeyPath: "selectedSegmentIndex")
    }
    
    
    func updateLine() -> Void {
        var width:CGFloat = 0
        if selectedSegmentIndex != UISegmentedControl.noSegment {
            width = self.frame.size.width/CGFloat(numberOfSegments)
            width *= 3/6.0
        }
        let x = (CGFloat(selectedSegmentIndex*2+1))/(CGFloat)(numberOfSegments*2)
        let centerX =  x * self.frame.size.width
        botomLine.frame = CGRect(x:centerX-width/2, y:self.frame.size.height-3, width:width, height:2)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        bringSubviewToFront(botomLine)
        updateLine()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

