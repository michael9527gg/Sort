//
//  TransactionRecordView.swift
//  ECGame
//
//  Created by Michale on 2019/10/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol TransactionRecordProtocol:class {
    var segementItems:[String]{
        get
    }
    
    func segementValueChanged(index:Int,view:TransactionRecordView) -> Void
}


class TransactionRecordView: UIView {
    
    let collection = TransactionCollectionView()
    let segement = TransactionSegement()
    
    weak var delegate:TransactionRecordProtocol?
    
    func updateSegement() -> Void {
        segement.removeAllSegments()
        
        guard let array = delegate?.segementItems else{
            return
        }
        
        for titile in array.reversed() {
            segement.insertSegment(withTitle: titile, at: 0, animated: false)
        }
    }
    
    @discardableResult
    func setSegementIndex(index:Int) -> Bool {
        if index > segement.numberOfSegments-1 {
            return false
        }
        
        segement.selectedSegmentIndex = index
        valueChange(segement: segement)
        return true
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        segement.addTarget(self, action: #selector(valueChange(segement:)), for: UIControl.Event.valueChanged)
        addSubview(segement)
        segement.snp.makeConstraints { (make) in
            make.top.equalTo(self.snp.topMargin)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
        

        addSubview(collection)
        collection.snp.makeConstraints { (make) in
            make.top.equalTo(segement.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
   
    @objc func valueChange(segement:TransactionSegement) -> Void {
        delegate?.segementValueChanged(index: segement.selectedSegmentIndex, view: self)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
