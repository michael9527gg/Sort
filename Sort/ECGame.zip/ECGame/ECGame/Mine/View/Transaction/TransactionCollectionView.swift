//
//  TransactionRecordCollection.swift
//  ECGame
//
//  Created by Michale on 2019/10/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol TransactionCollectionViewProtocol:class {
    func numberOfItems(section:Int) -> Int
    
    func cellForItem(at indexPath:IndexPath) -> TransactionCollectionView.CellType
}


class TransactionCollectionView: UICollectionView {
    
    weak var csDelegate:TransactionCollectionViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 0
        flow.sectionInset = UIEdgeInsets(top: 10.scale, left:0, bottom: 10.scale, right:0)
        super.init(frame: frame, collectionViewLayout: flow)
        let cells:[CellType] = [.default(nil),.return(nil)]
        for item in cells {
            register(item.cellClass, forCellWithReuseIdentifier: item.reuseId)
        }
        delegate = self
        dataSource = self
        backgroundColor = .clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}



extension TransactionCollectionView:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(section: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = csDelegate!.cellForItem(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:type.reuseId, for: indexPath)
        switch type {
        case let .default(delegate):
            (cell as! TransactionDefaultCell).updateUI(delegate: delegate)
        case let .return(delegate):
            (cell as! TransactionReturnCell).updateUI(delegate: delegate)
        }
        return cell
    }
}

extension TransactionCollectionView:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return csDelegate?.cellForItem(at:indexPath).itemSize ?? .zero
    }
}

extension TransactionCollectionView{
    enum CellType {
        case `default`(_ delegate:TransactionDefaultCellProtocol?)
        case `return`(_  delegate:TransactionReturnCellProtocol?)
        
        var reuseId:String{
            switch self {
            case .default:
                return "d"
            case .return:
                return "r"
            }
        }
        
        var cellClass:UICollectionViewCell.Type{
            switch self {
            case .default:
                return TransactionDefaultCell.self
            case .return:
                return TransactionReturnCell.self
            }
        }
        
        var itemSize:CGSize{
            let w = kScreenWidth
            switch self {
            case .default:
                return CGSize(width:w, height:TransactionDefaultCell.cellHeight)
            case .return:
                return CGSize(width:w, height:TransactionReturnCell.cellHeight)
            }
        }
    }
}
