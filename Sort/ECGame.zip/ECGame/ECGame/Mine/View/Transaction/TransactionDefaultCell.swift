//
//  TransactionRecordCell.swift
//  ECGame
//
//  Created by Michale on 2019/10/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol TransactionDefaultCellProtocol {
    var orderId:String?{
        get
    }
    var nameText:String?{
        get
    }
    var priceText:String?{
        get
    }
    var timeText:String?{
        get
    }
    var stateText:(text:String?,textColor:UIColor?){
        get
    }
}

class TransactionDefaultCell: UICollectionViewCell {
    
    let name    = UILabel()
    let price   = UILabel()
    let time    = UILabel()
    let state   = UILabel()
    let btn     = CopyButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        
        name.backgroundColor = .clear
        name.textColor = .white
        name.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
//        name.text = "银行卡在线支付"
        name.textAlignment = .left
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(16.scale)
            make.top.equalToSuperview().offset(10.scale)
        }
        
        price.font = UIFont(name: "DIN-Regular", size: 16.scale)
        price.backgroundColor = .clear
        price.textColor = .white
        price.textAlignment = .right
//        price.text = "¥ 2000.00"
        contentView.addSubview(price)
        price.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-16.scale)
            make.centerY.equalTo(name)
        }
        
        time.backgroundColor = .clear
        time.textColor = .marchName
        time.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
//        time.text = "今天 16:20"
        time.textAlignment = .left
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(name.snp.bottom).offset(5.scale)
        }
        
        state.backgroundColor = .clear
        state.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        state.textAlignment = .right
        state.textColor = .marchName
        contentView.addSubview(state)
        state.snp.makeConstraints { (make) in
            make.trailing.equalTo(price)
            make.centerY.equalTo(time)
        }

        contentView.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.trailing.equalTo(price)
            make.top.equalTo(state.snp.bottom).offset(8.scale)
        }
        
        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.trailing.equalTo(price)
            make.bottom.equalToSuperview().offset(-1)
            make.height.equalTo(1)
        }
    }
    
    func updateUI(delegate:TransactionDefaultCellProtocol?) -> Void {
        name.text = delegate?.nameText
        price.text = delegate?.priceText
        time.text = delegate?.timeText
        let s = delegate?.stateText
        state.text = s?.text
        state.textColor = s?.textColor
        let id = delegate?.orderId
        btn.touchUpInside = {[weak self] in
            let event:BaseController.Event = .copy(id)
            self?.routerEvent(event)
        }
    }
    
  
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static var cellHeight:CGFloat{
        return 94.scale
    }
}

extension TransactionDefaultCell{
    class CopyButton: UIButton {
        typealias Block = ()->Void
        var touchUpInside:Block?
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            let ck = UIColor.selected
            backgroundColor = .clear
            setTitle("复制订单号", for: .normal)
            titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
            setTitleColor(ck, for:.normal)
            layer.cornerRadius = 2
            addTarget(self, action: #selector(copyOrderId), for: .touchUpInside)
            layer.borderWidth = 0.5
            layer.borderColor = ck.cgColor
            clipsToBounds = true
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width:68.scale, height:22.scale)
        }
        
        @objc func copyOrderId()->Void{
            touchUpInside?()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
