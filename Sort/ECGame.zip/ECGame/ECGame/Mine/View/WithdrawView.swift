//
//  WithDrawView.swift
//  ECGame
//
//  Created by Michale on 2019/12/15.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class WithdrawView: UIView {
    
    enum Event {
        case `switch`
        case all
        case next(String)
    }
    
    let bank = BankRow()
    let banlance = BanlanceRow()
    let input = InputRowView()
    let nextBtn = UIButton()
    let error = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
//        bank.btn.addTarget(self, action: #selector(switchClick), for: .touchUpInside)
        addSubview(bank)
        bank.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(16.scale)
            make.centerX.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(25.scale)
        }
       
        banlance.title.text = "当前余额"
        addSubview(banlance)
        banlance.snp.makeConstraints { (make) in
            make.leading.centerX.equalTo(bank)
            make.top.equalTo(bank.snp.bottom)
        }
        
        UITextField.appearance().tintColor = .loginBtn
        let btn = UIButton(frame: CGRect(origin: .zero, size: CGSize(width:35.scale, height: 30.scale)))
        btn.addTarget(self, action: #selector(allClick), for: .touchUpInside)
        btn.setTitle("全部", for: .normal)
        btn.setTitleColor(.loginBtn, for: .normal)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        input.addSubview(btn)
        input.rightView = btn
        input.textField.keyboardAppearance = .dark
        input.textField.keyboardType = .numberPad
        input.placeHolderColor = .note
        input.textField.delegate = self
        input.textField.textColor = .white
        input.normalLineColor = .line
        input.normalTitleColor = .white
        input.setPlaceholder(str: "请输入")
        input.updateState = {(text) in
            return .default("提现金额")
        }
        addSubview(input)
        input.snp.makeConstraints { (make) in
            make.leading.centerX.equalTo(bank)
            make.top.equalTo(banlance.snp.bottom).offset(25.scale)
        }
        
        let note = UILabel()
        note.backgroundColor = .clear
        note.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        note.textColor = .note
        note.text = "单笔最低提款额100元，最高100,000元"
        addSubview(note)
        note.snp.makeConstraints { (make) in
            make.leading.equalTo(input)
            make.top.equalTo(input.snp.bottom).offset(15.scale)
        }
        
        error.backgroundColor = .clear
        error.textAlignment = .left
        error.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        error.textColor = .error
        addSubview(error)
        error.snp.makeConstraints { (make) in
            make.leading.equalTo(note)
            make.top.equalTo(note.snp.bottom).offset(10.scale)
        }
        
        nextBtn.isEnabled = false
        nextBtn.addTarget(self, action: #selector(nextClick), for: .touchUpInside)
        nextBtn.layer.cornerRadius = 4
        nextBtn.clipsToBounds = true
        nextBtn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        nextBtn.backgroundColor = .clear
        nextBtn.setTitle("下一步", for: .normal)
        nextBtn.setTitleColor(.white, for: .normal)
        nextBtn.setTitleColor(.white, for: .disabled)
        nextBtn.setBackgroundImage(UIColor.forgetPwd.image, for: .disabled)
        nextBtn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
        addSubview(nextBtn)
        nextBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(input)
            make.top.equalTo(note.snp.bottom).offset(50.scale)
            make.height.equalTo(52.scale)
        }
    }
    
    override func routerEvent(_ event: Any) {
        error.text = nil
        next?.routerEvent(event)
    }
    
    @objc func nextClick()->Void{
        endEditing(true)
        let event:Event = .next(input.textField.text!)
        routerEvent(event)
    }
    
    @objc func allClick()->Void{
        let event:Event = .all
        routerEvent(event)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension WithdrawView:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        input.normalLineColor = .white
        input.textFieldDidChange()
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        input.normalLineColor = .line
        input.textFieldDidChange()
    }
}

extension WithdrawView{
    class BankRow: UIView {
        let icon = UIImageView()
        let title = UILabel()
        let type = UILabel()
        let btn = UIButton()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            
//            icon.image = UIImage(named: "img_nologo")
            icon.backgroundColor = .clear
            addSubview(icon)
            icon.snp.makeConstraints { (make) in
                make.leading.equalToSuperview()
                make.top.equalToSuperview().offset(5.scale)
                let w = 40.scale
                make.size.equalTo(CGSize(width: w, height: w))
            }
            
            title.font = UIFont(name: "PingFangSC-Medium", size:18.scale)
            title.backgroundColor = .clear
            title.textColor = .white
//            title.text = "工商银行"
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.top.equalToSuperview()
                make.leading.equalTo(icon.snp.trailing).offset(15.scale)
            }
            
            
            type.backgroundColor = .clear
            type.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            type.textColor = .note
//            type.text = "尾号3300 借记卡"
            addSubview(type)
            type.snp.makeConstraints { (make) in
                make.leading.equalTo(title)
                make.top.equalTo(title.snp.bottom).offset(5.scale)
            }
            
          
            btn.isUserInteractionEnabled = false
            btn.setTitle("切换 >", for:.normal)
            btn.setTitleColor(.note, for:.normal)
            btn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            addSubview(btn)
            btn.snp.makeConstraints { (make) in
                make.trailing.equalToSuperview()
                make.centerY.equalTo(icon)
            }
            
            
            let line = UIView()
            line.backgroundColor = .line
            addSubview(line)
            line.snp.makeConstraints { (make) in
                make.bottom.leading.trailing.equalToSuperview()
                make.height.equalTo(1)
            }
        }
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            super.touchesBegan(touches, with: event)
            let event:WithdrawView.Event = .switch
            routerEvent(event)
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width:UIView.noIntrinsicMetric, height:66.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class BanlanceRow: UIView {
        let title = UILabel()
        let price = UILabel()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            
            title.backgroundColor = .clear
            title.textColor = .white
            title.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.centerY.leading.equalToSuperview()
            }
            
            price.backgroundColor = .clear
            price.textColor = .white
            price.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
            addSubview(price)
            price.snp.makeConstraints { (make) in
                make.centerY.trailing.equalToSuperview()
            }
            
            let line = UIView()
            line.backgroundColor = .line
            addSubview(line)
            line.snp.makeConstraints { (make) in
                make.bottom.leading.trailing.equalToSuperview()
                make.height.equalTo(1)
            }
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width:UIView.noIntrinsicMetric, height:52.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
