//
//  PickerBankView.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol PickerUserBankViewProtocol:class {
    func numberOfItems(in section:Int) -> Int
    func config(cell:PickerUserBankCell, indexPath:IndexPath) ->Void
    func didSelect(at indexPath:IndexPath) -> Void
}

private let reuseId = "id"

class PickerUserBankView: UICollectionView {
    
    weak var csDelegate:PickerUserBankViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.sectionHeadersPinToVisibleBounds = true
        flow.footerReferenceSize = CGSize(width: kScreenWidth, height: 70.scale)
        flow.headerReferenceSize = CGSize(width: kScreenWidth, height: 50.scale)
        flow.itemSize = CGSize(width:kScreenWidth, height:70.scale)
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 0
        super.init(frame: frame, collectionViewLayout: flow)
        register(PickerUserBankCell.self,forCellWithReuseIdentifier:reuseId)
        register(PickerUserBankFooter.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: reuseId)
        register(PickerUserBankHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: reuseId)
        delegate = self
        dataSource = self
        backgroundColor = .navigatonBar
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension PickerUserBankView:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier:reuseId, for: indexPath) as! PickerUserBankCell
        csDelegate?.config(cell: cell, indexPath: indexPath)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        csDelegate?.didSelect(at: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let view = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: reuseId, for: indexPath)
        return view
    }
}
