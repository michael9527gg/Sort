//
//  PickerBankHeader.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class PickerUserBankHeader: UICollectionReusableView {
    enum Event {
        case close
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
        let btn = UIButton()
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.setBackgroundImage(UIImage(named: "system-cancel-bold"), for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
        }
        
        let title = UILabel()
        title.text = "选择收款银行卡"
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
        title.textAlignment = .center
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
    }
    
    @objc func btnClick()->Void{
        let event:Event = .close
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
