//
//  PickerBankFooter.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class PickerUserBankFooter: UICollectionReusableView {
    enum Event {
        case add
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        let icon = UIImageView()
        icon.image = UIImage(named: "icon_add_bankcard_grey")
        icon.backgroundColor = .clear
        addSubview(icon)
        icon.snp.makeConstraints { (make) in
            let w = 40.scale
            make.size.equalTo(CGSize(width: w, height: w))
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
        }
        
        let subTitle = UILabel()
        subTitle.text = "新的收款银行卡"
        subTitle.backgroundColor = .clear
        subTitle.textColor = .marchName
        subTitle.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        subTitle.textAlignment = .left
        addSubview(subTitle)
        subTitle.snp.makeConstraints { (make) in
            make.centerY.equalTo(icon)
            make.leading.equalTo(icon.snp.trailing).offset(20.scale)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        let event:Event = .add
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
