//
//  PickerBankCell.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class PickerUserBankCell: UICollectionViewCell {
    let icon = UIImageView()
    let name = UILabel()
    let subTitle = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        icon.backgroundColor = .clear
        contentView.addSubview(icon)
        icon.snp.makeConstraints { (make) in
            let w = 40.scale
            make.size.equalTo(CGSize(width: w, height: w))
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
        }
        
        name.backgroundColor = .clear
        name.textColor = .white
        name.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
        name.textAlignment = .left
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.top.equalTo(icon)
            make.leading.equalTo(icon.snp.trailing).offset(20.scale)
        }

        subTitle.backgroundColor = .clear
        subTitle.textColor = .marchName
        subTitle.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        subTitle.textAlignment = .left
        contentView.addSubview(subTitle)
        subTitle.snp.makeConstraints { (make) in
            make.leading.equalTo(name)
            make.top.equalTo(name.snp.bottom).offset(6.scale)
        }

        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.height.equalTo(1)
            make.bottom.equalToSuperview().offset(-1)
            make.leading.equalTo(icon)
            make.centerX.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
