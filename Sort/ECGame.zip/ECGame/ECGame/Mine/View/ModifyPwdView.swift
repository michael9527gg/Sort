//
//  ModifyPwdView.swift
//  ECGame
//
//  Created by Michale on 2019/10/18.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit



class ModifyPwdView: UIView {
    
    enum Event {
        case save(oldPwd:String,newPwd:String)
    }
 
    
    let oldPwd  = InputRowView()
    let newPwd1 = InputRowView()
    let newPwd2 = InputRowView()
    let loginBtn = NameLoginView.NextButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
        UITextField.appearance().tintColor = .white
        oldPwd.normalTitleColor = .white
        oldPwd.normalLineColor = .line
        oldPwd.placeHolderColor = .placeHolder
        oldPwd.textField.textColor = .white
        oldPwd.setPlaceholder(str: "请输入")
        oldPwd.textField.returnKeyType = .next
        oldPwd.textField.isSecureTextEntry = true
        oldPwd.textField.delegate = self
        oldPwd.textField.clearButtonMode = .whileEditing
        oldPwd.updateState = {(text)  in
            if text == nil || text!.count == 0{
                return .default("登陆密码")
            }
            if text!.count < 6 {
                return .error("至少6位")
            }
            if text!.count > 16 {
                return .error("最多16位")
            }
            if text!.evaluate(pwdFormat) == false{
                return .error("不能包含特殊字符")
            }
            return .pass("登陆密码")
        }
        addSubview(oldPwd)
        oldPwd.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
            make.topMargin.equalToSuperview().offset(20.scale)
        }

       
        newPwd1.normalTitleColor = .white
        newPwd1.normalLineColor = .line
        newPwd1.placeHolderColor = .placeHolder
        newPwd1.textField.textColor = .white
        newPwd1.setPlaceholder(str: "6-16位英文或数字")
        newPwd1.textField.delegate = self
        newPwd1.textField.returnKeyType = .next
        newPwd1.textField.isSecureTextEntry = true
        newPwd1.textField.clearButtonMode = .whileEditing
        newPwd1.updateState = {[weak self] (text)  in
            if text == nil || text!.count == 0{
            return .default("新密码")
            }
            if text!.count < 6 {
                return .error("至少6位")
            }
            if text!.count > 16 {
                return .error("最多16位")
            }
            if text!.evaluate(pwdFormat) == false{
                return .error("不能包含特殊字符")
            }
            
            if case .pass? = self?.newPwd2.currentState,let other = self?.newPwd2.textField.text, text! != other{
                return .error("两次密码不一致")
            }
            if text! == self?.newPwd2.textField.text {
                self?.newPwd2.currentState = .pass("确认新密码")
            }
            
            return .pass("新密码")
        }
        addSubview(newPwd1)
        newPwd1.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalTo(oldPwd)
            make.top.equalTo(oldPwd.snp.bottom).offset(10.scale)
        }
        
        newPwd2.normalTitleColor = .white
        newPwd2.normalLineColor = .line
        newPwd2.placeHolderColor = .placeHolder
        newPwd2.textField.textColor = .white
        newPwd2.setPlaceholder(str: "请再次输入")
        newPwd2.textField.delegate = self
        newPwd2.textField.returnKeyType = .done
        newPwd2.textField.isSecureTextEntry = true
        newPwd2.textField.clearButtonMode = .whileEditing
        newPwd2.updateState = {[weak self] (text)  in
            if text == nil || text!.count == 0{
                return .default("确认新密码")
            }
            if text!.count < 6 {
                return .error("至少6位")
            }
            if text!.count > 16 {
                return .error("最多16位")
            }
            if text!.evaluate(pwdFormat) == false{
                return .error("不能包含特殊字符")
            }
            
            if case .pass? = self?.newPwd1.currentState,let other = self?.newPwd1.textField.text, text! != other{
                return .error("两次密码不一致")
            }
            
            if text! == self?.newPwd1.textField.text {
                self?.newPwd1.currentState = .pass("新密码")
            }
            
            return .pass("确认新密码")
        }
        addSubview(newPwd2)
        newPwd2.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalTo(oldPwd)
            make.top.equalTo(newPwd1.snp.bottom).offset(10.scale)
        }
        
        let note = UILabel()
        note.backgroundColor = .clear
        note.textColor = .disabled
        note.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        note.text = "密码至少6-16位数字及字母组合"
        addSubview(note)
        note.snp.makeConstraints { (make) in
            make.leading.equalTo(newPwd2)
            make.top.equalTo(newPwd2.snp.bottom).offset(15.scale)
        }
        
        
        
        loginBtn.setTitle("提交", for: .normal)
        loginBtn.setBackgroundImage(UIColor.inactivate.image, for: .disabled)
        loginBtn.setTitleColor(.note, for: .disabled)
        loginBtn.isEnabled = false
        loginBtn.addTarget(self, action: #selector(save), for: .touchUpInside)
        addSubview(loginBtn)
        loginBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(self.snp.bottomMargin)
            make.height.equalTo(52.scale)
        }
        
    }
    
  
    @objc func save() -> Void {
        endEditing(true)
        let result:Event = .save(oldPwd:oldPwd.textField.text!, newPwd: newPwd1.textField.text!)
        next?.routerEvent(result)
    }
    
    override func routerEvent(_ event: Any) {
        if case .valueChanged? = event as? InputRowView.Event{
            check()
            return
        }
        next?.routerEvent(event)
    }
    
    @discardableResult
    private func check()->Bool{
        if case .pass? = oldPwd.currentState,case .pass? = newPwd1.currentState,case .pass? = newPwd2.currentState{
            loginBtn.isEnabled = true
        }else{
             loginBtn.isEnabled = false
        }
        return loginBtn.isEnabled
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        endEditing(true)
        super.touchesBegan(touches, with: event)
    }
    
}


extension ModifyPwdView:UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case oldPwd.textField:
            _ = newPwd1.textField.becomeFirstResponder()
        case newPwd1.textField:
            _ = newPwd2.textField.becomeFirstResponder()
        case newPwd2.textField:
            if check(){
                save()
            }else{
                endEditing(true)
            }
        default:
            break
        }
        return true
    }
}
