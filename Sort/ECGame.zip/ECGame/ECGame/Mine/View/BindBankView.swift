//
//  AddBankView.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BindBankView: UIScrollView {
    
    enum Event {
        case bind(bankId:String,branchName:String)
    }
    
    let realName = Row()
    let idCard = BankIdView()
    let bankName = BankNameView()
    let branchName  = Row()
    let btn = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        keyboardDismissMode = .onDrag
        backgroundColor = .navigatonBar
        let vSpace = 12.scale
        
        realName.setPlaceholder(str: "需和绑定银行卡的持卡人姓名一致")
        realName.textField.delegate = self
        realName.textField.returnKeyType = .next
        realName.updateState = {(text)  in
            return .default("持卡人")
        }
        addSubview(realName)
        realName.snp.makeConstraints { (make) in
            let leading  = 15.scale
            make.width.equalToSuperview().offset(-2 * leading)
            make.leading.equalToSuperview().offset(leading)
            make.centerX.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(20.scale)
        }
        
       
        idCard.textField.delegate = self
        addSubview(idCard)
        idCard.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(realName.snp.bottom).offset(vSpace)
        }
        
        bankName.setPlaceholder(str: "请选择")
        bankName.textField.delegate = self
        bankName.textField.returnKeyType = .done
        bankName.updateState = {(text)  in
            return .default("银行名称")
        }
        addSubview(bankName)
        bankName.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(idCard.snp.bottom).offset(vSpace)
        }
        
        branchName.setPlaceholder(str: "请输入")
        branchName.textField.delegate = self
        branchName.textField.returnKeyType = .next
        branchName.updateState = {(text)  in
            if text == nil || text!.count == 0 {
                return .default("开户网点")
            }
            return .pass("开户网点")
        }
        addSubview(branchName)
        branchName.snp.makeConstraints { (make) in
            make.left.right.equalTo(realName)
            make.top.equalTo(bankName.snp.bottom).offset(vSpace)
        }
        
        btn.isEnabled = false
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        btn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("立即绑定", for: .normal)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 4.scale
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(realName)
            make.top.equalTo(branchName.snp.bottom).offset(35.scale)
            make.height.equalTo(52.scale)
            make.bottom.equalToSuperview().offset(-30.scale)
        }
    }
    
    @objc func btnClick(){
        endEditing(true)
        let id = idCard.textField.text?.replacingOccurrences(of:" ", with: "") ?? ""
        let event:Event = .bind(bankId:id, branchName: branchName.textField.text ?? "")
        routerEvent(event)
    }
    
    @discardableResult
    func check() -> Bool {
        if case .pass? = idCard.currentState,
           case .pass? = branchName.currentState,
           (bankName.textField.text?.count ?? 0) > 0{
            btn.isEnabled = true
        }else{
            btn.isEnabled = false
        }
        return btn.isEnabled
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    override func routerEvent(_ event: Any) {
        if case .valueChanged? = event as? InputRowView.Event{
            check()
            return
        }
        next?.routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension BindBankView:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case realName.textField:
            idCard.textField.becomeFirstResponder()
        case idCard.textField:
            branchName.textField.becomeFirstResponder()
        case branchName.textField:
            if check(){
                btnClick()
            }else{
                endEditing(true)
            }
        default:
            break
        }
        return true
    }
}

extension BindBankView{
    class Row: InputRowView {
        override init(frame: CGRect) {
            super.init(frame: frame)
            textField.textColor = .white
            UITextField.appearance().tintColor = .white
            normalTitleColor = .white
            normalLineColor = .line
            placeHolderColor = .placeHolder
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class BankIdView: Row {
        private func bank(text:String?) ->String?{
            guard let t = text else {
                return nil
            }
            var str = t.replacingOccurrences(of:" ", with:"")
            let end = str.count/4
            for i in 0 ..< end {
                let index = str.index(str.startIndex, offsetBy:(i+1)*4+i)
                str.insert(" ", at: index)
            }
            if str.last == " "{
               _ = str.popLast()
            }
            return str
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            setPlaceholder(str: "0000 0000 0000 0000")
            textField.keyboardType = .numberPad
            textField.keyboardAppearance = .dark
            textField.returnKeyType = .next
            updateState = {[weak self] (text)  in
                if text == nil || text?.count == 0{
                    return .default("卡号")
                }
                let t = self?.bank(text:text)
                self?.textField.text = t
                if t!.count < 14 {
                    return .error("请输入完整")
                }else if t!.count > 24{
                    self?.textField.text = String(t!.prefix(24))
                }
                return .pass("卡号")
            }
        }
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class BankNameView: Row {
        enum Action {
            case tap
        }
        override init(frame: CGRect) {
            super.init(frame: frame)
            textField.isEnabled = false
        }
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            super.touchesBegan(touches, with: event)
            let event:Action = .tap
            routerEvent(event)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
