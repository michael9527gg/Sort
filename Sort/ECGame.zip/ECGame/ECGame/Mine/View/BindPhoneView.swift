//
//  BindPhoneView.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BindPhoneView: UIView {
    
    enum Event {
        case bind(mobile:String)
    }
    
    let phone = PhoneLoginView.PhoneNumberView()
    let btn = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .navigatonBar
        
        phone.textField.textColor = .white
        UITextField.appearance().tintColor = .white
        phone.normalTitleColor = .white
        phone.placeHolderColor = .placeHolder
        phone.normalLineColor = .line
        phone.textFieldDidChange()
        addSubview(phone)
        phone.snp.makeConstraints { (make) in
            let leading  = 16.scale
            make.leading.equalToSuperview().offset(leading)
            make.centerX.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(20.scale)
        }
        
        btn.isEnabled = false
        btn.backgroundColor = .clear
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        btn.setBackgroundImage(UIColor.tintColor.image, for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.addTarget(self, action:#selector(btnClick), for: .touchUpInside)
        btn.setTitle("立即绑定", for: .normal)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 4.scale
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(phone)
            make.top.equalTo(phone.snp.bottom).offset(35.scale)
            make.height.equalTo(52.scale)
        }
    }
    
    @objc func btnClick()->Void{
        let event:Event = .bind(mobile: phone.phone ?? "")
        routerEvent(event)
    }
    
    override func routerEvent(_ event: Any) {
        if case .valueChanged? = event as? InputRowView.Event{
            check()
            return
        }
        
        next?.routerEvent(event)
    }
    
    @discardableResult
    func check() -> Bool {
        if case .pass? = phone.currentState{
            btn.isEnabled = true
        }else{
            btn.isEnabled = false
        }
        return btn.isEnabled
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
