//
//  PickerBankController.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class PickerBankController: BaseController {
    typealias Complete = (`Type`)->Void
    enum `Type` {
        case canceld
        case selected(MBank)
    }
    private let vm    = VMPickerBank()
    private let bottom = PickerBankView()
    private var complete:Complete?
    
    class func show(ctr:UIViewController,complete:Complete?) -> Void {
        let picker = PickerBankController()
        picker.complete = complete
        ctr.present(picker, animated:true, completion:nil)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle:nibBundleOrNil)
        modalPresentationStyle = .custom
        modalTransitionStyle = .crossDissolve
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .init(red: 0, green: 0, blue: 0, alpha: 0.4)
        view.addSubview(bottom)
        bottom.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(view.snp.bottomMargin)
            make.height.equalTo(330.scale)
        }
        bottom.csDelegate = vm
        vm.delegate = self
        vm.bankList {[weak self] (success) in
            if success{
                self?.bottom.reloadData()
            }
        }
    }
    
    override func routerEvent(_ event: Any) {
        if case .close? = event as? PickerUserBankHeader.Event{
            dismiss(animated: true) {
                self.complete?(.canceld)
            }
            return
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension PickerBankController:VMPickerBankProtocol{
    func didSelect(bank: MBank) {
        dismiss(animated: true) {
            self.complete?(.selected(bank))
        }
    }
}
