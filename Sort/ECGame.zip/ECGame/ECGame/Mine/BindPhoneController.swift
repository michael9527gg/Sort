//
//  BindPhoneController.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BindPhoneController: BaseController {
    let ctView = BindPhoneView()
    let vm = VMBindPhone()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "绑定手机号"
        setBackButton()
    }
    
    override func routerEvent(_ event: Any) {
        if case let .bind(mobile)? = event as? BindPhoneView.Event{
            bind(mobile: mobile)
        }
    }
    
    func bind(mobile:String) -> Void {
        vm.sendMobileCode(mobile:mobile) {[weak self] (result) in
            switch result{
            case .success:
                let verify = VerifyPhoneController(phone:mobile, done: { (code,failed) in
                    self?.vm.bind(mobile: mobile, code: code, complete:{ (r) in
                        switch r{
                        case .success:
                            self?.bindSuccess()
                        case let .failed(msg):
                            failed?(.error(msg))
                        case let .wrongCode(msg):
                            failed?(.wrongCode(msg))
                        case let .exist(msg):
                            self?.navigationController?.popViewController(animated: true)
                            self?.ctView.phone.currentState = .error(msg)
                            self?.ctView.check()
                        }
                    })
                })
                self?.navigationController?.pushViewController(verify, animated: true)
            case let .notExist(msg):
                self?.ctView.phone.currentState = .error(msg)
                self?.ctView.check()
            case let .failed(msg):
                print("===\(msg)")
            }
        }
    }
    
    func bindSuccess() -> Void {
        navigationController?.popViewController(animated: true)
        let white = WhiteAlertController(title: "手机号绑定成功", message:"下次您可以直接使用手机号登陆啦", buttons:[.default(title: "我知道了", action: {[weak self] in self?.navigationController?.popToRootViewController(animated: true)
        })])
        present(white, animated:true, completion:nil)
    }
    
    override func loadView() {
        view = ctView
    }
    
}
