//
//  MyMessageController.swift
//  ECGame
//
//  Created by Michale on 2019/12/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class MessageListController: BaseController {
    let listView = MessageListView()
    let vm = VMMessageList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的消息"
        setBackButton()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        listView.reloadData()
    }
    
    override func loadView() {
        vm.delegate = self
        view = listView
        listView.csDelegate = vm
        vm.messageList()
    }
}

extension MessageListController:VMMessageListProtocol{
    func didSelect(message id: String) {
        let detail = MessageDetailController(id: id)
        self.navigationController?.pushViewController(detail, animated: true)
    }
    
    func success() {
        listView.reloadData()
    }
}
