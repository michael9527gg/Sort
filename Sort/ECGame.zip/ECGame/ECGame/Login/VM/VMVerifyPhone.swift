//
//  VMVerifyPhone.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import SnapKit

class VMVerifyPhone: VMLoginBase {
    
    func attr(phone:String) -> NSAttributedString {
        let at = NSMutableAttributedString(string:"请输入 \(phone) 收到的验证码", attributes: [NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size: 15.scale)!,NSAttributedString.Key.foregroundColor:UIColor.disabled])
        at.addAttributes([NSAttributedString.Key.font : UIFont(name: "PingFangSC-Medium", size: 16.scale)!,NSAttributedString.Key.foregroundColor:UIColor.black], range: NSRange(location: 4, length: phone.count))
        return at
    }
}
