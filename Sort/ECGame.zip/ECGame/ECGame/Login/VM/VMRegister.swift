//
//  VMRegister.swift
//  ECGame
//
//  Created by Michale on 2019/10/15.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol VMRegisterProtocol:class {
    func userRegisterSuccess() -> Void
    func failed(msg:String) -> Void
    func userExist(msg:String) -> Void
}


class VMRegister: VMLoginBase {
    
    enum RegisterMobileResult {
        case success
        
        /// 手机号已经存在
        case exist(String)
        
        /// 验证码错误
        case wrongCode(String)
        case failed(String)
    }
    
    weak var delegate:VMRegisterProtocol?
    
    func register(name:String,pwd:String,inviteCode:String?) -> Void {
        Member.provider.request(.register(userName: name, pwd:pwd.md5.md5,recommend: inviteCode)) { (_ result:ECResult<MAccessToken>) in
            
            switch result {
            case let .success(at):
                self.saveUser(token: at)
                self.delegate?.userRegisterSuccess()
            case let .failed(code,msg):
                if code == 5{//用户已经存在
                    self.delegate?.userExist(msg: msg)
                    return
                }
                self.delegate?.failed(msg:msg)
            case .unreachable:
                self.delegate?.failed(msg:"无法连接服务器")
            default:
                self.delegate?.failed(msg:"其他错误")
            }
        }
    }
    
    func register(mobile:String,code:String,invite:String?,complete:@escaping (_ result:RegisterMobileResult)->Void) -> Void {
        Member.provider.request(.registerMobile(mobile: mobile, authCode: code, recommend: invite)) { (_ result:ECResult<MAccessToken>) in
            
            switch result{
            case let .success(at):
                self.saveUser(token: at)
                complete(.success)
            case let .failed(code, msg):
                switch code{
                case 31:
                     complete(.exist(msg))
                case 32:
                    complete(.wrongCode(msg))
                default:
                    complete(.failed(msg))
                }
            case .unreachable:
                complete(.failed("网络无法连接"))
            default:
                complete(.failed("其他错误"))
            }
        }
    }
}
