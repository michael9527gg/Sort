//
//  VMScanQRCode.swift
//  ECGame
//
//  Created by Michale on 2019/12/13.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

protocol VMScanQRCodeProtocol:class {
    func success(code:String) -> Void
    func failed(message:String) -> Void
}

class VMScanQRCode: VMBase {
    
    weak var delegate:VMScanQRCodeProtocol?
    
    //输入输出中间桥梁(会话)
    fileprivate lazy var session : AVCaptureSession = AVCaptureSession()
    
    func startRunning(view:ScanQRCodeView) -> Void {
        //1.获取输入设备（摄像头）
        guard let device = AVCaptureDevice.default(for: .video) else { return }
        
        //2.根据输入设备创建输入对象
        guard let deviceInput = try? AVCaptureDeviceInput(device: device) else { return }
        
        //3.创建原数据的输出对象
        let metadataOutput = AVCaptureMetadataOutput()
        
        //4.设置代理监听输出对象输出的数据，在主线程中刷新
        metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        //5.创建会话（桥梁）
        //        let session = AVCaptureSession()
        
        //6.添加输入和输出到会话
        if session.canAddInput(deviceInput) {
            session.addInput(deviceInput)
        }
        if session.canAddOutput(metadataOutput) {
            session.addOutput(metadataOutput)
        }
        
        //7.告诉输出对象要输出什么样的数据(二维码还是条形码),要先创建会话才能设置
        metadataOutput.metadataObjectTypes = [.qr, .code128, .code39, .code93, .code39Mod43, .ean8, .ean13, .upce, .pdf417, .aztec]
        
        DispatchQueue.main.async {
            //8.创建预览图层
            let previewLayer:AVCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: self.session)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = view.bounds
            view.layer.insertSublayer(previewLayer, at: 0)
            
        }
        
        //9.设置有效扫描区域(默认整个屏幕区域)（每个取值0~1, 以屏幕右上角为坐标原点）
//        let area:UIView = view.area
//        let rect = CGRect(x: area.frame.minY / kScreenHeight, y: area.frame.minX / kScreenWidth, width: area.frame.height / kScreenHeight, height: area.frame.width / kScreenWidth)
//        metadataOutput.rectOfInterest = rect
        
        //10. 开始扫描
        session.startRunning()
    }
    
    func parse(source:[String]?) ->String?{
        guard let array = source else {
            return nil
        }
        
        for item in array{
            if let c = URLComponents(string:item),c.url != nil,let fragment = c.fragment,
                fragment.starts(with:"/recommend/"),fragment.count > 11{
                let index = fragment.index(fragment.startIndex, offsetBy:11)
                let invite = String(fragment.suffix(from:index))
                if invite.evaluate(nameFormat){
                    return invite
                }
            }
        }
        return nil
    }
    
}

extension VMScanQRCode:AVCaptureMetadataOutputObjectsDelegate{
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        for object in metadataObjects {
            if object.type == .qr{
                if let readableCode = object as? AVMetadataMachineReadableCodeObject,
                    let string = readableCode.stringValue,let code = parse(source: [string]){
                    session.stopRunning()
                    delegate?.success(code: code)
                }
                delegate?.failed(message: "格式不对")
            }else{
                delegate?.failed(message: "非有效二维码")
            }
        }
    }
}
