//
//  VMLRBase.swift
//  ECGame
//
//  Created by Michale on 2019/10/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class VMLoginBase: VMBase {
    
    enum CodeResult {
        case success
        case failed(String)
    }
    
    enum PhoneResult {
        case success
        /// 手机号无效
        case notExist(String)
        
        case failed(String)
    }
    
    func saveUser(token:MAccessToken) -> Void {
        let user = Account()
        user.token = token
        Account.current = user
    }
    
    func userExist(userId:String,completion:@escaping (_ exist:Bool,_ msg:String)->Void) -> Void {
        Member.provider.request(.userExists(userId:userId)) { (_ result:ECResult<Any>) in
            if case let .failed(code,msg) = result{
                switch code{
                case 5://用户已经存在
                    completion(true,msg)
                case 6://用户不存在
                    completion(false,msg)
                default:
                    break
                }
            }
        }
    }
    
    func sendMobileCode(mobile:String,complete:((_ result:PhoneResult)->Void)?) -> Void {
        Member.provider.request(.mobileCode(mobile: mobile)) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate(_)://success
                complete?(.success)
            case let .failed(code, msg):
                switch code{
                case 29://手机号无效
                    complete?(.notExist(msg))
                default:
                    complete?(.failed(msg))
                }
            case .unreachable:
                complete?(.failed("网络连接失败"))
            default:
                complete?(.failed("其他错误"))
            }
        }
    }
    
    func verify(mobile:String,code:String,complete:((_ result:CodeResult)->Void)?) -> Void {
        Member.provider.request(.verifyCode(mobile:mobile, authCode: code)) { (_ result:ECResult<Any>) in
            switch result{
            case .untranslate:
                complete?(.success)
            case .unreachable:
                complete?(.failed("网络连接失败"))
            case let .failed(_, msg):
                complete?(.failed(msg))
            default:
                complete?(.failed("其他错误"))
            }
        }
    }
}
