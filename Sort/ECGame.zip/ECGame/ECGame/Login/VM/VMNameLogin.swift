//
//  VMNameLogin.swift
//  ECGame
//
//  Created by Michale on 2019/11/25.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMNameLoginProtocol:class {
    func success() -> Void
    func userNotExist(msg:String) -> Void
    func passwordWrong(msg:String) -> Void
    func failed(msg:String) -> Void
}

class VMNameLogin: VMLoginBase {
    
    weak var delegate:VMNameLoginProtocol?
    
    func login(userID:String,pwd:String) -> Void {
        Member.provider.request(.login(userID: userID, pwd: pwd.md5.md5)) { (_ result:ECResult<MAccessToken>) in
            
            switch result {
            case let .success(at):
                self.saveUser(token: at)
                self.delegate?.success()
            case let .failed(code,msg):
                switch code{
                case 3://密码不正确
                    self.delegate?.passwordWrong(msg: msg)
                case 6://用户不存在
                    self.delegate?.userNotExist(msg: msg)
                default:
                    self.delegate?.failed(msg: msg)
                }
            case .unreachable:
                self.delegate?.failed(msg: "无法连接服务器")
            default:
                self.delegate?.failed(msg: "其他错误")
            }
        }
    }

}
