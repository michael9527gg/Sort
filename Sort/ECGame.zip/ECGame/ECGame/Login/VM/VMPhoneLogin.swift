//
//  VMPhoneLogin.swift
//  ECGame
//
//  Created by Michale on 2019/12/17.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class VMPhoneLogin: VMLoginBase {
    
    enum PhoneLoginResult {
        case success
        
        /// 手机验证码不正确
        case wrongCode(String)
        
        /// 手机号不存在
        case notExist(String)
        case failed(String)
    }
    
    func login(mobile:String,code:String,complete:@escaping (_ result:PhoneLoginResult)->Void) -> Void {
        Member.provider.request(.loginMobile(mobile: mobile, authCode: code)) { (_ result:ECResult<MAccessToken>) in
            switch result{
            case let .success(at):
                self.saveUser(token: at)
                complete(.success)
            case let .failed(code, msg):
                switch code{
                case 30:
                    complete(.notExist(msg))
                case 32:
                    complete(.wrongCode(msg))
                default:
                    complete(.failed(msg))
                }
            case .unreachable:
                complete(.failed("网络无法连接"))
            default:
                complete(.failed("其他错误"))
            }
        }
    }
}
