//
//  PackageLogin.swift
//  ECGame
//
//  Created by Michale on 2019/10/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

class PackageLogin {
    typealias Complete = (_ success:Bool)->Void
    
    fileprivate static var isBeingPresented = false
    fileprivate static var complete:Complete?
    
    func startRegister(_ controller:UIViewController,inviteCode:String? = nil, completion:Complete?) -> Void {
        /// 当前登陆操作正在进行
        if PackageLogin.isBeingPresented {
            return
        }
        PackageLogin.isBeingPresented = true
        PackageLogin.complete = { (success) in
            completion?(success)
            // clear
            PackageLogin.isBeingPresented = false
            PackageLogin.complete = nil
        }
        
        let register = Register()
        register.register.user.invite.textField.text = inviteCode
        register.register.phone.invite.textField.text = inviteCode
        let nav = NavigationController(rootViewController:register)
        controller.present(nav, animated:true, completion: nil)
    }
    
    
    func startLogin(_ controller:UIViewController , completion:Complete?) -> Void {
        /// 当前登陆操作正在进行
        if PackageLogin.isBeingPresented {
            return
        }
        PackageLogin.isBeingPresented = true
        PackageLogin.complete = { (success) in
            completion?(success)
            // clear
            PackageLogin.isBeingPresented = false
            PackageLogin.complete = nil
        }
        
        let login = NameLogin()
        let nav = NavigationController(rootViewController:login)
        controller.present(nav, animated:true, completion: nil)
    }
}

extension PackageLogin{
    private class NameLogin: NameLoginController {
        override func leftClick() {
            dismiss(animated: true) {
                PackageLogin.complete?(false)
            }
        }
        
        override func phoneLogin() {
            let phone = PhoneLogin()
            navigationController?.pushViewController(phone, animated: true)
        }
        
        override func loginSuccess() {
            dismiss(animated: true) {
                PackageLogin.complete?(true)
            }
        }
        
    }
}

extension PackageLogin{
    private class PhoneLogin:PhoneLoginController{
        override func loginSuccess() {
            dismiss(animated: true) {
                PackageLogin.complete?(true)
            }
        }
    }
}

extension PackageLogin{
    private class Register:RegisterController{

        override func registerSuccess() {
            dismiss(animated: true) {
                PackageLogin.complete?(true)
            }
        }
        
        override func leftClick() {
            dismiss(animated: true) {
                PackageLogin.complete?(false)
            }
        }
        
    }
}
