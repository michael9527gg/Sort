//
//  PhoneLoginController.swift
//  ECGame
//
//  Created by Michale on 2019/12/12.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class PhoneLoginController: BaseController {
    let ctView = PhoneLoginView()
    let vmLogin  = VMPhoneLogin()
    let vmRegister = VMRegister()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationType = .white
        setBackButton(isBlack: true)
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? PhoneLoginView.Event {
        case .some(.userNameLogin):
            leftClick()
        case let .some(.login(phone)):
           startLogin(phone: phone)
        default:
            break
        }
    }
    
    func sendCode(phone:String,done:VerifyPhoneController.Done?) -> Void {
        vmLogin.sendMobileCode(mobile: phone) {[weak self] (result) in
            switch result{
            case .success:
                let code = VerifyPhoneController(phone: phone, done: done)
                self?.navigationController?.pushViewController(code, animated: true)
            case let .notExist(msg):
                self?.ctView.phone.currentState = .error(msg)
            case let .failed(msg):
                print(msg)
            }
        }
    }
    
    func startLogin(phone:String) -> Void {
        sendCode(phone: phone) {[weak self] (code, failed) in
            self?.vmLogin.login(mobile: phone, code: code, complete: { (result) in
                switch result{
                case .success:
                    self?.loginSuccess()
                case let .wrongCode(msg):
                    failed?(.wrongCode(msg))
                case let .notExist(msg):
                    self?.navigationController?.popViewController(animated: true)
                    self?.phoneNotExist(msg: msg)
                case let .failed(msg):
                    failed?(.error(msg))
                }
            })
        }
    }
    
    func startRegister() -> Void {
        let phone = ctView.phone.phone ?? ""
        sendCode(phone:phone) {[weak self] (code, failed) in
            self?.vmRegister.register(mobile: phone, code: code, invite:nil, complete: { (result) in
                switch result{
                case .success:
                    self?.loginSuccess()
                case let .wrongCode(msg):
                    failed?(.wrongCode(msg))
                case let .exist(msg)://should never run  here
                    self?.navigationController?.popViewController(animated: true)
                    self?.ctView.phone.currentState = .error(msg)
                case let .failed(msg):
                    failed?(.error(msg))
                }
            })
        }
    }
    
    func phoneNotExist(msg:String) -> Void {
        ctView.phone.currentState = .error(msg)
        ctView.check()
        
        let alert = WhiteAlertController(title: "该手机号尚未注册，您是否要注册新的账号？", message:nil, buttons: [.default(title: "返回", action:nil),.hilight(title: "注册", action: {[weak self] in
            self?.startRegister()
        })])
        present(alert, animated: true, completion: nil)
    }
    
    func loginSuccess() -> Void {
    }
    
    override func loadView() {
        view = ctView
    }
}
