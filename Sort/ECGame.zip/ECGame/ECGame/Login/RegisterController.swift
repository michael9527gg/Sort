//
//  RegisterController.swift
//  ECGame
//
//  Created by Michale on 2019/10/14.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class RegisterController: BaseController {
 
    let vmRegister = VMRegister()
    let vmPhoneLogin = VMPhoneLogin()
    let register = RegisterView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationBar()
    }
    
    private func setupNavigationBar()->Void{
        navigationType = .image
        title = "注册成为开心电竞会员"
        setBackButton()
    }
    
    override func loadView() {
        view = register
        vmRegister.delegate = self
    }
    
    override func routerEvent(_ event: Any) {
        
        if case let .scan(row)? = event as? RegisterView.InviteRow.Action{
            ScanQRCodeController.startScan(ctr: self) { (text) in
                if let s = text{
                    row.textField.text = s
                }
            }
            return
        }
        
        switch event as? NameLoginView.NamePwdView.Event{
        case let .checkUserName(row)?:
            let user = row.textField.text!
            vmRegister.userExist(userId:user) { (exist,msg)  in
                if exist == true,user == row.textField.text{
                    row.currentState = .error(msg)
                }
            }
        default:
            break
        }
        
        switch event as? RegisterView.Event {
        case let .userRegister(btn, name, pwd, invite)?:
            btn.isEnabled = false
            vmRegister.register(name:name, pwd:pwd, inviteCode:invite)
        case let .phoneRegister(btn, phone,invite)?:
            phoneRegister(phone: phone, invite: invite)
            btn.isEnabled = false
        default:
            break
        }
    }
    
    func sendMobileCode(phone:String,done:VerifyPhoneController.Done?) -> Void {
        vmRegister.sendMobileCode(mobile: phone) {[weak self] (result) in
            switch result{
            case .success:
                let verify = VerifyPhoneController(phone: phone, done: done)
                self?.navigationController?.pushViewController(verify, animated: true)
            case let .notExist(msg):
                self?.register.phone.phone.currentState = .error(msg)
            default:
                break
            }
        }
    }
    
    func phoneRegister(phone:String,invite:String?) -> Void {
        sendMobileCode(phone: phone) {[weak self] (code, failed) in
            self?.vmRegister.register(mobile:phone, code:code, invite: invite, complete:{ (result) in
                switch result{
                case .success://success
                    self?.registerSuccess()
                case let .exist(msg):
                    self?.navigationController?.popViewController(animated: true)
                    self?.phoneExist(msg:msg)
                case let .wrongCode(msg):
                    failed?(.wrongCode(msg))
                case let .failed(msg):
                    failed?(.error(msg))
                }
            })
        }
    }
    
    func startLogin(mobile:String) -> Void {
        sendMobileCode(phone: mobile) {[weak self] (code, failed) in
            self?.vmPhoneLogin.login(mobile: mobile, code: code, complete: { (result) in
                switch result{
                case .success:
                    self?.registerSuccess()
                case let .wrongCode(msg):
                    failed?(.wrongCode(msg))
                case let .failed(msg):
                    failed?(.error(msg))
                case let .notExist(msg)://never run here
                    self?.navigationController?.popViewController(animated: true)
                    self?.register.phone.phone.currentState = .error(msg)
                }
            })
        }
    }
    
    func phoneExist(msg:String) -> Void {
        register.phone.phone.currentState = .error(msg)
        register.check()
        
        let alert = WhiteAlertController(title: "该手机号已注册，您是否要直接登录？", message:nil, buttons: [.default(title: "返回", action:nil),.hilight(title: "登录", action: {[weak self] in
            self?.startLogin(mobile:self?.register.phone.phone.phone ?? "")
        })])
        present(alert, animated: true, completion: nil)
    }
    
    func registerSuccess() -> Void {
    }
    
}

extension RegisterController:VMRegisterProtocol{
    
    func userExist(msg: String) {
        register.user.namePwd.name.currentState = .error(msg)
        register.check()
    }
    
    func userRegisterSuccess() {
        registerSuccess()
    }
    
    func failed(msg: String) {
        
    }
}
