//
//  InputRowView.swift
//  ECGame
//
//  Created by Michale on 2019/11/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class InputRowView: UIView {
    
    enum Event {
        case valueChanged(UITextField)
    }
    
    enum State {
        case `default`(String) //默认状态
        case error(String) //提示错误信息
        case pass(String) //校验成功
    }
    
    internal let title = UILabel()
    var textField:UITextField!
    private let line = UIView()
    
    var errorColor:UIColor?
    var placeHolderColor:UIColor?
    var normalTitleColor:UIColor?
    var normalLineColor:UIColor?
    
    private var _currentState:State?
    var currentState:State?{
        set{
            _currentState = newValue
        
            func success(_ str:String)->Void{
                title.text = str
                title.textColor = normalTitleColor
                line.backgroundColor = normalLineColor
            }
            
            switch newValue{
            case let .some(.error(str)):
                title.text = str
                title.textColor = errorColor
                line.backgroundColor = title.textColor
            case let .default(str)?:
                success(str)
            case let .pass(str)?:
                success(str)
            default:
                break
            }
        }
        get{
            return _currentState
        }
    }
    
    private var _updateState:((_ text:String?) -> State?)?
    var updateState:((_ text:String?) -> State?)?{
        get{
            return _updateState
        }
        set{
            _updateState = newValue
            textFieldDidChange()
        }
    }
    
    var rightView:UIView?
    
    func setPlaceholder(str:String) -> Void {
        let placeholder = NSMutableAttributedString(string:str, attributes: [NSAttributedString.Key.font :textField.font!,NSAttributedString.Key.foregroundColor:placeHolderColor!])
        textField.attributedPlaceholder = placeholder
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        textField = textFiledClass.init()
        errorColor = .error
        placeHolderColor = UIColor(hexString: "#CCCCCC")
        normalTitleColor = .forgetPwd
        normalLineColor = .borderColor
        
        title.backgroundColor = .clear
        title.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview()
        }
        
        textField.addTarget(self, action:#selector(textFieldDidChange), for: .editingChanged)
        textField.font = UIFont(name: "PingFangSC-Regular", size:18.scale)
        textField.textColor = .title
        textField.backgroundColor = .clear
        addSubview(textField)
        textField.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(8.scale)
        }
        UITextField.appearance().tintColor = textField.textColor
        addSubview(line)
        line.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
    @objc func textFieldDidChange()->Void{
        if let b = updateState{
            currentState = b(textField.text)
        }
        let event:Event = .valueChanged(textField)
        routerEvent(event)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        textField.becomeFirstResponder()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        
        if let right = rightView{
            right.x = width - right.width
            right.centerY = textField.centerY
            
            textField.width = width - right.width - 10.scale
        }else{
            textField.width = width - 10.scale
        }
    }

    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height:65.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var textFiledClass:UITextField.Type{
        return UITextField.self
    }
}
