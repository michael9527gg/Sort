//
//  NameLoginView.swift
//  ECGame
//
//  Created by Michale on 2019/11/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


let nameFormat = "^[A-Za-z]{1}[A-Za-z0-9]{4,11}$"
let pwdFormat  = "^[A-Za-z0-9]{6,16}$"


class NameLoginView: UIView {
    
    enum Event {
        case phoneLogin
        case login(name:String?,pwd:String?)
    }
    
    let namePwd = NamePwdView()
    let nextBtn = NextButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        let title = UILabel()
        title.backgroundColor = .clear
        title.font = UIFont(name: "PingFangSC-Medium", size: 24.scale)
        title.textColor = .title
        title.text = "用户名登陆"
        addSubview(title)
        title.snp.makeConstraints {[weak self] (make) in
            make.leading.equalToSuperview().offset(20.scale)
            make.top.equalTo(self!.snp.topMargin).offset(20.scale)
        }
        
        namePwd.name.textField.delegate = self
        namePwd.pwd.textField.delegate = self
        namePwd.pwd.textField.returnKeyType = .done
        addSubview(namePwd)
        namePwd.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.centerX.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(25.scale)
        }
        
        let btn = UIButton()
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(phoneLogin), for: .touchUpInside)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:14.scale)
        btn.setTitle("通过手机号登陆", for:.normal)
        btn.setTitleColor(.loginBtn, for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.equalTo(namePwd)
            make.top.equalTo(namePwd.snp.bottom).offset(20.scale)
        }
        
       
        nextBtn.addTarget(self, action: #selector(login), for: .touchUpInside)
        nextBtn.isEnabled = false
        addSubview(nextBtn)
        nextBtn.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.snp.bottomMargin)
            make.height.equalTo(52.scale)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    @discardableResult
    func check() -> Bool {
        if case .pass(_)? = namePwd.name.currentState,
           case .pass(_)? = namePwd.pwd.currentState{
            nextBtn.isEnabled = true
            return true
        }else{
            nextBtn.isEnabled = false
            return false
        }
    }
    
    @objc func phoneLogin()->Void{
        let event:Event = .phoneLogin
        routerEvent(event)
    }
    
    @objc func login()->Void{
        endEditing(true)
        let event:Event = .login(name: namePwd.name.textField.text, pwd: namePwd.pwd.textField.text)
        next?.routerEvent(event)
    }
    
    override func routerEvent(_ event: Any) {
        if case .valueChanged? = event as? InputRowView.Event{
            check()
        }
        
        next?.routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension NameLoginView:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case namePwd.name.textField:
            _ = namePwd.pwd.textField.becomeFirstResponder()
        case namePwd.pwd.textField:
            if check(){
                login()
            }else{
                endEditing(true)
            }
        default:
            break
        }
        return true
    }
}


extension NameLoginView{
    class NextButton: UIButton,KeyboardMoverProtocol {
        let keyboard = KeyboardMover()
        
        override init(frame: CGRect) {
            super.init(frame:frame)
            keyboard.delegate = self
            backgroundColor = .clear
            titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size:16.scale)
            setTitle("下一步", for:.normal)
            setTitleColor(.marchName, for: .disabled)
            setTitleColor(.white, for: .normal)
            setBackgroundImage(UIColor.tintColor.image, for: .normal)
            setBackgroundImage(UIColor.nextBtn.image, for: .disabled)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        var movingViewWithKeyboard: UIView{
            return self
        }
    }
    class NamePwdView: UIView {
        
        enum Event {
            case checkUserName(InputRowView)
        }
        
        let name = InputRowView()
        let pwd = InputRowView()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            
            name.updateState = {[weak self] (text)  in
                if text == nil || text!.count == 0{
                    return .default("用户名")
                }
                if !(text!.first!.isLetter) {
                    return .error("必须以字母开头")
                }
                if text!.count < 5 {
                    return .error("至少5位")
                }
                if text!.count > 12 {
                    return .error("最多12位")
                }
                if text!.evaluate(nameFormat) == false{
                    return .error("不能包含特殊字符")
                }
                if let weak = self{
                    let event:Event = .checkUserName(weak.name)
                    weak.next?.routerEvent(event)
                }
                return .pass("用户名")
            }
            
            name.textField.returnKeyType = .next
            name.setPlaceholder(str: "5-12位字母加数字组成，字母开头")
            addSubview(name)
            name.snp.makeConstraints { (make) in
                make.leading.top.centerX.equalToSuperview()
            }
            
            pwd.updateState = {(text)  in
                if text == nil || text!.count == 0{
                    return .default("密码")
                }
                if text!.count < 6 {
                    return .error("至少6位")
                }
                if text!.count > 16 {
                    return .error("最多16位")
                }
                if text!.evaluate(pwdFormat) == false{
                    return .error("不能包含特殊字符")
                }
                return .pass("密码")
            }
            
            let eyeBtn = UIButton(frame: CGRect(origin: .zero, size: CGSize(width:18.scale, height:12.scale)))
            eyeBtn.addTarget(self, action: #selector(eyeClick(sender:)), for: .touchUpInside)
            eyeBtn.setImage(UIImage(named:"icon_eye_open"), for: .normal)
            eyeBtn.setImage(UIImage(named:"icon_eye_close"), for: .selected)
            pwd.rightView = eyeBtn
            pwd.addSubview(eyeBtn)
            pwd.textField.returnKeyType = .next
            pwd.textField.isSecureTextEntry = true
            pwd.setPlaceholder(str: "6-16位数字及字母组合")
            addSubview(pwd)
            pwd.snp.makeConstraints { (make) in
                make.leading.trailing.equalTo(name)
                make.top.equalTo(name.snp.bottom).offset(10.scale)
            }
        }
        
        @objc func eyeClick(sender:UIButton) ->Void{
            sender.isSelected = !sender.isSelected
            pwd.textField.isSecureTextEntry = !sender.isSelected
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            invalidateIntrinsicContentSize()
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height:pwd.y+pwd.height)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
