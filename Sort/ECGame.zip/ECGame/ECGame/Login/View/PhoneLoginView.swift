//
//  PhoneLoginView.swift
//  ECGame
//
//  Created by Michale on 2019/12/12.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class PhoneLoginView: UIView {
    
    enum Event {
        case login(phone:String)
        case userNameLogin
    }
    
    let phone = PhoneNumberView()
    let nextBtn = NameLoginView.NextButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        let title = UILabel()
        title.backgroundColor = .clear
        title.font = UIFont(name: "PingFangSC-Medium", size: 24.scale)
        title.textColor = .title
        title.text = "手机号登陆"
        addSubview(title)
        title.snp.makeConstraints {[weak self] (make) in
            make.leading.equalToSuperview().offset(20.scale)
            make.top.equalTo(self!.snp.topMargin).offset(20.scale)
        }
        
        phone.textField.returnKeyType = .done
        addSubview(phone)
        phone.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.centerX.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(25.scale)
        }
        
        let btn = UIButton()
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(userNameLogin), for: .touchUpInside)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:14.scale)
        btn.setTitle("通过用户名登陆", for:.normal)
        btn.setTitleColor(.loginBtn, for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.leading.equalTo(phone)
            make.top.equalTo(phone.snp.bottom).offset(20.scale)
        }
        
        nextBtn.addTarget(self, action: #selector(login), for: .touchUpInside)
        nextBtn.isEnabled = false
        addSubview(nextBtn)
        nextBtn.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.snp.bottomMargin)
            make.height.equalTo(52.scale)
        }
    }
    
    @discardableResult
    func check() -> Bool {
        if case .pass? = phone.currentState{
            nextBtn.isEnabled = true
        }else{
            nextBtn.isEnabled = false
        }
        return nextBtn.isEnabled
    }
    
    override func routerEvent(_ event: Any) {
        if case .valueChanged? = event as? InputRowView.Event{
            check()
            return
        }
        next?.routerEvent(event)
    }
    
    @objc func login()->Void{
        endEditing(true)
        let event:Event = .login(phone: phone.phone ?? "")
        next?.routerEvent(event)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    @objc func userNameLogin()->Void{
        endEditing(true)
        let event:Event = .userNameLogin
        next?.routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension PhoneLoginView{
    class PhoneNumberView: InputRowView {
        
        private func phone(text:String?) ->String?{
            guard let t = text else {
                return nil
            }
            var str = t.replacingOccurrences(of:" ", with:"")
            if str.count <= 3{
                return str
            }
            if str.count <= 7{
                let index = str.index(str.startIndex, offsetBy: 3)
                str.insert(" ", at: index)
                return str
            }
            
            var index = str.index(str.startIndex, offsetBy: 3)
            str.insert(" ", at: index)
            index = str.index(str.startIndex, offsetBy:8)
            str.insert(" ", at: index)
            return str
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            updateState = {[weak self] (text)  in
                let phone = self?.phone(text: text)
                self?.textField.text = phone
                
                if phone?.count == 0 {
                    return .default("手机号")
                }else if let t = phone,t.count < 13{
                    return .error("请输入完整")
                }
                
                if (phone?.count ?? 0) > 13 {
                    self?.textField.text = String(text!.prefix(13))
                }
                return .pass("手机号")
            }
            textField.keyboardType = .numberPad
            setPlaceholder(str: "中国大陆11位手机号")
        }
        
        var phone:String?{
            return textField.text?.replacingOccurrences(of:" ", with: "")
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
