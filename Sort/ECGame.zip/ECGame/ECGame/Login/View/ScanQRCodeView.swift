//
//  ScanQRCodeView.swift
//  ECGame
//
//  Created by Michale on 2019/12/13.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class ScanQRCodeView: UIView {
    let maskContent = UIView()
    let scaning     = ScaningView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    
        maskContent.isHidden = true
        maskContent.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        addSubview(maskContent)
        maskContent.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        backgroundColor = .navigatonBar
        scaning.isHidden = true
        addSubview(scaning)
        scaning.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(self.snp.topMargin)
            make.bottom.equalTo(self.snp.bottomMargin)
        }
    }

    
    override func routerEvent(_ event: Any) {
        if case let .frame(frame)? = event as? ScaningView.Event{
            if maskContent.layer.mask == nil{
                let rect = frame
                let path = UIBezierPath(rect:UIScreen.main.bounds)
                path.append(UIBezierPath(roundedRect:rect, cornerRadius:0).reversing())
                let shape = CAShapeLayer()
                shape.path = path.cgPath
                maskContent.layer.mask = shape
            }
            return
        }
        next?.routerEvent(event)
    }
    
    func startScan() -> Void {
        maskContent.isHidden = false
        scaning.isHidden = false
        scaning.addScaningAnimation()
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension ScanQRCodeView{
    class ScaningView: UIView {
        enum Event {
            case frame(CGRect)
            case `switch`
        }
        
        let area = UIImageView()
        let note = UILabel()
        let scan_line = UIImageView(image: UIImage(named: "scan_line"))
        let btn = UIButton()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            area.backgroundColor = .clear
            area.image = UIImage(named: "scan_area")
            addSubview(area)
            area.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.top.equalToSuperview().offset(124.scale)
            }
            
            addSubview(scan_line)
            scan_line.backgroundColor = .clear
            addSubview(scan_line)
            scan_line.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.top.equalTo(area)
            }
            
            note.backgroundColor = .clear
            note.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
            note.textColor = .marchName
            note.text = "将二维码放入框内，即可自动扫描"
            addSubview(note)
            note.snp.makeConstraints { (make) in
                make.top.equalTo(area.snp.bottom).offset(15.scale)
                make.centerX.equalToSuperview()
            }
            
           
            btn.setImage(UIImage(named: "icon_light"), for: .normal)
            btn.addTarget(self, action: #selector(switchTorch), for: .touchUpInside)
            btn.backgroundColor = .clear
            addSubview(btn)
            btn.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.bottom.equalTo(self.snp.bottomMargin).offset(-25.scale)
            }
        }
        
        @objc func switchTorch()->Void{
            let event:Event = .switch
            routerEvent(event)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            
            let event:Event = .frame(area.frame)
            routerEvent(event)
        }
        
        //添加扫描动画
        fileprivate func addScaningAnimation(){
            scan_line.y = area.frame.minY
            UIView.animate(withDuration: 2, animations: {
                self.scan_line.frame.origin.y = self.area.frame.maxY
            }) {[weak self] (finished) in
                self?.addScaningAnimation()
            }
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
