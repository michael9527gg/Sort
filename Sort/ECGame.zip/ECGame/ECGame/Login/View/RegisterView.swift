//
//  RegisterScrollView.swift
//  ECGame
//
//  Created by Michale on 2019/10/14.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class RegisterView: UIView {
    
    enum Event {
        case userRegister(btn:UIButton,name:String,pwd:String,invite:String?)
        case phoneRegister(btn:UIButton,phone:String,invite:String?)
    }
    
    let user = UserView()
    let phone = PhoneView()
    let segement = Segement(items: ["手机号注册","用户名注册"])
    let nextBtn = NameLoginView.NextButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        segement.selectedSegmentIndex = 0
        addSubview(segement)
        segement.addTarget(self, action: #selector(segementValueChange(s:)), for: .valueChanged)
        segement.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(20.scale)
            make.height.equalTo(45.scale)
        }
        
        let line = UIView()
        line.backgroundColor = UIColor(hexString: "#F2F2F2")
        addSubview(line)
        line.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(segement)
            make.top.equalTo(segement.snp.bottom)
            make.height.equalTo(1)
        }
        
        addSubview(user)
        user.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(20.scale)
            make.centerX.equalToSuperview()
            make.top.equalTo(segement.snp.bottom).offset(30.scale)
        }
        
        addSubview(phone)
        phone.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalTo(user)
        }
        
        
        nextBtn.addTarget(self, action: #selector(nextClick(sender:)), for: .touchUpInside)
        addSubview(nextBtn)
        nextBtn.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.snp.bottomMargin)
            make.height.equalTo(52.scale)
        }
        
        segementValueChange(s: segement)
    }
    
    @objc func nextClick(sender:UIButton)->Void{
         var event:Event = .userRegister(btn:sender, name:user.namePwd.name.textField.text!, pwd: user.namePwd.pwd.textField.text!, invite:user.invite.textField.text)
        
        if user.isHidden == true{
            event = .phoneRegister(btn: sender, phone:phone.phone.phone ?? "", invite:phone.invite.textField.text)
        }
        
        next?.routerEvent(event)
    }
    
    @objc func segementValueChange(s:Segement)->Void{
        let b = s.selectedSegmentIndex == 0
        phone.isHidden = !b
        user.isHidden = b
        check()
    }
        
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? InputRowView.Event{
        case .valueChanged?:
            check()
        default:
            break
        }
        
        switch event as? UserView.Event {
        case .inviteShouldReturn?:
            if check(){
                nextClick(sender: nextBtn)
            }
        default:
            break
        }
        
        next?.routerEvent(event)
    }
    
    @discardableResult
    func check() ->Bool{
        switch segement.selectedSegmentIndex {
        case 1:
            if case .pass(_)? = user.namePwd.name.currentState,
                case .pass(_)? = user.namePwd.pwd.currentState{
                nextBtn.isEnabled = true
                return true
            }else{
                nextBtn.isEnabled = false
            }
        case 0:
            if case .pass(_)? = phone.phone.currentState{
                nextBtn.isEnabled = true
                return true
            }else{
                nextBtn.isEnabled = false
            }
        default:
            break
        }
        return false
    }
/*

extension RegisterView{
    
    @objc func keyboardWillShow(noti:Notification) -> Void {
        let userInfo = noti.userInfo
        let value = userInfo?[UIView.keyboardFrameEndUserInfoKey] as? NSValue
        
        guard let keyboardRect = value?.cgRectValue else {return}
        guard let durationValue = userInfo?[UIView.keyboardAnimationDurationUserInfoKey] as? NSNumber else {return}
        guard let tf = editingTF else{return}
        guard let top = topWindow else {return}
        
        let vSpace = 20.scale
        let point = CGPoint(x: tf.frame.origin.x, y: tf.frame.origin.y+tf.frame.size.height)
        let p = convert(point, to: top)
        let offset = p.y + keyboardRect.size.height + vSpace - top.bounds.size.height
        let tr = offset > 0 ?CGAffineTransform(translationX: 0, y: -offset):CGAffineTransform.identity
        
        UIView.beginAnimations("ResizeView", context: nil)
        UIView.setAnimationDuration(TimeInterval(truncating: durationValue))
        transform = tr
        UIView.commitAnimations()
    }
    
    
    @objc func keyboardWillHide(noti:Notification) -> Void {
        UIView.beginAnimations("ResizeView", context: nil)
        UIView.setAnimationDuration(0.3)
        transform = CGAffineTransform.identity
        UIView.commitAnimations()
    }
    */
}


extension RegisterView{
    class Segement: UISegmentedControl {
        private let botomLine = UIImageView(image:UIImage(named: "segement_bottom"))
        
        override init(items: [Any]?) {
            super.init(items:items)
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            backgroundColor = .clear
            tintColor = .clear
            setTitleTextAttributes([NSAttributedString.Key.foregroundColor :UIColor.title,NSAttributedString.Key.font:UIFont(name: "PingFangSC-Medium", size: 20.scale)!], for: .selected)
            setTitleTextAttributes([NSAttributedString.Key.foregroundColor :UIColor(hexString: "#CCCCCC"),NSAttributedString.Key.font:UIFont(name: "PingFangSC-Medium", size: 20.scale)!], for: .normal)
            
            addSubview(botomLine)
            
            addObserver(self, forKeyPath: "selectedSegmentIndex", options: NSKeyValueObservingOptions.new, context: nil)
        }
        
        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
            if keyPath == "selectedSegmentIndex" {
                updateLine()
            }
        }
        
        deinit {
            removeObserver(self, forKeyPath: "selectedSegmentIndex")
        }
        
        
        func updateLine() -> Void {
            var width:CGFloat = 0
            if selectedSegmentIndex != UISegmentedControl.noSegment {
                width = 30.scale
            }
            let x = (CGFloat(selectedSegmentIndex*2+1))/(CGFloat)(numberOfSegments*2)
            let centerX =  x * self.frame.size.width
            botomLine.frame = CGRect(x:centerX-width/2, y:self.frame.size.height-3, width:width, height:2)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            bringSubviewToFront(botomLine)
            updateLine()
        }
        
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class UserView: UIView,UITextFieldDelegate {
        
        enum Event {
            case inviteShouldReturn
        }
        
        let invite = InviteRow()
        let namePwd = NameLoginView.NamePwdView()
        let note = NoteLable()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            
            addSubview(namePwd)
            namePwd.name.textField.delegate = self
            namePwd.pwd.textField.delegate = self
            namePwd.snp.makeConstraints { (make) in
                make.leading.top.equalToSuperview()
                make.centerX.equalToSuperview()
            }
            
            invite.textField.delegate = self
            invite.textField.returnKeyType = .done
            addSubview(invite)
            invite.snp.makeConstraints { (make) in
                make.leading.trailing.equalTo(namePwd)
                make.top.equalTo(namePwd.snp.bottom).offset(10.scale)
            }
           
            addSubview(note)
            note.snp.makeConstraints { (make) in
                make.leading.equalTo(invite)
                make.top.equalTo(invite.snp.bottom).offset(10.scale)
            }
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            invalidateIntrinsicContentSize()
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height:note.y+note.height)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            endEditing(true)
            switch textField {
            case namePwd.name.textField:
                _ = namePwd.pwd.textField.becomeFirstResponder()
            case namePwd.pwd.textField:
                _ = invite.textField.becomeFirstResponder()
            case invite.textField:
                let event:Event = .inviteShouldReturn
                next?.routerEvent(event)
            default:
                break
            }
            return true
        }
    }
    
    class PhoneView: UIView,UITextFieldDelegate {
        let phone = PhoneLoginView.PhoneNumberView()
        let invite = InviteRow()
        let note = NoteLable()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            
            phone.textField.delegate = self
            phone.textField.returnKeyType = .next
            addSubview(phone)
            phone.snp.makeConstraints { (make) in
                make.leading.top.equalToSuperview()
                make.centerX.equalToSuperview()
            }
            
            invite.textField.delegate = self
            invite.textField.returnKeyType = .done
            addSubview(invite)
            invite.snp.makeConstraints { (make) in
                make.leading.trailing.equalTo(phone)
                make.top.equalTo(phone.snp.bottom).offset(10.scale)
            }
            
            addSubview(note)
            note.snp.makeConstraints { (make) in
                make.leading.equalTo(invite)
                make.top.equalTo(invite.snp.bottom).offset(10.scale)
            }
        }
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            
            switch textField {
            case phone.textField:
                _ = invite.textField.becomeFirstResponder()
            case invite.textField:
                endEditing(true)
            default:
                break
            }
            return true
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            invalidateIntrinsicContentSize()
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height:note.y+note.height)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class NoteLable: UILabel {
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            let str = "注册即表示同意开心电竞所有的"
            let attr = NSMutableAttributedString(string:str + "《规则与条款》", attributes: [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size:14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.loginBtn])
            attr.addAttributes([NSAttributedString.Key.foregroundColor :UIColor.disabled], range: NSRange(location:0, length:str.count))
            attributedText = attr
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class InviteRow: InputRowView {
        enum Action {
            case scan(InviteRow)
        }
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            let scan = UIButton(frame: CGRect(origin: .zero, size: CGSize(width: 120.scale, height:30.scale)))
            scan.addTarget(self, action: #selector(inviteBtn), for: .touchUpInside)
            scan.backgroundColor = .clear
            scan.titleEdgeInsets = UIEdgeInsets(top:0, left:10.scale, bottom: 0, right: 0)
            scan.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 14.scale)
            scan.setTitle("扫好友推荐码", for: .normal)
            scan.setImage(UIImage(named: "icon_scan_orange"), for: .normal)
            scan.setTitleColor(.loginBtn, for: .normal)
            addSubview(scan)
            rightView = scan
            
            updateState = {(text)  in
//                if let t = text,t.count > 0{
//                    return .error("错误")
//                }
                return .default("推荐码")
            }
            setPlaceholder(str: "选填")
        }
        
        @objc func inviteBtn()->Void{
            let action:Action = .scan(self)
            routerEvent(action)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
