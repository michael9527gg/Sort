//
//  VerifyPhoneView.swift
//  ECGame
//
//  Created by Michale on 2019/12/12.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class VerifyPhoneView: UIView {
    
    enum Event {
        case sendCode
    }
    
    let title = UILabel()
    let code = CodeView(count:5)
    let btn = CountButton()
    let note = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        title.backgroundColor = .clear
        title.textAlignment = .center
//        title.text = "请输入 221 32312 31321 收到的验证码"
        title.font = UIFont(name: "PingFangSC-Regular", size: 15.scale)
        title.textColor = .disabled
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(self.snp.topMargin).offset(35.scale)
        }
        
        addSubview(code)
        code.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(25.scale)
        }
        
        note.backgroundColor = .clear
        note.textAlignment = .left
        note.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        note.textColor = .error
        addSubview(note)
        note.snp.makeConstraints { (make) in
            make.leading.equalTo(code)
            make.top.equalTo(code.snp.bottom).offset(15.scale)
        }
        
        btn.addTarget(self, action: #selector(sendCode), for: .touchUpInside)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(note.snp.bottom).offset(25.scale)
        }
    }
    
    @objc func sendCode()->Void{
        let event:Event = .sendCode
        routerEvent(event)
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? CodeView.Event{
        case .some(.endEdit):
            endEditing(true)
            next?.routerEvent(event)
            fallthrough
        case .some(.beginEdit),.some(.editing):
            note.text = nil
        default:
            next?.routerEvent(event)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        endEditing(true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension VerifyPhoneView{
    class CodeView: UIView,UIKeyInput {
        
        enum Event {
            case endEdit(text:String)
            case beginEdit
            case editing
        }
        var keyboardType: UIKeyboardType{
            set{
                
            }
            get{
                return .numberPad
            }
        }
        
        var hasText: Bool{
            return (text?.count ?? 0) > 0
        }
        var text:String?{
            set{
                var index = 0
                for item in subviews {
                    if let char = item as? CharView{
                        if (newValue?.count ?? 0) > index{
                            let index = newValue!.index(newValue!.startIndex, offsetBy:index)
                            char.title.text = String(newValue![index])
                        }else{
                            char.title.text = nil
                        }
                        
                        index += 1
                    }
                }
            }
            get{
                if subviews.count == 0{
                    return nil
                }
                var str = ""
                for item in subviews {
                    if let char = item as? CharView,let c = char.title.text,c.count > 0{
                        str += c
                    }
                }
                return str
            }
        }
        
        override func resignFirstResponder() -> Bool {
            for item in subviews {
                if let char = item as? CharView{
                    char.isEditing(false)
                }
            }
            return super.resignFirstResponder()
        }
        
        private func updateEditing() -> Void {
            
            var isFind = false
            for item in subviews {
                if let char = item as? CharView{
                    if (char.title.text?.count ?? 0) == 0,!isFind{
                        char.isEditing(true)
                        isFind = true
                    }else{
                        char.isEditing(false)
                    }
                }
            }
        }
        
        override var canBecomeFirstResponder: Bool{
            return true
        }
        
        @discardableResult
        override func becomeFirstResponder() -> Bool {
            updateEditing()
            let event:Event = .beginEdit
            routerEvent(event)
            return super.becomeFirstResponder()
        }
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            if !isFirstResponder {
                becomeFirstResponder()
            }
        }
        
        func insertText(_ text: String) {
            var event:Event = .editing
            if self.text == nil {
                self.text = text
            }else{
                let s = self.text! + text
                self.text = s
                if s.count == subviews.count{
                    event = .endEdit(text: s)
                }
            }
            updateEditing()
            routerEvent(event)
        }
        
        func deleteBackward() {
            if let str = self.text,str.count > 0{
                self.text = String(str.prefix(str.count-1))
            }
            updateEditing()
            let event:Event = .editing
            routerEvent(event)
        }
        
        
        class CharView: UIView {
            
            func isEditing(_ editing:Bool) -> Void {
                if editing {
                    title.text = nil
                    icon.isHidden = false
                    line.backgroundColor = .forgetPwd
                }else{
                    icon.isHidden = true
                    line.backgroundColor = .borderColor
                }
            }
            
            let title = UILabel()
            private let icon = UIView()
            private let line = UIView()
            
            override init(frame: CGRect) {
                super.init(frame: frame)
                backgroundColor = .clear
                title.backgroundColor = .clear
                title.textAlignment = .center
                title.font = UIFont(name: "PingFangSC-Regular", size: 26.scale)
                title.textColor = .title
                addSubview(title)
                title.snp.makeConstraints { (make) in
                    make.edges.equalToSuperview()
                }
                
                icon.backgroundColor = UIColor(hexString: "#7C86E9")
                addSubview(icon)
                icon.snp.makeConstraints { (make) in
                    make.size.equalTo(CGSize(width: 2, height: 26.scale))
                    make.center.equalTo(title)
                }
                
               
                addSubview(line)
                line.snp.makeConstraints { (make) in
                    make.height.equalTo(1)
                    make.left.right.bottom.equalToSuperview()
                }
                isEditing(false)
            }
            
            override var intrinsicContentSize: CGSize{
                return CGSize(width:36.scale, height:40.scale)
            }
            
            required init?(coder aDecoder: NSCoder) {
                fatalError("init(coder:) has not been implemented")
            }
        }
        
        var hSpace:CGFloat = 10.scale
        private var count:Int = 0
        
        convenience init(count:Int) {
            self.init(frame:.zero)
            self.count = count >= 0 ? count : 0
            
            var pre:UIView? = nil
            for _ in 0 ..< self.count {
                let c = CharView()
                addSubview(c)
                c.snp.makeConstraints { (make) in
                    make.top.equalToSuperview()
                    if pre == nil{
                        make.leading.equalToSuperview()
                    }else{
                        make.leading.equalTo(pre!.snp.trailing).offset(hSpace)
                    }
                }
                pre = c
            }
            
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
        }
        
        override var intrinsicContentSize: CGSize{
            if let first = subviews.first as? CharView{
                let s = first.intrinsicContentSize
                return CGSize(width:s.width * CGFloat(count) + CGFloat(count-1) * hSpace, height: s.height)
            }
            return .zero
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}

extension VerifyPhoneView{
    class CountButton: UIButton {
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
            setTitle("重新发送验证码", for: .normal)
            setTitleColor(.loginBtn, for:.normal)
            setTitleColor(.disabled, for: .disabled)
        }
        
        func startCount() -> Void {
            var time = 60
            isEnabled = false
            let codeTimer = DispatchSource.makeTimerSource(flags:.init(rawValue: 0), queue: DispatchQueue.global())
            codeTimer.schedule(deadline: .now(), repeating: .milliseconds(1000))
            codeTimer.setEventHandler {[weak self] in
              
                if self == nil{
                    codeTimer.cancel()
                    return
                }
                
                time = time - 1
                if time < 0 {
                    codeTimer.cancel()
                    DispatchQueue.main.async {
                        self?.setTitle("重新发送验证码", for: .normal)
                        self?.isEnabled = true
                    }
                    return
                }
                
                DispatchQueue.main.async {
                    self?.setTitle("重新发送 (\(time)秒)", for: .normal)
                }
            }
            
            codeTimer.activate()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
