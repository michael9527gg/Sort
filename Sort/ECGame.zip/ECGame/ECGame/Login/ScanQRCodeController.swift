//
//  ScanQRCodeController.swift
//  ECGame
//
//  Created by Michale on 2019/12/12.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import AVKit

class ScanQRCodeController: BaseController {
    let vm = VMScanQRCode()
    let ctView = ScanQRCodeView()
    
    typealias Complete = (_ text:String?)->Void
    fileprivate var compete:Complete?
    
    class func startScan(ctr:UIViewController?,complete:Complete?)->Void{
        let qr = ScanQRCodeController()
        qr.compete = complete
        let nav = NavigationController(rootViewController:qr)
        ctr?.present(nav, animated:true, completion: nil)
    }
    
    override func leftClick() {
        dismiss(animated: true) {
            self.compete?(nil)
        }
    }
    
    override func loadView() {
        view = ctView
        vm.delegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setNavigation()
    }
    
    func setNavigation() -> Void {
        navigationType = .default
        setBackButton()
        
        let btn = UIButton()
        btn.backgroundColor = .clear
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        btn.setTitle("相册", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.addTarget(self, action: #selector(toPhoto), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: btn)
        
        title = "扫描好友推荐二维码"
        videoAuthorization()
    }
    
    
    @objc func toPhoto()->Void{
        DeviceAuthorization.photo {[weak self] (result) in
            DispatchQueue.main.async {
                switch result{
                case .first(let success):
                    if !success{
                        self?.alert(title: "您拒绝了相册访问权限", message: "我们将无法打开您的相册，点击去开启重新打开")
                    }else{
                        self?.imagPicker()
                    }
                case .default(let success):
                    if !success{
                        self?.alert(title: "无法打开相册", message: "点击去开启以打开您的相册")
                    }else{
                        self?.imagPicker()
                    }
                }
            }
        }
    }
    
    func imagPicker() -> Void {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) == false{
            return
        }
        
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        present(picker, animated: true, completion:nil)
    }
    
    override func routerEvent(_ event: Any) {
        if case .switch? = event as? ScanQRCodeView.ScaningView.Event{
            DeviceAuthorization.switchTorch()
        }
    }
    
    func videoAuthorization() -> Void {
        DeviceAuthorization.video {[weak self] (result) in
            DispatchQueue.main.async {
                switch result{
                case .first(let success):
                    if !success{
                        self?.alert(title: "您拒绝了相机访问权限", message: "我们将无法打开您的相机，点击去开启重新打开")
                    }else{
                        self?.vm.startRunning(view:self!.ctView)
                        self?.ctView.startScan()
                    }
                case .default(let success):
                    if !success{
                        self?.alert(title: "无法打开相机", message: "点击去开启以打开您的摄像头")
                    }else{
                        self?.vm.startRunning(view:self!.ctView)
                        self?.ctView.startScan()
                    }
                }
            }
        }
    }
    
    func alert(title:String,message:String) -> Void {
        let alert = UIAlertController(title:title, message:message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title:"取消", style: .cancel, handler: { (_) in
            
        }))
        alert.addAction(UIAlertAction(title: "去开启", style: .default, handler: {(_) in
            DeviceAuthorization.toSetting()
        }))
        self.present(alert, animated:true, completion:nil)
    }
}

extension ScanQRCodeController:VMScanQRCodeProtocol{
    func success(code: String) {
        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
        dismiss(animated: true) {
            self.compete?(code)
        }
    }
    
    func failed(message: String) {
        ctView.scaning.note.text = message
        ctView.scaning.note.textColor = .error
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
            self.ctView.scaning.note.text = "将二维码放入框内，即可自动扫描"
            self.ctView.scaning.note.textColor = .marchName
        }
    }
}

extension ScanQRCodeController:UIImagePickerControllerDelegate,UINavigationControllerDelegate{

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
       
        if let img = info[UIImagePickerController.InfoKey.originalImage] as? UIImage,
           let code = vm.parse(source: img.qrCodes){
            picker.dismiss(animated:true) {[weak self] in
                self?.success(code: code)
            }
            return
        }
        picker.dismiss(animated: true, completion:{[weak self] in
            let alert = UIAlertController(title:"未发现二维码", message:"图片二维码要尽量清晰哦", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title:"我知道了", style: .cancel, handler:nil))
            self?.present(alert, animated:true, completion:nil)
        })
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
