//
//  NameLoginController.swift
//  ECGame
//
//  Created by Michale on 2019/11/24.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class NameLoginController: BaseController {
    let vm = VMNameLogin()
    let ctView = NameLoginView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
    }
    

    private func setupNavigationBar() -> Void{
        navigationType = .white
        setBackButton(isBlack: true)
    }
    
    override func routerEvent(_ event: Any) {
        
        switch event as? NameLoginView.Event {
        case let .login(name, pwd)?:
            vm.login(userID: name!, pwd:pwd!)
        case .phoneLogin?:
            phoneLogin()
        default:
            break
        }
        
        switch event as?  NameLoginView.NamePwdView.Event{
        case let .checkUserName(row)?:
            let user = row.textField.text!
            vm.userExist(userId:user) { (exist,msg)  in
                if exist == false,user == row.textField.text{
                    row.currentState = .error(msg)
                }
            }
        default:
            break
        }
    }
   
    func phoneLogin() -> Void {
        let phone = PhoneLoginController()
        navigationController?.pushViewController(phone, animated: true)
    }
    
    func loginSuccess() -> Void {
        
    }
    
    override func loadView() {
        view = ctView
        vm.delegate = self
    }
}

extension NameLoginController:VMNameLoginProtocol{
    func userNotExist(msg: String) {
        ctView.namePwd.name.currentState = .error(msg)
        ctView.check()
    }
    func passwordWrong(msg: String) {
        ctView.namePwd.pwd.currentState = .error(msg)
        ctView.check()
    }
    
    func success() {
        loginSuccess()
    }
    
    func failed(msg: String) {
        
    }
}
