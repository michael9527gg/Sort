//
//  ECSocket.swift
//  ECGame
//
//  Created by Michale on 2019/11/5.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import SwiftSignalRClient


protocol ECSocketMatchProtocol:class {
    func matchDidChanged(_ match: [String:ECSocket.MMatchChanged]) -> Void
}

protocol ECSocketOddsProtocol:class {
    func oddsDidChanged(_ odds:[String:[String:ECSocket.MOddsChanged]]) -> Void
}

protocol ECSocketBetProtocol:class {
    func betDidChanged(_ bet:[String:ECSocket.MBetsChanged]) -> Void
}

protocol ECSocketPlayProtocol:class {
    func playDidChanged(_ play:[String:[String:ECSocket.MPlayChanged]]) -> Void
}

protocol ECSocketOnlineProtocol:class {
    func onlineCountChanged(_ count:ECSocket.MOnlineCount) -> Void
}


class ECSocket {
    static var socket: ECSocket?
    var connection:HubConnection!
    fileprivate static let delegates = Delegates()
    
    init(url:URL) {
        self.connection = HubConnectionBuilder(url:url).withLogging(minLogLevel: .error).withJSONHubProtocol().build()
        connection.delegate = self
        
        func traslate<T>(dict:[String:NSDictionary]) ->[String:T]? where T:MTranslateProtocol{
            var ret = [String:T]()
            for (key,value) in dict{
                ret[key] = T(dict:value)
            }
            return ret
        }
        
        func traslateArray<T>(dict:[String:[NSDictionary]],key:String) ->[String:[String:T]]? where T:MTranslateProtocol{
            var ret = [String:[String:T]]()
            for (k,value) in dict{
                var v = [String:T]()
                for item in value{
                    if let k = item[key] as? String{
                        v[k] = T(dict: item)
                    }
                }
                ret[k] = v
            }
            return ret
        }
        
        @discardableResult
        func on<T>(_ method:String,key:String? = nil) ->T? where T:MTranslateProtocol{
            connection.on(method:method, callback: {(str:String) in
                var t:Any? = nil
                if let  data = str.data(using: .utf8),let dict = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String:Any]{
                    
                    if let array = dict as? [String:[NSDictionary]],let ret:[String:[String:T]] = traslateArray(dict:array, key: key ?? ""){
                        t = ret
                    }else if let array = dict as? [String:NSDictionary],let ret:[String:T] = traslate(dict: array){
                        t = ret
                    }else{
                        t = T(dict: dict as NSDictionary)
                    }
                }
                
                ECSocket.delegates.send(t)
            })
            return nil
        }
        
        let _:MMatchChanged? = on("GetMatchChangedList")
        let _:MBetsChanged? = on("GetBetChangedList")
        let _:MPlayChanged? = on("GetPlayChangedList",key:"edid")
        let _:MOddsChanged? = on("GetOddsChangedList",key:"edoid")
        let _:MOnlineCount? = on("GetOnlineCount")
    }
    
    class func startConnect(){
        VMContactUs().site {(result) in
            switch result{
            case let .success(site):
                if let str = site.signalUrl,let u = URL(string: str){
                    ECSocket.socket = ECSocket(url:u)
                    ECSocket.socket?.connection.start()
                }
            case .failed:
                DispatchQueue.global().asyncAfter(deadline: .now() + 10, execute: {
                    startConnect()
                })
            }
        }
    }
    
    class func add(delegates:Set<`Type`>) -> Void {
        remove(delegates: delegates)
        let m = ECSocket.delegates
        for type in delegates{
            switch type {
            case let .bet(delegate):
                m.bet.append(WeakRef(value: delegate))
            case let .match(delegate):
                m.match.append(WeakRef(value: delegate))
            case let .odds(delegate):
                m.odds.append(WeakRef(value: delegate))
            case let .play(delegate):
                m.play.append(WeakRef(value: delegate))
            case let .onlineCount(delegate):
                m.onlineCount.append(WeakRef(value: delegate))
            }
        }
    }
    
   
    class func remove(delegates:Set<`Type`>?) -> Void {
        guard let sets = delegates else {
            return
        }
        let m = ECSocket.delegates
        for type in sets{
            switch type {
            case let .bet(delegate):
                m.bet.removeAll { (pro) -> Bool in
                    return pro.pointer == nil ||  pro.pointer! === delegate
                }
            case let .match(delegate):
                m.match.removeAll { (pro) -> Bool in
                    return pro.pointer == nil ||  pro.pointer! === delegate
                }
            case let .odds(delegate):
                m.odds.removeAll { (pro) -> Bool in
                    return pro.pointer == nil ||  pro.pointer! === delegate
                }
            case let .play(delegate):
                m.play.removeAll { (pro) -> Bool in
                    return pro.pointer == nil ||  pro.pointer! === delegate
                }
            case let .onlineCount(delegate):
                m.onlineCount.removeAll { (pro) -> Bool in
                    return pro.pointer == nil ||  pro.pointer! === delegate
                }
            }
        }
    }
}


extension ECSocket:HubConnectionDelegate{
    func connectionDidOpen(hubConnection: HubConnection) {
        let sign = ECSignature.sign(nil)
        hubConnection.invoke(method:"VerifyConnection",sign["timestamp"] as! Int,sign["random"] as! String,sign["signature"] as! String){ (_) in
        }
    }
    
    func connectionDidFailToOpen(error: Error) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5) {
            ECSocket.startConnect()
        }
    }
    
    func connectionDidClose(error: Error?) {
        print("didClose")
    }
}

extension ECSocket{
    class WeakRef<T:AnyObject>{
        private(set) weak var pointer:T?
        init(value:T?){
            self.pointer = value
        }
    }
    
    enum `Type`:Hashable {
        static func == (lhs: `Type`, rhs: `Type`) -> Bool {
            switch (lhs,rhs) {
            case (.match(let l),.match(let r)):
                return l === r
            case (.odds(let l),.odds(let r)):
                return l === r
            case (.bet(let l),.bet(let r)):
                return l === r
            case (.play(let l),.play(let r)):
                return l === r
            case (.onlineCount(let l),.onlineCount(let r)):
                return l === r
            default:
                return false
            }
        }
        
        func hash(into hasher: inout Hasher) {
        }
        
        case match(ECSocketMatchProtocol?)
        case odds(ECSocketOddsProtocol?)
        case bet(ECSocketBetProtocol?)
        case play(ECSocketPlayProtocol?)
        case onlineCount(ECSocketOnlineProtocol?)
    }
    
    fileprivate class Delegates {
        func send<T>(_ dict:T?) -> Void {
            if dict == nil{
                return
            }
            if let d = dict as? [String:Any],d.count == 0{
                return
            }
            
            if let m = dict as? [String:ECSocket.MMatchChanged]{
                for item in match{
                    (item.pointer as? ECSocketMatchProtocol)?.matchDidChanged(m)
                }
            }else if let m = dict as? [String:[String:ECSocket.MOddsChanged]]{
                for item in odds{
                    (item.pointer as? ECSocketOddsProtocol)?.oddsDidChanged(m)
                }
            }else if let m = dict as? [String:[String:ECSocket.MPlayChanged]]{
                for item in play{
                    (item.pointer as? ECSocketPlayProtocol)?.playDidChanged(m)
                }
            }else if let m = dict as? [String:ECSocket.MBetsChanged]{
                for item in bet{
                    (item.pointer as? ECSocketBetProtocol)?.betDidChanged(m)
                }
            }else if let m = dict as? MOnlineCount{
                for item in onlineCount{
                    (item.pointer as? ECSocketOnlineProtocol)?.onlineCountChanged(m)
                }
            }
        }
        
        
        var match    = [WeakRef<AnyObject>]()
        var odds     = [WeakRef<AnyObject>]()
        var bet      = [WeakRef<AnyObject>]()
        var play     = [WeakRef<AnyObject>]()
        var onlineCount = [WeakRef<AnyObject>]()
    }
}
