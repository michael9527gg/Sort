//
//  ECSocket+Extension.swift
//  ECGame
//
//  Created by Michale on 2019/12/30.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation



extension ECSocket{
    class MOnlineCount: MTranslateProtocol {
        var count:Int?
        required init(dict: NSDictionary?) {
            count = dict?["count"]
        }
    }
}

extension ECSocket{
    class MPlayChanged: MTranslateProtocol {
        class Detail: MTranslateProtocol {
            required init(dict: NSDictionary?) {
                betState = dict?["betState"]
                canCombine = dict?["canCombine"]
            }
            var betState:Bool?
            var canCombine:Bool?
            
            init(play:MPlaySort.Detail) {
                betState = play.betState
                canCombine = play.canCombine
            }
        }
        
        required init(dict: NSDictionary?) {
//            edid = dict?["edid"]
            oldDetail = Detail(dict: dict?["oldDetail"])
            newDetail = Detail(dict: dict?["newDetail"])
        }
        
//        var edid:String?
        var oldDetail:Detail?
        var newDetail:Detail?
    }
}

extension ECSocket{
    class MBetsChanged: MTranslateProtocol {
        class Detail: MTranslateProtocol {
            required init(dict: NSDictionary?) {
                betState = dict?["betState"]
                betStateName = dict?["betStateName"]
                openState = dict?["openState"]
                openStateName = dict?["openStateName"]
            }
            
            var betState:Int?
            var betStateName:String?//\":\"成功\",\"
            var openState:Bool?//\":\"0\",\"
            var openStateName:String?//\":\"未派奖\"}
            
        }
        required init(dict: NSDictionary?) {
            bid = dict?["bid"]
            oldDetail = Detail(dict: dict?["oldDetail"])
            newDetail = Detail(dict: dict?["newDetail"])
        }
        
        var bid:String?
        var oldDetail:Detail?
        var newDetail:Detail?
    }
}

extension ECSocket{
    class MOddsChanged:MTranslateProtocol {
        
        class Detail: MTranslateProtocol {
            required init(dict: NSDictionary?) {
                odds = dict?["odds"]
                betState = dict?["betState"]
            }
            
            var odds:Double?
            var betState:Bool?
        }
        
        enum Trend:Int {
            case unchanged = 0
            case up = 1
            case down = 2
        }
        
        required init(dict: NSDictionary?) {
//            edoid = dict?["edoid"]
            oddsState = Trend(rawValue: dict?["oddsState"] ?? 0)
            oldDetail = Detail(dict: dict?["oldDetail"])
            newDetail = Detail(dict: dict?["newDetail"])
        }
        
//        var edoid:String?// = "05dcfa27-5370-4f2f-8f40-e90c47f0e54c";
        var oddsState:Trend?
        var oldDetail:Detail?
        var newDetail:Detail?
    }
}

extension ECSocket{
    class MMatchChanged: MTranslateProtocol {
        class Detail: MTranslateProtocol {
            required init(dict: NSDictionary?) {
                betState = dict?["betState"]
                canCombine = dict?["canCombine"]
                result = dict?["result"]
                state = MEgEgameMatch.MatchState(rawValue: dict?["state"] ?? -1)
                stateName = dict?["stateName"]
            }
            
            var betState:Bool?
            var canCombine:Bool?
            var result:String?
            var state:MEgEgameMatch.MatchState?
            var stateName:String?
        }
        
        required init(dict: NSDictionary?) {
//            mid = dict?["mid"]
            oldDetail = Detail(dict: dict?["oldDetail"])
            newDetail = Detail(dict: dict?["newDetail"])
        }
        
//        var mid:String?
        var oldDetail:Detail?
        var newDetail:Detail?
    }
}
