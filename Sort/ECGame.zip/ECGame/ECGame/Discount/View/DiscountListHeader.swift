//
//  DiscountListHeader.swift
//  ECGame
//
//  Created by Michale on 2019/11/21.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class DiscountListHeader: UISegmentedControl {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    init() {
        super.init(items: ["进行中","已结束"])
        frame = CGRect(origin: .zero, size: CGSize(width:130.scale, height:25.scale))
        backgroundColor = .clear
        tintColor = .clear
        let normalColor = UIColor(red:1, green: 1, blue: 1, alpha: 0.5)
        let font = UIFont(name: "PingFangSC-Regular", size:18.scale)!
        setTitleTextAttributes([NSAttributedString.Key.foregroundColor :normalColor,NSAttributedString.Key.font:font], for: .normal)
        setTitleTextAttributes([NSAttributedString.Key.foregroundColor :UIColor.white,NSAttributedString.Key.font:font], for: .selected)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
