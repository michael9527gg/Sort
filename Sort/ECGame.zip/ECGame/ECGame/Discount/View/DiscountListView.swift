//
//  DiscountListView.swift
//  ECGame
//
//  Created by Michale on 2019/11/21.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

private let reuseId = "id"

protocol DiscountListViewProtocol:class {
    func numberOfItems(in section:Int) -> Int
    func configCell(cell:DiscountListCollectionCell,indexPath:IndexPath) -> Void
    func didSelect(indexPath:IndexPath) -> Void
}

class DiscountListView: UICollectionView {
    weak var csDelegate:DiscountListViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let leading = 15.scale
        let flow = UICollectionViewFlowLayout()
        flow.itemSize = CGSize(width: kScreenWidth - 2 * leading, height: 210.scale)
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 20.scale
        flow.sectionInset = UIEdgeInsets(top:leading, left:leading,bottom:leading, right:leading)
        super.init(frame: frame, collectionViewLayout:flow)
        delegate = self
        dataSource = self
        backgroundColor = .line
        register(DiscountListCollectionCell.self, forCellWithReuseIdentifier: reuseId)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension DiscountListView:UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        csDelegate?.didSelect(indexPath: indexPath)
    }
}

extension DiscountListView:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:reuseId, for: indexPath) as! DiscountListCollectionCell
        csDelegate?.configCell(cell: cell, indexPath:indexPath)
        return cell
    }
}
