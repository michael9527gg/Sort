//
//  DiscountListCollectionCell.swift
//  EEGame
//
//  Created by Michale on 2019/10/7.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

public class DiscountListCollectionCell: UICollectionViewCell {
    
    let image = UIImageView()
    let title = UILabel()
    let time  = TimeLable()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        image.backgroundColor = .clear
        image.clipsToBounds = true
        image.layer.cornerRadius = 8.scale
//        image.image = UIImage(named: "test0000")
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(140.scale)
        }
        
        title.backgroundColor = .clear
        title.textColor = .white
        title.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
//        title.text = "新人有好礼，注册送18财经"
        title.textAlignment = .left
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.leading.equalTo(image)
            make.top.equalTo(image.snp.bottom).offset(10.scale)
        }
        
        
        contentView.addSubview(time)
//        time.text = "2019年04月16日-2019年04月30日"
        time.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(13.scale)
        }
        
        let checkLable = UILabel()
        checkLable.text = "查看 >"
        checkLable.textAlignment = .right
        checkLable.textColor = .tintColor
        checkLable.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        contentView.addSubview(checkLable)
        checkLable.snp.makeConstraints { (make) in
           make.trailing.equalTo(image)
            make.centerY.equalTo(title)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension DiscountListCollectionCell{
    class TimeLable: UILabel {
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            let ck = UIColor.marchName.withAlphaComponent(0.5)
            backgroundColor = UIColor.clear
            textAlignment = .center
            textColor = ck
            layer.borderWidth = 1
            layer.cornerRadius = 2
            layer.borderColor = ck.cgColor
            font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        }
        
        override var intrinsicContentSize: CGSize{
            let s = super.intrinsicContentSize
            return CGSize(width: s.width + 10.scale, height: s.height + 6.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
