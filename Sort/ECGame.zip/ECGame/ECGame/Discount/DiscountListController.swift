//
//  DiscountListController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class DiscountListController: BaseController {

    private let vm = VMDiscountList()
    let collectionView = DiscountListView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let right = UIBarButtonItem(image: UIImage(named: "customer service")?.withRenderingMode(.alwaysOriginal), style: .done, target: self, action: #selector(rightClick))
        navigationItem.rightBarButtonItem = right
        
        let header = DiscountListHeader()
        header.addTarget(self, action: #selector(valueChanged(segement:)), for: .valueChanged)
        navigationItem.titleView = header
        //default select first one
        header.selectedSegmentIndex = 0
        valueChanged(segement: header)
    }
    
    @objc func rightClick() -> Void {
        
    }
    
    
    @objc func valueChanged(segement:DiscountListHeader){
        let index = segement.selectedSegmentIndex
        collectionView.csDelegate = vm
        collectionView.reloadData()
        vm.getDiscountLists(state:index) {[weak self] (success) in
            self?.collectionView.reloadData()
        }
    }

    
    override func loadView() {
        view = collectionView
        vm.delegate = self
    }
}

extension DiscountListController:VMDiscountListProtocol{
    func didSelect(promotion id: String) {
        let detail = DiscountDetailControler(id: id)
        detail.title = "优惠详情"
        detail.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(detail, animated: true)
    }
}
