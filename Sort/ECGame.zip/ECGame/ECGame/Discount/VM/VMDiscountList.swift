//
//  VMDiscountList.swift
//  ECGame
//
//  Created by Michale on 2019/10/11.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol VMDiscountListProtocol:class {
    func didSelect(promotion id:String) -> Void
}

class VMDiscountList:VMBase {
    var promotions:[MPromotion]?
    weak var delegate:VMDiscountListProtocol?
    
    public func getDiscountLists(state:Int,success:@escaping ((_ success:Bool)->Void)){
        
        BaseInfo.provider.request(.promotionList(state: state, pageIndex: 0, pageSize: 0)) { (_ result:ECResult<[MPromotion]>) in
            if case let .success(list) = result{
                self.promotions = list
                success(true)
            }
        }
    }
    
}

extension VMDiscountList:DiscountListViewProtocol{
    func numberOfItems(in section: Int) -> Int {
        return promotions?.count ?? 0
    }
    
    func configCell(cell: DiscountListCollectionCell, indexPath: IndexPath) {
        let m = promotions![indexPath.row]
        cell.image.setImage(url: m.imgUrl,placeholder: UIImage(named: "image_news_placeholder"))
        cell.title.text = m.title
        cell.time.text = "\(m.fromDate ?? "")-\(m.endDate ?? "")"
    }
    
    func didSelect(indexPath: IndexPath) {
        delegate?.didSelect(promotion: promotions![indexPath.row].pid ?? "")
    }
}
