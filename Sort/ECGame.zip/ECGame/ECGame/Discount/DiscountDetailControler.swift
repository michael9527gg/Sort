//
//  DiscountDetailControler.swift
//  ECGame
//
//  Created by Michale on 2020/1/3.
//  Copyright © 2020 EC. All rights reserved.
//

import Foundation
import WebKit

class DiscountDetailControler: WebViewController {
    init(id:String) {
        let url = "http://10.10.11.54:8080/#/promotions/" + id
        super.init(urlStr: url)
        webView.navigationDelegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setBackButton()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension DiscountDetailControler:WKNavigationDelegate{
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        let js = "(document.getElementsByClassName(\"head\")[0]).remove()"
        webView.evaluateJavaScript(js, completionHandler: nil)
    }
}
