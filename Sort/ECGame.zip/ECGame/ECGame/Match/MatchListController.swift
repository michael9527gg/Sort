//
//  GuessListController.swift
//  EEGame
//
//  Created by Michale on 2019/10/7.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class MatchListController: BaseController {
    let filterResult = FilterTitleView()
    let bottomBar = MatchDetailBottomView()
    let segement = MatchSortSegement(items: ["今日","滚盘","赛前","赛后"])
    let vm = VMMatchList()
    let ctView = MatchListView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setNavigation()
    }
    
    func setNavigation() -> Void {
        updateFilterTitle([])
        segement.frame = CGRect(x: 0, y: 0, width:200.scale, height:50.scale)
        segement.addTarget(self, action: #selector(valueChanged(segement:)), for: .valueChanged)
        segement.selectedSegmentIndex = 0
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: segement)
        
        let filterBtn = UIButton()
        filterBtn.addTarget(self, action: #selector(filter), for: .touchUpInside)
        filterBtn.backgroundColor = .clear
        filterBtn.setTitle("筛选", for: .normal)
        filterBtn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        filterBtn.setTitleColor(.white, for: .normal)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: filterBtn)
    }
    
    func updateFilterTitle(_ egids:[MBaseEgame]?) -> Void {
        vm.egids = egids
        var content = "全部"
        if (egids?.count ?? 0) > 0 {
            content = ""
            for item in egids!{
                content.append(item.name + ",")
            }
            content.removeLast()
        }
        filterResult.set(title: "正在查看 ",content: content)
    }
    
    @objc func valueChanged(segement:MatchSortSegement) -> Void {
        if let sortId = Bet.MatchSortId(rawValue: segement.selectedSegmentIndex+1){
            vm.sortId = sortId
            vm.getMatchList()
        }
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .clear
        view.addSubview(filterResult)
        filterResult.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(view.snp.topMargin)
        }
        
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.top.equalTo(filterResult.snp.bottom)
            make.leading.trailing.equalToSuperview()
        }
        view.addSubview(bottomBar)
        bottomBar.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(ctView.snp.bottom)
            make.height.equalTo(36.scale)
        }
        vm.delegate = self
        ctView.csDelegate = vm
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        vm.remeveObserver()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        vm.addObserver()
        vm.getMatchList()
    }
 
    override func routerEvent(_ event: Any) {
        if case .betClick? = event as? MatchDetailBottomView.Event{
            toSelecteBetController()
        }
    }
    
    @objc func filter() -> Void {
        let f = GameFilterController()
        f.selectedEgame = vm.egids
        f.finishSelect = {[weak self](array) in
            self?.updateFilterTitle(array)
        }
        present(f, animated: true, completion: nil)
    }
}

extension MatchListController:VMMatchListProtocol{
    func toSelecteBetController() {
        let bet = SelectedBetController()
        present(bet, animated: true, completion: nil)
    }
    
    func updateBottom(count: Int) {
        bottomBar.updateBar(count: count)
    }
    
    func updateUI() {
         ctView.reloadData()
    }
    
    func didSelectMatch(id: String) {
        let match = MatchDetailController(mid: id)
        present(match, animated: true, completion: nil)
    }
    
    func success() {
        ctView.reloadData()
    }
}
