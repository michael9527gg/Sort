//
//  VMGameFilter.swift
//  ECGame
//
//  Created by Michale on 2019/10/22.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation


class VMGameFilter: VMBase {
    
    var gameList:[MBaseEgame]?
    
    func getBaseEgameList(success:(()->Void)?) -> Void {
        Bet.provider.request(.baseEgameList) { (_ result:ECResult<[MBaseEgame]>) in
            if case let .success(list) = result{
                self.gameList = list
                success?()
            }
        }
    }
    
    func selected(egames:[MBaseEgame]?) -> [IndexPath]? {
        if egames == nil || egames!.count == 0 {
            return nil
        }
        if gameList == nil || gameList!.count == 0 {
            return nil
        }
        
        var indexPaths = [IndexPath]()
        for item in egames!{
            for (i,o) in gameList!.enumerated(){
                if item.egid == o.egid{
                    indexPaths.append(IndexPath(row:i+1, section:0))
                }
            }
        }
        
        return indexPaths.count > 0 ? indexPaths : nil
    }
}

extension VMGameFilter:GameFilterViewProtocol{
    func numberOfItem(in section: Int) -> Int {
        if let n = gameList?.count{
            return n+1
        }
        return 0
    }
    
    func cellType(at indexPath: IndexPath) -> GameFilterView.CellType {
        if indexPath.row == 0 {
            return .all("全部")
        }
        let m = gameList![indexPath.row - 1]
        return .game(title: m.name, url:m.logo)
    }
    
    func didSelectItem(at indexPath: IndexPath, _ view: GameFilterView) {
        
        if indexPath.row == 0 ,let items = view.indexPathsForSelectedItems{
            for item in items{
                if item.row != 0{
                    view.deselectItem(at: item, animated: true)
                }
            }
        }
        
        if indexPath.row > 0 {
            view.deselectItem(at:IndexPath(row: 0, section: 0), animated: true)
        }
    }
    
    func didDeselectItem(at indexPath: IndexPath, _ view: GameFilterView) {
        let first = IndexPath(row: 0, section: 0)
        if indexPath.row == 0{
            view.selectItem(at:first , animated: true, scrollPosition: .init(rawValue: 0))
            return
        }
        
        if view.indexPathsForSelectedItems?.count == 0{
            view.selectItem(at:first, animated: true, scrollPosition: .init(rawValue: 0))
            return
        }
    }
}
