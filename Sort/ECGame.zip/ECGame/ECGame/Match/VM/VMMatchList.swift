//
//  VMMatchList.swift
//  ECGame
//
//  Created by Michale on 2019/10/21.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMMatchListProtocol:class {
    func updateBottom(count:Int) -> Void
    
    func updateUI() -> Void
    
    func success() -> Void
    
    func didSelectMatch(id:String) -> Void
    
    func toSelecteBetController() -> Void
}

class VMMatchList: VMMatchObserver {
    
    var sortId:Bet.MatchSortId = .today
    var egids:[MBaseEgame]?
    
    weak var delegate:VMMatchListProtocol?
    
    override func updateUI() {
        delegate?.updateUI()
    }
    
    func getMatchList() -> Void {
        var ids:[String]?
        if let array = egids,array.count > 0{
            ids = []
            for item in array{
                ids?.append(item.egid)
            }
        }
        Bet.provider.request(.egEgameMatchList(egids:ids, sortID:sortId, pageIndex: 0, pageSize:0)) { (_ result:ECResult<[MEgEgameMatch]>) in
            if case let .success(list) = result{
                self.matchList = list
                self.delegate?.success()
                self.updateBottomBar()
            }
        }
    }
    
    func updateBottomBar() -> Void {
        delegate?.updateBottom(count:  SelectedOdds.current.odd.count)
    }
    
}

extension VMMatchList:MatchListViewProtocol{
    func numberOfItems(in section: Int) -> Int {
        return matchList?.count ?? 0
    }
    
    func configMatch(cell: MatchListCell, indexPath: IndexPath) {
        let match = matchList![indexPath.row]
        cell.updateUI(with: match)
        cell.btnAction = {[weak self] (type,isSelected) in
            var team:MEgEgameMatch.Team?
            switch type {
            case .left:
                team = match.egEgameMatchTeamList?.left
            case .right:
                team = match.egEgameMatchTeamList?.right
            }

        
            if isSelected {
                let m = SelectedOdds.Match(match: match)
                
                let p = SelectedOdds.Play()
                p.edid = match.edid
                p.canCombine = match.playDetail?.canCombine
                p.betState = match.playDetail?.betState
                p.mid = match.mid
                
                let odd = SelectedOdds.Odd(team: team)
                odd.hTeam = match.egEgameMatchTeamList?.left.team ?? ""
                odd.vTeam = match.egEgameMatchTeamList?.right.team ?? ""
                odd.playName = match.playName
                odd.playSortName = match.playSortName
                odd.minMoney = match.minMoney
                odd.maxMoney = match.maxMoney
                odd.edid = match.edid
                
                SelectedOdds.current.add(odd: odd, play:p, match: m)
            }else{
                SelectedOdds.current.remove(edoid: team?.edoid ?? "")
            }
            
            self?.updateBottomBar()
            
            if isSelected && SelectedOdds.current.odd.count == 1{
                self?.delegate?.toSelecteBetController()
            }
        }
    }
    
    func didSelectMatch(at indexPath: IndexPath) {
        delegate?.didSelectMatch(id: matchList![indexPath.row].mid)
    }
}

extension MEgEgameMatch:MatchListCellProtocol{
    var matchTitle: String? {
        var str = ""
        if bo > 0{
            str = String(format:" - B%02d",bo)
        }
        return matchName + str
    }
    
    var totalPlayCount: String? {
        return "+\(playCount)"
    }
    
    var cellAlpha: CGFloat {
        switch state {
        case .canceled?:
            return 0.5
        default:
            return 1
        }
    }
    
    var stateImage: String? {
        switch state {
        case .living?:
            return "icon_living"
        case .willRoll?:
            return "icon_countdown"
        case .willBegin?:
            return "icon_countdown_grey"
        case .rolling?:
            return "icon_deadline"
        case .over?:
            return "icon_end"
        case .canceled?:
            return "icon_countdown"
        default:
            break
        }
        return nil
    }
    
    var leftMatch: MatchTeamView.Match? {
        let which = egEgameMatchTeamList?.left
        return oddState(which: which)
    }
    
    private func oddState(which:Team?) -> MatchTeamView.Match {
        let detail = MatchTeamView.Match()
        detail.name = which?.team
        detail.url = which?.teamLogo
        
        let str = String(format: "%.02f",which?.odds ?? 0)
        let odds = MatchOddsButton.Content()
        odds.type = .center
        odds.isEnable = false
        
        // first time set isSelected
        if which != nil && which!.isSelected == nil{
            var isSelected = false
                for item in  SelectedOdds.current.odd{
                    if item.edoid == which?.edoid{
                        isSelected = true
                        break
                    }
                }
            which?.isSelected = isSelected
        }
        
        odds.isSelected = which?.isSelected ?? false
        
        switch which?.result{
        case .nothing?:
            if betState && (playDetail?.betState ?? false) && (which?.oddsBetState ?? false){
                odds.isEnable = true
                switch which?.trend {
                case .some(.up):
                    odds.odds = .up(str)
                case .some(.down):
                    odds.odds = .down(str)
                default:
                    odds.odds = .default(str)
                }
            }else{//lock
                odds.odds = .lock
            }
        case .win?:
            odds.odds =  .lock//.result(true)
        case .lose?:
            odds.odds =  .lock//.result(false)
        case .noResult?:
            odds.odds = .error("无结果")
        case .canceled?:
            odds.odds = .error("已取消")
        default:
            break
        }
        
        detail.content = odds
        
        switch which?.result {
        case .some(.win):
            detail.stateImage = "win"
        case .some(.lose):
            detail.stateImage = "lose"
        default:
            detail.stateImage = nil
        }
        
        return detail
    }
    
    var rightMatch: MatchTeamView.Match? {
        let which = egEgameMatchTeamList?.right
        return oddState(which: which)
    }
    
    var centerAttr: NSAttributedString? {
        var attr:NSAttributedString?
        switch state {
        case .over?, .living?,.rolling?:
            let date = Date(timeIntervalSince1970:matchDateTime/1000)
            let formate = DateFormatter()
            formate.dateFormat = "yyyy-MM-dd HH:mm"
            let time = formate.string(from: date)
            let font:UIFont = UIFont(name: "DBLCDTempBlack", size: 30.scale)!
            attr = attrFor(line1:time, line2:result,font2:font,lineSpacing:6.scale)

//            attr = NSAttributedString(string: result, attributes: [NSAttributedString.Key.font:font,NSAttributedString.Key.foregroundColor:UIColor.white])
        case .willRoll?,.willBegin?:
            let date = Date(timeIntervalSince1970:matchDateTime/1000)
            let formate = DateFormatter()
            if Calendar.current.isDateInToday(date){
                formate.dateFormat = "HH:mm"
                let hour = formate.string(from: date)
                attr = attrFor(line1: "今天", line2: hour)
            }else if Calendar.current.isDateInTomorrow(date){
                formate.dateFormat = "HH:mm"
                let hour = formate.string(from: date)
                attr = attrFor(line1: "明天", line2: hour)
            }else{
                formate.dateFormat = "yyyy-MM-dd"
                let year = formate.string(from: date)
                formate.dateFormat = "HH:mm"
                let hour = formate.string(from: date)
                attr = attrFor(line1: year, line2: hour)
            }
        case .canceled?:
            attr = attrFor(line1: "", line2: "已取消")
        default:
            break
        }
        return attr
    }
    
    
    private func attrFor(line1:String,font1:UIFont = UIFont(name: "PingFangSC-Regular", size: 10.scale)!,kern1:CGFloat = 0, line2:String,font2:UIFont = UIFont(name: "PingFangSC-Regular", size: 18.scale)!,kern2:CGFloat = 0,lineSpacing:CGFloat = 0)->NSAttributedString?{
        
        var attr :NSMutableAttributedString?
        let b = (Int(truncating: NSNumber(booleanLiteral: line1.count>0)) << 1) | Int(truncating: NSNumber(booleanLiteral: line2.count>0))
        
        switch b {
        case 0b11:
            let str = line1 + "\n" + line2
            attr = NSMutableAttributedString(string: str, attributes: [NSAttributedString.Key.foregroundColor: UIColor.marchName,NSAttributedString.Key.font:font1,NSAttributedString.Key.kern:kern1])
            attr!.setAttributes([NSAttributedString.Key.font : font2,NSAttributedString.Key.kern:kern2,NSAttributedString.Key.foregroundColor:UIColor.white], range: NSMakeRange(line1.count,line2.count+1))
            let style = NSMutableParagraphStyle()
            style.lineSpacing = lineSpacing
            style.alignment = .center
            attr!.addAttribute(NSAttributedString.Key.paragraphStyle, value: style, range: NSMakeRange(0, str.count))
        case 0b01:
            attr = NSMutableAttributedString(string: line2, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white,NSAttributedString.Key.font:font2,NSAttributedString.Key.kern:kern2])
        case 0b10:
            attr = NSMutableAttributedString(string: line1, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white,NSAttributedString.Key.font:font1,NSAttributedString.Key.kern:kern1])
        default:
            break
        }
        return attr
    }
}
