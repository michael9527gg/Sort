//
//  SelectedOdds.swift
//  ECGame
//
//  Created by Michale on 2020/1/1.
//  Copyright © 2020 EC. All rights reserved.
//

import Foundation

protocol SelectedOddsProtocol:class {
    func oddDidChanged() -> Void
}

class SelectedOdds {
    static let current = SelectedOdds()
    weak var delegate:SelectedOddsProtocol?
   
    var match = [String:Match]()
    var play  = [String:Play]()
    var odd = [Odd]()
    
    /// 筛选出串关赔率
    var serialOdd:[Odd]{
        var dict = [String:Odd]()
        for o in odd{
            if o.result != .nothing{
                continue
            }
            
            let p = play[o.edid ?? ""]
            let m = match[p?.mid ?? ""]
            
            if dict[p?.mid ?? ""] != nil{
                continue
            }
            if m?.canCombine == true && p?.canCombine == true{
                dict[p?.mid ?? ""] = o
            }
        }
        return Array(dict.values)
    }
    
    func add(odd:Odd,play:Play,match:Match) -> Void {
        remove(edoid: odd.edoid)
        if let mid = match.mid {
           self.match[mid] = match
        }
        if let edid = play.edid{
            self.play[edid] = play
        }
        self.odd.append(odd)
    }
    
    /// 删除指定的赔率
    func remove(edoid:String) -> Void {
        var edid:String?
        odd.removeAll { (bet) -> Bool in
            if bet.edoid == edoid{
                edid = bet.edid
                return true
            }
            return false
        }
        
        guard let id = edid else { return }
        var isFind = false
        for o in odd{
            if o.edid == id{
                isFind = true
                break
            }
        }
        
        if !isFind {
            let mid = play[id]?.mid
            play.removeValue(forKey:id)
            
            guard let i = mid else{return}
            
            for (_,p) in play{
                if p.mid == i{
                    isFind = true
                    break
                }
            }
            
            if !isFind{
                match.removeValue(forKey:i)
            }
        }
    }
    
    init() {
        ECSocket.add(delegates:[.match(self),.odds(self),.play(self)])
    }
}

extension SelectedOdds:ECSocketMatchProtocol{
    func matchDidChanged(_ match: [String : ECSocket.MMatchChanged]) {
        var should = false
        
        for (mid,m) in self.match {
            if let d = match[mid],let n = d.newDetail{
                should = true
                m.betState = n.betState
                m.canCombine = n.canCombine
            }
        }
        
        if should{
            delegate?.oddDidChanged()
        }
    }
}

extension SelectedOdds:ECSocketOddsProtocol{
    func oddsDidChanged(_ odds: [String : [String : ECSocket.MOddsChanged]]) {
        var should = false
        
        for (mid,_) in self.match {
            if let dict = odds[mid]{
                for o in self.odd{
                    if let odd = dict[o.edoid]{
                        should = true
                        
                        o.trend = odd.oddsState
                        o.oddsBetState = odd.newDetail?.betState ?? false
                        o.odds = odd.newDetail?.odds ?? 0
                    }
                }
            }
        }
        
        if should{
            delegate?.oddDidChanged()
        }
    }
}

extension SelectedOdds:ECSocketPlayProtocol{
    func playDidChanged(_ play: [String : [String : ECSocket.MPlayChanged]]) {
        var should = false

        for (mid,_) in self.match{
            if let m = play[mid]{
                for (edid,p) in self.play{
                    if let c = m[edid]{
                        should = true
                        p.betState = c.newDetail?.betState
                        p.canCombine = c.newDetail?.canCombine
                    }
                }
            }
        }
        
        if should{
            delegate?.oddDidChanged()
        }
    }
}

extension SelectedOdds{
    class Match {
        
        init(match:MEgEgameMatch?) {
            mid = match?.mid
            betState = match?.betState
            canCombine = match?.canCombine
        }
        
        /// 比赛ID
        var mid:String?
        var canCombine:Bool?
        var betState:Bool?//投注状态（0、封盘 1、开盘）
    }
    
    class Play:ECSocket.MPlayChanged.Detail {
        init() {
            super.init(dict: nil)
        }
        
        required init(dict: NSDictionary?) {
            fatalError("init(dict:) has not been implemented")
        }
        /// 玩法ID
        var edid:String?
        
        ///所属的比赛ID
        var mid:String?
    }
    
    class Odd:MPlaySort.Detail.Odds {
        
        init(odds:MPlaySort.Detail.Odds) {
            super.init(dict: nil)
            edoid = odds.edoid
            oddsName = odds.oddsName
            self.odds = odds.odds
            oddsBetState = odds.oddsBetState
            result = odds.result
        }
        
        init(team:MEgEgameMatch.Team?) {
            super.init(dict: nil)
            if team == nil{
                return
            }
            edoid = team!.edoid
            oddsName = team!.oddsName
            odds = team!.odds
            result = team!.result
            oddsBetState = team!.oddsBetState
        }
        
        required init(dict: NSDictionary?) {
            fatalError("init(dict:) has not been implemented")
        }
        
        var minMoney:Double = 0
        var maxMoney:Double = 0
        var playSortName = ""
        var playName = ""
        var input = ""
        var hTeam = ""
        var vTeam = ""
        
        var edid:String? //所属的玩法ID
        
        var trend:ECSocket.MOddsChanged.Trend?//自定义字段,赔率变化
    }
}
