//
//  VMMatchObserver.swift
//  ECGame
//
//  Created by Michale on 2019/12/16.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class VMMatchObserver: VMBase,ECSocketOddsProtocol,ECSocketMatchProtocol,ECSocketPlayProtocol {
    var matchList:[MEgEgameMatch]?
    
    ///子类实现
    func updateUI() -> Void {
    }
    
    func addObserver() -> Void {
        ECSocket.add(delegates:[.odds(self),.play(self),.match(self)])
    }
    
    func remeveObserver() -> Void {
        ECSocket.remove(delegates:[.odds(self),.play(self),.match(self)])
    }
    
    func playDidChanged(_ play: [String : [String : ECSocket.MPlayChanged]]) {
        guard let list = matchList else { return }
        var should = false
        for item in list {
            if let team = play[item.mid],let p = team[item.edid ?? ""]{
                should = true
                item.playDetail = p.newDetail
            }
        }
        if should{
            updateUI()
        }
    }
    
    func matchDidChanged(_ match: [String : ECSocket.MMatchChanged]) {
        guard let list = matchList else{ return }
        
        var should = false
        for item in list {
            if let m = match[item.mid],let new = m.newDetail{
                should = true
                item.betState = new.betState ?? false
                item.canCombine = new.canCombine ?? false
                item.result = new.result ?? ""
                item.state = new.state
                item.stateName =  new.stateName ?? ""
            }
        }
        
        if should{
            updateUI()
        }
    }
    
    func oddsDidChanged(_ odds: [String : [String : ECSocket.MOddsChanged]]) {
        guard let list = matchList else {
            return
        }
        var should = false
        for item in list {
            if let m = item.egEgameMatchTeamList,let team = odds[item.mid]{
                if let left = team[m.left.edoid]{
                    should = true
                    let l = item.egEgameMatchTeamList?.left
                    l?.odds = left.newDetail?.odds ?? 0
                    l?.oddsBetState = left.newDetail?.betState ?? false
                    l?.trend = left.oddsState
                }
                if let right = team[m.right.edoid]{
                    should = true
                    let r = item.egEgameMatchTeamList?.right
                    r?.odds = right.newDetail?.odds ?? 0
                    r?.oddsBetState = right.newDetail?.betState ?? false
                    r?.trend = right.oddsState
                }
            }
        }
        
        if should {
            updateUI()
        }
    }
}
