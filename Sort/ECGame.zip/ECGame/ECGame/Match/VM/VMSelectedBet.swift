//
//  VMBetList.swift
//  ECGame
//
//  Created by Michale on 2019/10/31.
//  Copyright © 2019 EC. All rights reserved.
//


import Foundation
import UIKit

class VMSelectedBet: VMBase {
    
    var serialOdd:[SelectedOdds.Odd]?
    
    func attr(isSingle:Bool,input:Double?,totalOdds:Double) -> NSAttributedString? {
        let n =  input ?? 0
        
        var totalInput:Double = 0
        var totalMoney:Double = 0
        if isSingle{
            for item in SelectedOdds.current.odd{
                let input = Double(item.input) ?? 0
                totalInput += input
                totalMoney += item.odds * input
            }
        }
        
        let str1 = isSingle ? "总投注额 " :"总赔率 "
        let str2 = (isSingle ? "¥ \(totalInput)" : String(format: "%.2f",totalOdds)) + "\n"
        let str3 = "最高可赢 "
        let str4 = "¥ " + String(format: "%.2f", isSingle ? totalMoney : totalOdds * n)
        let str = str1 + str2 + str3 + str4
        let attr = NSMutableAttributedString(string:str, attributes: [NSAttributedString.Key.font :UIFont(name: "PingFangSC-Regular",size:12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.note])
        let ck:UIColor = isSingle ? .tintColor : .odds
        attr.addAttributes([NSAttributedString.Key.foregroundColor:ck], range:NSRange(location: str1.count, length: str2.count))
        attr.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white,NSAttributedString.Key.font:UIFont(name: "PingFangSC-Medium", size: 14.scale)!], range:NSRange(location:str.count - str4.count, length: str4.count))
        return attr
    }
    
    func moneyLimit() -> (min:Double,max:Double,odds:Double) {
        var min:Double = 0
        var max:Double?
        var odds:Double = 1
        if serialOdd != nil {
            for item in serialOdd!{
                if item.minMoney > min{
                    min = item.minMoney
                }
                odds *= item.odds
                if item.maxMoney < (max ?? Double.greatestFiniteMagnitude){
                    max = item.maxMoney
                }
            }
        }
        return (min:min,max:max ?? 0,odds:odds)
    }
    
    private func preparePay(ctr:UIViewController,completion:@escaping (_ isLogin:Bool)->Void) -> Void {
        if Account.current != nil{//已经登陆
            completion(true)
        }else{
            let tip = DarkAlertController(title: "登陆成功才能下注", buttons: [.default(title: "注册", action: {
                let pack = PackageLogin()
                pack.startRegister(ctr, completion: { (success) in
                    completion(success)
                })
            }),.hilight(title: "登陆", action: {
                let pack = PackageLogin()
                pack.startLogin(ctr, completion: { (success) in
                    completion(success)
                })
            })])
            ctr.present(tip, animated: true, completion: nil)
        }
    }
    
    
    func singelPay(ctr:UIViewController,acceptOddsChange:Bool)->Void{
        preparePay(ctr: ctr) { (isLogin) in
            if isLogin == false{
                return
            }
            var list = [NSDictionary]()
            for i in  SelectedOdds.current.odd{
                if i.input.count > 0, let input = Double(i.input),input >= i.minMoney{
                    list.append(["edoid":i.edoid,"money":Decimal(input),
                                 "betOdds":Decimal(i.odds)])
                }
            }
            if list.count == 0 {
                return
            }
            
            Bet.provider.request(.singleBet(list:list, acceptOddsChange:acceptOddsChange,userID:Account.current?.token?.userID ?? "")){ (_ result:ECResult<Any>) in
                switch result{
                case .untranslate:
                    self.betSuccess(ctr)
                case let .failed(code, msg):
                    switch code{
                    case 11: //余额不足
                        self.noEnoughMoney(ctr,msg)
                    default:
                        self.otherError(ctr, msg)
                    }
                case .unreachable:
                    self.otherError(ctr, "网络无法连接")
                default:
                    self.otherError(ctr, "其他错误")
                }
            }
        }
    }
    
    func otherError(_ ctr:UIViewController,_ msg:String) -> Void{
        let alert = DarkAlertController(title:msg, buttons:[.default(title: "稍后再试试", action: {
            
        })])
        ctr.present(alert, animated: true, completion: nil)
    }
    
    func noEnoughMoney(_ ctr:UIViewController,_ msg:String) -> Void {
        let alert = DarkAlertController(title:msg, buttons:[.default(title: "先看看", action: {
            
        }),.hilight(title: "去充值", action: {
            
        })])
        ctr.present(alert, animated: true, completion: nil)
    }
    
    func betSuccess(_ ctr:UIViewController) -> Void {
        let alert = DarkAlertController(title: "投注成功！", buttons:[.default(title: "查看注单", action: {
            let nav = NavigationController(rootViewController: Record())
            ctr.present(nav, animated: true, completion: nil)
        }),.hilight(title: "继续投注", action: {
            
        })])
        ctr.present(alert, animated: true, completion: nil)
    }
    
    func multiplePay(ctr:UIViewController,acceptOddsChange:Bool,money:Decimal)->Void{
        guard let array = serialOdd,array.count > 0 else{
            return
        }
        preparePay(ctr: ctr) { (isLogin) in
            if isLogin == false{
                return
            }
            var list = [NSDictionary]()
            for i in array{
                list.append(["edoid":i.edoid,"betOdds":Decimal(i.odds)])
            }
            if list.count == 0 {
                return
            }
            
            Bet.provider.request(.multipleBet(list:list, acceptOddsChange:acceptOddsChange, money:money, userID:Account.current?.token?.userID ?? "")) { (_ result:ECResult<Any>) in
                switch result{
                case .untranslate:
                    self.betSuccess(ctr)
                case let .failed(code, msg):
                    switch code{
                    case 11: //余额不足
                        self.noEnoughMoney(ctr,msg)
                    default:
                        self.otherError(ctr, msg)
                    }
                case .unreachable:
                    self.otherError(ctr, "网络无法连接")
                default:
                    self.otherError(ctr, "其他错误")
                }
            }
        }
    }
}

extension VMSelectedBet:BetListTableViewProtocol{
    func maxMoney(at row: Int) -> String {
         let m:SelectedOdds.Odd = (serialOdd != nil) ? serialOdd![row] :  SelectedOdds.current.odd[row]
        return "\(m.maxMoney)"
    }
    
    func configCell(cell: BetListTableCell, row: Int) {
        let m:SelectedOdds.Odd = (serialOdd != nil) ? serialOdd![row] :  SelectedOdds.current.odd[row]
        let name = m.hTeam + " vs " + m.vTeam
        //Team
        var attr = NSMutableAttributedString(string: name, attributes: [NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.note])
        cell.team.attributedText = attr
        
        //playName
        attr = NSMutableAttributedString(string:m.playSortName + " · " + m.playName,attributes: [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size: 12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.note])
        attr.addAttributes([NSAttributedString.Key.foregroundColor:UIColor.forgetPwd], range: NSRange(location: 0, length: m.playSortName.count))
        cell.playName.attributedText = attr
        
        cell.odds.content = oddsContent(odds: m)
        cell.bet = m
        
        cell.textField.text = m.input
        cell.winMoney.isHidden = serialOdd != nil
        
        if cell.odds.content?.isEnable == true {
            if serialOdd != nil{
                cell.lock.isHidden = false
                cell.lock.text = nil
                cell.textField.isUserInteractionEnabled = false
            }else{
                cell.lock.isHidden = true
                cell.textField.isUserInteractionEnabled = true
            }
        }else{ //lock
            cell.lock.isHidden = false
            cell.textField.isUserInteractionEnabled = false
            cell.lock.text = "已锁住，无法下注"
        }
        
        cell.updateText()
    }
    
    func deleteCell(_ row: Int) -> Void {
        if serialOdd != nil {
            serialOdd!.remove(at:row)
        }
        
        let ret =  SelectedOdds.current.odd[row]
        SelectedOdds.current.remove(edoid:ret.edoid)
    }
    
    func numberOfRows() -> Int {
        if serialOdd != nil{
            return serialOdd!.count
        }
        return  SelectedOdds.current.odd.count
    }
}


extension VMSelectedBet{
    private func oddsContent(odds:SelectedOdds.Odd) -> MatchOddsButton.Content{
        var isEnable = false
        let content = MatchOddsButton.Content()
        content.type = .left
        content.name = odds.oddsName
        
        switch odds.result{
        case .nothing:
            let play = SelectedOdds.current.play[odds.edid ?? ""]
            let match = SelectedOdds.current.match[play?.mid ?? ""]
            let playBetState = play?.betState ?? false
            let matchBetState = match?.betState ?? false
            
            if matchBetState && playBetState && odds.oddsBetState{
                isEnable = true
                switch odds.trend {
                case .some(.up):
                    content.odds = .up("\(odds.odds)")
                case .some(.down):
                    content.odds = .down("\(odds.odds)")
                default:
                    content.odds = .default("\(odds.odds)")
                }
            }else{//lock
                content.odds = .lock
            }
        case .win:
            content.odds = .result(true)
        case .lose:
            content.odds = .result(false)
        case .noResult:
            content.odds = .error("无结果")
        case .canceled:
            content.odds = .error("已取消")
        }
        content.isEnable = isEnable
        content.isSelected = true
        
        return content
    }
}

extension VMSelectedBet{
    class Record: BettingRecordController {
        override func leftClick() {
            dismiss(animated: true, completion: nil)
        }
    }
}
