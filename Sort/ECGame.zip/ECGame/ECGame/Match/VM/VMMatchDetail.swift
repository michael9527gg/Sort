//
//  VMMatchDetail.swift
//  ECGame
//
//  Created by Michale on 2019/10/23.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit


protocol VMMatchDetailProtocol:class {
    func updateBottom(count:Int) -> Void
    func success() -> Void
    func oddsDidChanged() -> Void
    func matchDidChanged() -> Void
}

extension MMatchDetail{
    var egEgameMatch:MEgEgameMatch{
        let m = MEgEgameMatch(dict: nil)
        m.mid = defaultMatchDetails?.mid ?? ""
        m.edid = defaultMatchDetails?.edid
        m.matchName = defaultMatchDetails?.matchName ?? ""
        m.state = defaultMatchDetails?.state
        m.stateName = defaultMatchDetails?.stateName ?? ""
        m.matchDateTime = defaultMatchDetails?.matchDateTime ?? 0
        m.result = defaultMatchDetails?.result ?? ""
        m.betState = defaultMatchDetails?.betState ?? false
        m.canCombine = defaultMatchDetails?.canCombine ?? false
        
        let left = MEgEgameMatch.Team(dict: nil)
        left.team = defaultMatchDetails?.hTeam ?? ""
        left.teamLogo = defaultMatchDetails?.hTeamLogo ?? ""
        left.odds = defaultMatchDetails?.hTeamOdds ?? 0
        left.edoid = defaultMatchDetails?.hTeamEDOID ?? ""
        
        let right = MEgEgameMatch.Team(dict: nil)
        right.team = defaultMatchDetails?.vTeam ?? ""
        right.teamLogo = defaultMatchDetails?.vTeamLogo ?? ""
        right.odds = defaultMatchDetails?.vTeamOdds ?? 0
        right.edoid = defaultMatchDetails?.vTeamEDOID ?? ""
        
        m.egEgameMatchTeamList = (left:left,right:right)
        return m
    }
}

class VMMatchDetail: VMMatchObserver {
    struct Segement {
        var title:String
        var index:Int
    }
    
    weak var delegate:VMMatchDetailProtocol?

    private var selectedCount = 0
    private var segements = [Segement]()
    private var cells = [MatchDetailView.CellType]()
    private var mid:String
    private var plays = [String:ECSocket.MPlayChanged.Detail]() //所有玩法
    
    init(mid:String) {
        self.mid = mid
        super.init()
        addObserver()
    }
    
    override func updateUI() {
        delegate?.success()
    }
    
    override func playDidChanged(_ play: [String : [String : ECSocket.MPlayChanged]]) {
        super.playDidChanged(play)
        
        guard let dict = play[mid] else {
            return
        }
        
        if dict.count == 0 {
            return
        }
        
        for (key,value) in dict {
            if let o = value.newDetail{
                plays[key] = o
            }
        }
        
        delegate?.oddsDidChanged()
    }
    
  
    override func oddsDidChanged(_ odds: [String : [String : ECSocket.MOddsChanged]]) {
        super.oddsDidChanged(odds)
        
        guard let current = odds[mid] else{
            return
        }
        
        var changed = false
        
        for (i,item) in cells.enumerated(){
            if case let .button(p) = item,let data = p as? ButtonData,
                let odd = current[data.edoid]{
                changed = true
                
                data.trend = odd.oddsState
                data.odds = odd.newDetail?.odds ?? 0
                data.oddsBetState = odd.newDetail?.betState ?? false
                cells[i] = .button(data)
            }
        }
        
        if changed {
            delegate?.oddsDidChanged()
        }
    }
    
    func getMatchDetail() -> Void {
        Bet.provider.request(.egEgameMatchDetails(mid: mid)) { (_ result:ECResult<MMatchDetail>) in
            if case let .success(match) = result{
                self.transalte(match: match)
                self.delegate?.success()
                self.delegate?.updateBottom(count: self.selectedCount)
            }
        }
    }
    
    private func oddsContent(button:ButtonData) -> MatchOddsButton.Content{
        let odds = button
        let edid = button.edid!
        let isLeft = button.isLeft!
        
        var isEnable = false
        let content = MatchOddsButton.Content()
        content.type = isLeft ? .left : .right
        content.name = odds.oddsName
        
        switch odds.result{
        case .nothing:
            let matchBetState = matchList?.first?.betState ?? false
            let playBetState = plays[edid]?.betState ?? false
            
            if matchBetState && playBetState && odds.oddsBetState{
                isEnable = true
                switch button.trend {
                case .some(.up):
                    content.odds = .up("\(odds.odds)")
                case .some(.down):
                    content.odds = .down("\(odds.odds)")
                default:
                    content.odds = .default("\(odds.odds)")
                }
            }else{//lock
                content.odds = .lock
            }
        case .win:
            content.odds = .result(true)
        case .lose:
            content.odds = .result(false)
        case .noResult:
            content.odds = .error("无结果")
        case .canceled:
            content.odds = .error("已取消")
        }
        content.isEnable = isEnable
        content.isSelected = button.isSelected
        
        return content
    }
    
    private func transalte(match:MMatchDetail) ->Void{
        matchList = [match.egEgameMatch]
        cells.removeAll()
        selectedCount = 0
        segements.removeAll()
        plays.removeAll()
        
        if let sortList = match.basePlaySortList, sortList.count > 0{
            
            for sort in sortList{
                let play = sort.egEgameMatchDetailsList
                if play == nil || play?.count == 0{
                    continue
                }
                segements.append(Segement(title:sort.playSortName, index: cells.count))
                for p in play!{
                    if let details = p.egEgameMatchDetailOddsList,details.count > 0{
                        
                        let attr = NSMutableAttributedString(string:sort.playSortName + " · " + p.playName,attributes: [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size: 12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.note])
                        attr.addAttributes([NSAttributedString.Key.foregroundColor:UIColor.forgetPwd], range: NSRange(location: 0, length: sort.playSortName.count))
                        
                        cells.append(.title(attr))
                        
                        var index = -1
                        for item in details{
                            index += 1
                            
                            let data = ButtonData(odds: item)
                            data.playSortName = sort.playSortName
                            data.playName = p.playName
                            data.vTeam = match.defaultMatchDetails?.vTeam ?? ""
                            data.hTeam = match.defaultMatchDetails?.hTeam ?? ""
                            data.minMoney = p.minMoney
                            data.maxMoney = p.maxMoney
                            data.edid = p.edid
                            data.isLeft = index%2==0
                            data.parent = self
                            cells.append(.button(data))
                            
                            selectedCount += data.isSelected ? 1 : 0
                        }
                        if let key = p.edid{
                            plays[key] = ECSocket.MPlayChanged.Detail(play:p)
                        }
                    }
                }
            }
        }
    }
}

extension VMMatchDetail:MatchDetailViewProtocol{
    func didSelectButton(at row: Int, isSelected: Bool) {
        if case let .button(data)  = cells[row],let odd = data as? ButtonData{
            if isSelected {
                selectedCount += 1
                
                let m = SelectedOdds.Match(match: matchList?.first)
                
                let currentPlay = plays[odd.edid ?? ""]
                let p = SelectedOdds.Play()
                p.mid = m.mid
                p.edid = odd.edid
                p.betState = currentPlay?.betState
                p.canCombine = currentPlay?.canCombine
                
                SelectedOdds.current.add(odd:odd, play:p, match:m)
            }else{
                selectedCount -= 1
                SelectedOdds.current.remove(edoid:odd.edoid)
            }
            delegate?.updateBottom(count: selectedCount)
        }
    }
    
    func numberOfCell() -> Int {
        return cells.count
    }
    
    func cellForItem(at row: Int) -> MatchDetailView.CellType {
        return cells[row]
    }
    
    func sectionType(at section: Int) -> MatchDetailView.SectonType {
        if section == 0 {
            return .team(matchList?.first)
        }
        return .odds
    }
    
    func numberOfSections() -> Int {
        return 2
    }
}



extension VMMatchDetail:MatchSegementScrollProtocol{
    func numberOfItems() -> Int {
        return segements.count
    }
    
    func titleOfItems(index: Int) -> String {
        return segements[index].title
    }
    
    func didSelectItems(view: MatchSegementScroll, index: Int) {
        let row = segements[index].index
        if row >= cells.count {
            return
        }
        
        var matchView: MatchDetailView?
        var next = view.next
        while next != nil {
            if let m = next as? MatchDetailView?{
                matchView = m
                break
            }
            next = next?.next
        }
        matchView?.scrollToItem(at: IndexPath(row:row, section:1), at: .centeredVertically, animated:true)
    }
}

extension VMMatchDetail{
    class ButtonData:SelectedOdds.Odd,MatchOddsButtonProtocol {
        weak var parent:VMMatchDetail?
        var isLeft:Bool?
        
        var isSelected:Bool{
            for item in  SelectedOdds.current.odd{
                if item.edoid == edoid{
                    return true
                }
            }
            return false
        }
        
        var matchOddsButtonContent: MatchOddsButton.Content?{
            return parent?.oddsContent(button:self)
        }
    }
}
