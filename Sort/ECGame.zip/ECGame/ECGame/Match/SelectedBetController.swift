//
//  BetListController.swift
//  ECGame
//
//  Created by Michale on 2019/10/29.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class SelectedBetController: BaseController {
    let header = BetListHeaderView()
    let tableView = BetListTableView()
    let bottomBar = BetListBottomBar()
    let vm = VMSelectedBet()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SelectedOdds.current.delegate = self
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .black
        
        view.addSubview(header)
        header.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(view.snp.topMargin).offset(15.scale)
        }
        
        let btn = UIButton()
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.backgroundColor = .clear
        btn.setImage(UIImage(named: "icon_match_close"), for: .normal)
        view.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.equalTo(header)
            make.trailing.equalToSuperview().offset(-20.scale)
        }
        
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(header.snp.bottom).offset(15.scale)
            make.left.right.equalToSuperview()
        }
        
        view.addSubview(bottomBar)
        bottomBar.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(tableView.snp.bottom)
            make.bottom.equalTo(view.snp.bottomMargin)
        }
        tableView.csDelegate = vm
        tableView.reloadData()
        updateUI()
    }
    
    @objc func btnClick()->Void{
        dismiss(animated: true, completion: nil)
    }
    
    private func updateUI()->Void{
        let isSingel = header.one.isSelected
        if isSingel {
            bottomBar.type = .singel(count: SelectedOdds.current.odd.count, money:vm.attr(isSingle:true, input:nil, totalOdds:0))
            vm.serialOdd = nil
            tableView.reloadData()
        }else{
            vm.serialOdd =  SelectedOdds.current.serialOdd
            
            let limit = vm.moneyLimit()
            bottomBar.type = .mutiple(count:vm.serialOdd?.count, min:limit.min, max:limit.max, attr: {[weak self] (input) -> NSAttributedString? in
                return self?.vm.attr(isSingle:false, input:input, totalOdds:limit.odds)
            })
            tableView.keyboardSection = nil
            tableView.reloadData()
        }
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? BetListHeaderView.Event {
        case .some(.multiple):
           updateUI()
        case .some(.singel):
            updateUI()
        default:
            break
        }
        
        switch event as? BetListTableCell.EventType{
        case .some(.remove):
            updateUI()
        case .some(.textFieldDidChange):
            if header.one.isSelected{
                bottomBar.type = .singel(count: SelectedOdds.current.odd.count, money:vm.attr(isSingle:true, input:nil, totalOdds:0))
            }
        default:
            break
        }
        
        switch event as? BetListBottomBar.Event{
        case .sure?:
            if header.one.isSelected{
                vm.singelPay(ctr:self, acceptOddsChange:bottomBar.third.selectedBtn.isSelected)
            }else{
                if let money = bottomBar.second.textField.text,let m = Decimal(string: money){
                    vm.multiplePay(ctr: self, acceptOddsChange:bottomBar.third.selectedBtn.isSelected, money:m)
                }
                
            }
        case .clearAll?:
            clearAll()
        default:
            break
        }
    }
    
    private func clearAll()->Void{
        let alert = DarkAlertController(title:"确认清空吗？", buttons:[.default(title: "取消", action:nil),.hilight(title: "清空", action: {[weak self] in
            SelectedOdds.current.odd.removeAll()
            SelectedOdds.current.play.removeAll()
            SelectedOdds.current.match.removeAll()
            self?.updateUI()
        })])
        present(alert, animated: true, completion: nil)
    }
}

extension SelectedBetController:SelectedOddsProtocol{
    func oddDidChanged() {
        updateUI()
    }
}
