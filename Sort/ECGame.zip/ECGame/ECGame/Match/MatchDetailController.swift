//
//  MatchDetailController.swift
//  EEGame
//
//  Created by Michale on 2019/10/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class MatchDetailController: BaseController {
    
    var vm:VMMatchDetail!
    let ctView = MatchDetailView()
    let bottomBar = MatchDetailBottomView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
   
    convenience init(mid:String) {
        self.init(nibName: nil, bundle: nil)
        vm = VMMatchDetail(mid: mid)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .navigatonBar
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.top.equalTo(view.snp.topMargin)
            make.left.right.equalToSuperview()
        }
        
        view.addSubview(bottomBar)
        bottomBar.snp.makeConstraints { (make) in
            make.top.equalTo(ctView.snp.bottom)
            make.left.right.equalToSuperview()
            make.bottom.equalTo(view.snp.bottomMargin)
        }
        ctView.csDelegate = vm
        vm.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        vm.getMatchDetail()
    }
    
    override func routerEvent(_ event: Any) {
        if case .exit? = event as? MatchDetailTeamHeader.Event{
            dismiss(animated: true, completion: nil)
        }
        
        if case .betClick? = event as? MatchDetailBottomView.Event{
            let bet = SelectedBetController()
            present(bet, animated: true, completion: nil)
        }
    }
}


extension MatchDetailController:VMMatchDetailProtocol{
    func updateBottom(count: Int) {
        bottomBar.updateBar(count: count)
    }
    
    func matchDidChanged() {
        ctView.reloadSections([0])
    }
    
    func oddsDidChanged() {
        ctView.reloadItems(at: ctView.indexPathsForVisibleItems)
    }
    
    func success() {
        ctView.reloadData()
    }
}
