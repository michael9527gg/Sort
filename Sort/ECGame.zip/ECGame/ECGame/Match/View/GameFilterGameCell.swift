//
//  GameFilterGameCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class GameFilterGameCell: GameFilterBaseCell {
    let image = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        image.backgroundColor = .clear
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            let width = 20.scale
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(12.scale)
            make.size.equalTo(CGSize(width: width, height: width))
        }
    
        title.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(image.snp.trailing).offset(8.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
