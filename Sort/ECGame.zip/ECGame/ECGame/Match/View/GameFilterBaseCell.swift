//
//  GameFilterBaseCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class GameFilterBaseCell: UICollectionViewCell {
    private let normalTextColor:UIColor = .marchName
    
    let title = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.backgroundColor = .clear
        backgroundColor = .line
        
        let selectView = UIView()
        selectView.layer.borderWidth = 1
        selectView.clipsToBounds = true
        selectView.layer.cornerRadius = 3.scale
        selectView.layer.borderColor = UIColor.tintColor.cgColor
        selectView.backgroundColor = UIColor(hexString: "#242d38")
        let image = UIImageView(image: UIImage(named: "game_picked"))
        selectView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.trailing.bottom.equalToSuperview()
        }
        
        selectedBackgroundView = selectView
        
        clipsToBounds = true
        layer.cornerRadius = 3.scale
        
        title.backgroundColor = .clear
        title.textColor = normalTextColor
        title.textAlignment = .center
        title.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        contentView.addSubview(title)
    }
    
    override var isSelected: Bool{
        set{
            title.textColor = newValue ? UIColor.white : normalTextColor
            super.isSelected = newValue
        }
        get{
            return super.isSelected
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
