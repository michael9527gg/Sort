//
//  GuessListView.swift
//  ECGame
//
//  Created by Michale on 2019/10/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

private let id = "id"

protocol MatchListViewProtocol:class {
    func numberOfItems(in section:Int) -> Int
    func configMatch(cell:MatchListCell,indexPath:IndexPath) -> Void
    func didSelectMatch(at indexPath:IndexPath) -> Void
}

class MatchListView: UICollectionView {
    weak var csDelegate:MatchListViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 10.scale
        flow.sectionInset = UIEdgeInsets(top:5.scale, left:homeLeading, bottom:5.scale, right:homeLeading)
        flow.itemSize = CGSize(width:kScreenWidth - 2 * homeLeading,height:MatchTeamView.height)
        super.init(frame: frame, collectionViewLayout:flow)
        register(MatchListCell.self, forCellWithReuseIdentifier: id)
        backgroundColor = .navigatonBar
        showsVerticalScrollIndicator = true
        delegate = self
        dataSource = self
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension MatchListView:UICollectionViewDataSource,UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: id, for: indexPath) as! MatchListCell
        csDelegate?.configMatch(cell: cell, indexPath: indexPath)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        csDelegate?.didSelectMatch(at: indexPath)
    }
    
}
