//
//  MatchListCollectionCell.swift
//  EEGame
//
//  Created by Michale on 2019/10/10.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


protocol MatchListCellProtocol:MatchTeamViewProtocol {
    var totalPlayCount:String?{
        get
    }
}


class MatchListCell: UICollectionViewCell {
    
    enum ButtonType:Int {
        case left = 4
        case right = 5
    }
    
    let team = MatchTeamView()
    let playCount  = UILabel()
    var btnAction:((_ type:ButtonType,_ isSelected:Bool)->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        team.leftOdds.tag = ButtonType.left.rawValue
        team.leftOdds.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
        
        team.rightOdds.tag = ButtonType.right.rawValue
        team.rightOdds.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
        contentView.addSubview(team)
        team.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
        }
        
        playCount.backgroundColor = .clear
        playCount.textColor = .tintColor
        //        playCount.text = "+21"
        playCount.textAlignment = .center
        playCount.font = UIFont(name: "PingFangSC-Medium", size: 12.scale)
        team.addSubview(playCount)
        playCount.snp.makeConstraints { (make) in
            make.centerY.equalTo(team.stateImage)
            make.trailing.equalToSuperview().offset(-10.scale)
        }
    }
    
    @objc func btnClick(sender:MatchOddsButton)->Void{
        sender.isSelected = !sender.isSelected
        btnAction?(ButtonType(rawValue: sender.tag)!,sender.isSelected)
    }
    
    
    func updateUI(with delegate:MatchListCellProtocol?) -> Void {
        team.updateUI(with: delegate)
        guard let d = delegate else {
            return
        }
        playCount.text = d.totalPlayCount
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
