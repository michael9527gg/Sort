//
//  BetListHeaderView.swift
//  ECGame
//
//  Created by Michale on 2019/12/2.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BetListHeaderView: UIView {
    
    enum Event {
        case singel
        case multiple
    }
    
    let one = BetListButton()
    let multiple = BetListButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        one.isSelected = true
        one.setTitle("单关", for: .normal)
        one.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
        addSubview(one)
        one.snp.makeConstraints { (make) in
            make.leading.top.equalToSuperview()
        }
        multiple.setTitle("串关", for: .normal)
        multiple.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
        addSubview(multiple)
        multiple.snp.makeConstraints { (make) in
            make.trailing.top.equalToSuperview()
            make.leading.equalTo(one.snp.trailing).offset(30.scale)
        }
    }
    
    @objc func btnClick(sender:BetListButton) ->Void{
        one.isSelected = false
        multiple.isSelected = false
        sender.isSelected = true
        
        var event:Event = .singel
        if sender === multiple {
            event = .multiple
        }
        routerEvent(event)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        invalidateIntrinsicContentSize()
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width:multiple.x+multiple.width, height:multiple.height)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension BetListHeaderView{
    class BetListButton: UIButton {
        override init(frame: CGRect) {
            super.init(frame: frame)
            titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 16.scale)
            setTitleColor(.white, for:.selected)
            setTitleColor(.marchName, for: .normal)
            clipsToBounds = true
            layer.cornerRadius = 4.scale
            setBackgroundImage(UIColor.selected.image, for:.selected)
            setBackgroundImage(UIColor.line.image, for: .normal)
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width:78.scale, height:38.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }

}
