//
//  BetKeyboardView.swift
//  ECGame
//
//  Created by Michale on 2019/12/3.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol BetKeyboardViewProtocol:class {
    func inset(number:Int) -> Void
    func backSpace() -> Void
    func sure() -> Void
}

class BetKeyboardView: UIView {
    weak var delegate:BetKeyboardViewProtocol?
    let maxMoney = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .line
        
        maxMoney.backgroundColor = .clear
        maxMoney.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        maxMoney.textColor = .white
//        maxMoney.text = "88,333"
        addSubview(maxMoney)
        maxMoney.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-10.scale)
        }
        
        let title = UILabel()
        title.backgroundColor = .clear
        title.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        title.textColor = .marchName
        title.text = "最大投注额"
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(6.scale)
            make.trailing.equalTo(maxMoney.snp.leading).offset(-8.scale)
            make.centerY.equalTo(maxMoney)
        }
        
        
        func horizontal(views:[UIView]) ->Void{
            let leading = 10.scale
            let space = 5.scale
            
            var prev:UIView?
            for btn in views{
                addSubview(btn)
                btn.snp.makeConstraints { (make) in
                    if prev == nil{
                        make.leading.equalToSuperview().offset(leading)
                    }else{
                        make.leading.equalTo(prev!.snp.trailing).offset(space)
                        make.width.top.equalTo(prev!)
                    }
                    make.height.equalTo(44.scale)
                }
                prev = btn
            }
            prev!.snp.makeConstraints { (make) in
                make.trailing.equalToSuperview().offset(-leading)
            }
        }
        
        var btns = [UIView]()
        for i in 0..<10{
            let btn = Button()
            btn.addTarget(self, action: #selector(numClick(sender:)), for: .touchUpInside)
            btn.tag = i
            btn.setTitle("\(i)", for: .normal)
            btns.append(btn)
        }
        
        let backSpace = Button()
        backSpace.addTarget(self, action: #selector(backSpaceAction), for: .touchUpInside)
        backSpace.setImage(UIImage(named: "icon_delete"), for: .normal)
        btns.append(backSpace)
        
        let sure = Button()
        sure.setBackgroundImage(UIColor.selected.image, for:.normal)
        sure.addTarget(self, action: #selector(sureAction), for: .touchUpInside)
        sure.setTitle("确认", for: .normal)
        sure.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 16.scale)
        sure.setTitleColor(.white, for: .normal)
        btns.append(sure)
        
        var start = 0
        while start < btns.count {
            let array:[UIView] = Array(btns[start ... start+3])
            horizontal(views: array)
            array.first?.snp.makeConstraints({ (make) in
                if start == 0{
                    make.top.equalToSuperview().offset(37.scale)
                }else{
                    make.top.equalTo(btns[start-1].snp.bottom).offset(5.scale)
                }
            })
            start += 4
        }
    }
    
    @objc func numClick(sender:Button) ->Void{
        delegate?.inset(number: sender.tag)
    }
    
    @objc func backSpaceAction() ->Void{
        delegate?.backSpace()
    }
    
    @objc func sureAction()->Void{
        delegate?.sure()
    }

    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height:190.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension BetKeyboardView{
    class Button: UIButton {
        override init(frame: CGRect) {
            super.init(frame: frame)
            setBackgroundImage(UIColor.navigatonBar.image, for: .normal)
            backgroundColor = .clear
            setTitleColor(.marchName, for: .normal)
            titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:22.scale)
            layer.cornerRadius = 4
            clipsToBounds = true
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
