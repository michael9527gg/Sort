//
//  BetListKeyBoard.swift
//  ECGame
//
//  Created by Michale on 2019/10/29.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class BetListKeyBoard: UITableViewCell {
    let keyboard = BetKeyboardView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = .line
        backgroundColor = .clear
        selectionStyle = .none
        
        contentView.addSubview(keyboard)
        keyboard.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.leading.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
