//
//  BetListTableView.swift
//  ECGame
//
//  Created by Michale on 2019/10/29.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


protocol BetListTableViewProtocol:class {
    func maxMoney(at row:Int) -> String
    func numberOfRows() -> Int
    func configCell(cell:BetListTableCell,row:Int) -> Void
    func deleteCell(_ row:Int) -> Void
}


class BetListTableView: UITableView {
    
    weak var csDelegate:BetListTableViewProtocol?
    var keyboardSection:Int?
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style:.grouped)

        sectionHeaderHeight = 6.scale
        sectionFooterHeight = 0.1
        estimatedSectionFooterHeight = 0.1
        estimatedSectionHeaderHeight = 4.scale
        backgroundColor = .clear//UIColor(hexString: "#28323c")
        separatorStyle = .none
        delegate = self
        dataSource = self
        
        let types:[CellType] = [.bet,.keyboard(max: nil)]
        for t in types {
            register(t.cellClass, forCellReuseIdentifier:t.reuserId)
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension BetListTableView:UITableViewDelegate{
}

extension BetListTableView:UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return csDelegate?.numberOfRows() ?? 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = UIView()
        header.backgroundColor = .black
        return header
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keyboardSection == section ? 2 : 1
    }
    
  
    private func cellType(indexPath:IndexPath) -> CellType {
        return (keyboardSection == indexPath.section && indexPath.row > 0) ? .keyboard(max:csDelegate?.maxMoney(at: indexPath.section)):.bet
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let type = cellType(indexPath: indexPath)
        let cell = tableView.dequeueReusableCell(withIdentifier: type.reuserId, for: indexPath)
        if let keyboard = cell as? BetListKeyBoard,case let .keyboard(max) = type{
            keyboard.keyboard.delegate = self
            keyboard.keyboard.maxMoney.text = max
        }else if let c = cell as? BetListTableCell{
            csDelegate?.configCell(cell: c, row:indexPath.section)
            c.action = ({[weak self] (type) in
                self?.cellEvent(indexPath:indexPath, type: type)
            })
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellType(indexPath: indexPath).cellHeight
    }
}

extension BetListTableView{
    
    private func cellEvent(indexPath:IndexPath,type:BetListTableCell.EventType){
        switch type {
        case .beginEdit:
            let index = IndexPath(row:1, section:indexPath.section)
            if keyboardSection != nil{//move
                let old = IndexPath(row:1, section:keyboardSection!)
                keyboardSection = indexPath.section
                moveRow(at:old , to:index)
                reloadRows(at: [index], with: .none)
            }else{//Insert
                keyboardSection = indexPath.section
                insertRows(at: [index], with: .none)
            }
            scrollToRow(at:index, at:.middle, animated: true)
        case .resign:
            if keyboardSection != nil{
                let pre = keyboardSection!
                keyboardSection = nil
                deleteRows(at: [IndexPath(row:1, section:pre)], with: .none)
            }
        case .remove:
            self.csDelegate?.deleteCell(indexPath.section)
            keyboardSection = nil
            reloadData()
            fallthrough
        default:
            next?.routerEvent(type)
        }
    }
}

extension BetListTableView{
    enum CellType {
        
        var reuserId:String{
            switch self {
            case .bet:
                return "bet"
            case .keyboard:
                return "keyboard"
            }
        }
        
        var canEdit:Bool{
            switch self {
            case .bet:
                return true
            case .keyboard:
                return false
            }
        }
        
        var cellHeight:CGFloat{
            switch self {
            case .bet:
                return 134.scale
            case .keyboard:
                return 185.scale
            }
        }
        
        var cellClass: UITableViewCell.Type{
            switch self {
            case .bet:
                return BetListTableCell.self
            case .keyboard:
                return BetListKeyBoard.self
            }
        }
        
        case bet
        case keyboard(max:String?)
    }
}

extension BetListTableView:BetKeyboardViewProtocol{

    func inset(number: Int) {
        if let s = keyboardSection,
           let cell = cellForRow(at: IndexPath(row:0, section:s)) as? BetListTableCell{
            cell.textField.insertText("\(number)")
        }
    }

    func backSpace() {
        if let s = keyboardSection,
            let cell = cellForRow(at: IndexPath(row:0, section:s)) as? BetListTableCell{
            cell.textField.deleteBackward()
        }
    }

    func sure() {
        if let s = keyboardSection,
            let cell = cellForRow(at: IndexPath(row:0, section:s)) as? BetListTableCell{
            cell.resignKeyBoard()
        }
    }
}
