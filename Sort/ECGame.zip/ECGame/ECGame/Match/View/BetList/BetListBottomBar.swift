//
//  BetListBottomBar.swift
//  ECGame
//
//  Created by Michale on 2019/10/31.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BetListBottomBar: UIView {
    
    enum Event {
        case sure
        case beginEditing
        case clearAll
    }
    
    enum `Type` {
        case singel(count:Int?,money:NSAttributedString?)
        case mutiple(count:Int?,min:Double?,max:Double?,attr:((_ input:Double)->NSAttributedString?)?)
    }
    
    private var maxMoney:Double?
    private var minMoney:Double?
    private var attr:((_ input:Double)->NSAttributedString?)?
    
    let first = First()
    let second = Second()
    let third = Third()
    
    var keyboard:BetKeyboardView?
    
    private var _type:`Type`?
    var type:`Type`?{
        get{
            return _type
        }
        set{
            _type = newValue
            invalidateIntrinsicContentSize()
            switch newValue {
            case let .some(.mutiple(count, min, max, attr)):
                first.count.text = "(\(count ?? 0))"
                maxMoney = max
                minMoney = min
                self.attr = attr
                first.type.text = (count ?? 0) > 0 ? "\(count!)串1" : nil
                textFiledDidChange(second.textField)
            case let .some(.singel(count, money)):
                first.type.text = nil
                first.count.text = "(\(count ?? 0))"
                first.money.attributedText = money
            default:
                break
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        
        addSubview(first)
        addSubview(second)
        addSubview(third)
        
        first.clearBtn.addTarget(self, action: #selector(clearAll), for: .touchUpInside)
        first.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
        }
        
        second.textField.delegate = self
        second.textField.addTarget(self, action:#selector(textFiledDidChange(_:)), for: .editingChanged)
        second.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(first.snp.bottom).offset(1)
        }
        
        
        third.sureBtn.addTarget(self, action: #selector(sureClick), for: .touchUpInside)
        third.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
    @objc func clearAll()->Void{
        let event:Event = .clearAll
        routerEvent(event)
    }
    
    @objc func sureClick()->Void{
        let event:Event = .sure
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var intrinsicContentSize: CGSize{
        switch type {
        case .some(.mutiple):
            if keyboard != nil{
                return CGSize(width: UIView.noIntrinsicMetric, height:2 * 50.scale + 1 + keyboard!.intrinsicContentSize.height)
            }
            return CGSize(width: UIView.noIntrinsicMetric, height:3 * 50.scale + 2)
        default:
            return CGSize(width: UIView.noIntrinsicMetric, height:2 * 50.scale + 1)
        }
    }
    

    @objc func textFiledDidChange(_ textFiled:UITextField)->Void{
        if let max = maxMoney{
            let input = textFiled.text ?? ""
            var n =  Double(input) ?? 0
            if n > max{
                n = max
                let s = String(format: "%.0f",n)
                second.textField.text = s
            }
            
            if let b = attr{
                first.money.attributedText = b(n)
            }
        }
    }
}

extension BetListBottomBar:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboard = BetKeyboardView()
        keyboard?.maxMoney.text = String(format: "%.0f",maxMoney ?? 0)
        keyboard?.delegate = self
        addSubview(keyboard!)
        keyboard?.snp.makeConstraints({ (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(second.snp.bottom)
        })
        invalidateIntrinsicContentSize()
        
        let event:Event = .beginEditing
        routerEvent(event)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        keyboard?.removeFromSuperview()
        keyboard = nil
        invalidateIntrinsicContentSize()
        
        if let text = textField.text,text.count>0,
            let n =  Double(text),n < (minMoney ?? 0){
            
            textField.text = String(format: "%.0f",minMoney ?? 0)
            textFiledDidChange(textField)
        }
    }
}

extension BetListBottomBar:BetKeyboardViewProtocol{
    func inset(number: Int) {
        second.textField.insertText("\(number)")
    }
    
    func backSpace() {
        second.textField.deleteBackward()
    }
    
    func sure() {
       second.textField.resignFirstResponder()
    }
    
}

extension BetListBottomBar{
    class First: UIView {
        class Lable: UILabel {
            override init(frame: CGRect) {
                super.init(frame: frame)
                backgroundColor = .clear
                font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
                textColor = UIColor.tintColor.withAlphaComponent(0.5)
                textAlignment = .center
                layer.cornerRadius = 4.scale
                layer.borderWidth = 1
                layer.borderColor = textColor.cgColor
            }
            
            override var intrinsicContentSize: CGSize{
                let s = super.intrinsicContentSize
                if s.width <= 0.01{
                    return s
                }
                return CGSize(width: s.width + 8.scale, height: s.height + 4.scale)
            }
            
            
            required init?(coder aDecoder: NSCoder) {
                fatalError("init(coder:) has not been implemented")
            }
        }
        
        let clearBtn = UIButton()
        let count = UILabel()
        let type = Lable()
        let money = UILabel()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .navigatonBar
            clearBtn.backgroundColor = .clear
            clearBtn.setTitle("清空全部", for: .normal)
            clearBtn.setTitleColor(.note, for: .normal)
            clearBtn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
            addSubview(clearBtn)
            clearBtn.snp.makeConstraints { (make) in
                make.leading.equalToSuperview().offset(15.scale)
                make.centerY.equalToSuperview()
            }
            
            count.backgroundColor = .clear
//            count.text = "(5)"
            count.textColor = .tintColor
            count.font = clearBtn.titleLabel?.font
            addSubview(count)
            count.snp.makeConstraints { (make) in
                make.leading.equalTo(clearBtn.snp.trailing)
                make.centerY.equalTo(clearBtn)
            }
            
//            type.text = "3串1"
            addSubview(type)
            type.snp.makeConstraints { (make) in
                make.leading.equalTo(count.snp.trailing).offset(10.scale)
                make.centerY.equalToSuperview()
            }
            
            money.backgroundColor = .clear
            money.numberOfLines = 0
            money.textAlignment = .right
            addSubview(money)
            money.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.trailing.equalToSuperview().offset(-15.scale)
            }
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height: 50.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    class Second: UIView {
        let textField = BetListTableCell.TextField()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .navigatonBar
            
            let title = UILabel()
            title.backgroundColor = .clear
            title.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
            title.textColor = .white
            title.text = "总投注额"
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.leading.equalToSuperview().offset(15.scale)
            }
            
            let left = UILabel(frame: CGRect(x: 0, y: 0, width:16.scale, height:20.scale))
            left.text = "¥"
            left.textAlignment = .center
            left.textColor = textField.textColor
            left.font = textField.font
            left.backgroundColor = .clear
            textField.leftViewMode = .always
            textField.leftView = left
            textField.set(placeHolder: "输入总投注额")
            textField.backgroundColor = .black
            textField.layer.borderColor = UIColor.line.cgColor
            textField.layer.borderWidth = 2
            textField.layer.cornerRadius = 4.scale
            textField.clipsToBounds = true
            addSubview(textField)
            textField.snp.makeConstraints { (make) in
                make.trailing.equalToSuperview().offset(-15.scale)
                make.centerY.equalToSuperview()
                make.top.equalToSuperview().offset(5.scale)
                make.leading.equalTo(title.snp.trailing).offset(15.scale)
            }
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height: 50.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    
    class Third: UIView {
        let selectedBtn = SelectedButton()
        let sureBtn = UIButton()
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .navigatonBar
            
            sureBtn.backgroundColor = .clear
            sureBtn.setBackgroundImage(UIImage(named: "bg_confirm"), for: .normal)
            sureBtn.setTitle("立即下注", for: .normal)
            sureBtn.setTitleColor(.white, for: .normal)
            sureBtn.titleLabel?.font = UIFont(name:"PingFangSC-Medium", size: 16.scale)
            addSubview(sureBtn)
            sureBtn.snp.makeConstraints { (make) in
                make.bottom.trailing.equalToSuperview()
                make.width.equalToSuperview().multipliedBy(0.5)
                make.height.equalTo(50.scale)
            }
            
            addSubview(selectedBtn)
            selectedBtn.snp.makeConstraints { (make) in
                make.leading.equalToSuperview().offset(5.scale)
                make.centerY.equalTo(sureBtn)
            }
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height: 50.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}

extension BetListBottomBar{
    class SelectedButton: UIButton {
        private let hSpace = 15.scale
        override init(frame: CGRect) {
            super.init(frame: frame)
            isSelected = true
            
            titleEdgeInsets = UIEdgeInsets(top: 0, left:hSpace, bottom: 0, right: 0)
            setTitle("接受赔率变化", for:.normal)
            addTarget(self, action: #selector(btnClick), for: .touchUpInside)
            titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            let ck = UIColor.marchName
            setTitleColor(ck, for: .normal)
            setTitleColor(ck, for: .selected)
            setImage(UIImage(named: "box_selected"), for: .selected)
            setImage(UIImage(named: "box_unselected"), for: .normal)
        }
        
        @objc func btnClick()->Void{
            isSelected = !isSelected
        }
        
        override var intrinsicContentSize: CGSize{
            let s = super.intrinsicContentSize
            return CGSize(width: s.width+hSpace+4, height: s.height)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
