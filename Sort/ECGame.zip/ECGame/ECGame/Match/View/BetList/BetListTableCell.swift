//
//  BetListTableCell.swift
//  ECGame
//
//  Created by Michale on 2019/10/29.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class BetListTableCell: UITableViewCell {
    
    enum EventType {
        case remove
        case beginEdit
        case resign
        case textFieldDidChange(text:String?)
    }
    
    var action:((_ type:EventType)->Void)?
    var bet:SelectedOdds.Odd?
    
    let team = UILabel()
    let playName = UILabel()
    let winMoney = UILabel()
    let odds = MatchOddsButton()
    var textField:TextField!
    let lock = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = .navigatonBar
        backgroundColor = .clear
        selectionStyle = .none
        
        team.backgroundColor = .clear
        team.textAlignment = .left
        team.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        contentView.addSubview(team)
        team.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(13.scale)
            make.leading.equalToSuperview().offset(16.scale)
        }
        
        let closeBtn = UIButton()
        closeBtn.addTarget(self, action: #selector(remove), for: .touchUpInside)
        closeBtn.backgroundColor = .clear
        closeBtn.setImage(UIImage(named: "icon_bet_close"), for: .normal)
        contentView.addSubview(closeBtn)
        closeBtn.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-16.scale)
            make.centerY.equalTo(team)
        }
        
        let line = UIView()
        line.backgroundColor = .line
        contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(team)
            make.trailing.equalTo(closeBtn)
            make.height.equalTo(1)
            make.top.equalTo(closeBtn.snp.bottom).offset(10.scale)
        }
        
        playName.backgroundColor = .clear
//        playName.text = "adf"
        contentView.addSubview(playName)
        playName.snp.makeConstraints { (make) in
            make.leading.equalTo(team)
            make.top.equalTo(line.snp.bottom).offset(10.scale)
        }
        
        winMoney.backgroundColor = .clear
//        winMoney.text = "fads"
        contentView.addSubview(winMoney)
        winMoney.snp.makeConstraints { (make) in
            make.trailing.equalTo(line)
            make.centerY.equalTo(playName)
        }
        
        contentView.addSubview(odds)
        odds.snp.makeConstraints { (make) in
            make.leading.equalTo(line)
            make.width.equalTo(line).multipliedBy(0.5)
            make.top.equalTo(playName.snp.bottom).offset(10.scale)
        }
        
        let ck = TextFieldView()
        textField = ck.textField
        textField.delegate = self
        textField.addTarget(self, action:#selector(textFiledDidChange(_:)), for: .editingChanged)
        contentView.addSubview(ck)
        ck.snp.makeConstraints { (make) in
            make.leading.equalTo(odds.snp.trailing)
            make.top.size.equalTo(odds)
        }
        
        lock.backgroundColor = .navigatonBar
        lock.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        lock.textAlignment = .center
        lock.isHidden = true
//        lock.text = "已锁住，无法下注"
        lock.textColor = .placeHolder
        contentView.addSubview(lock)
        lock.snp.makeConstraints { (make) in
            make.edges.equalTo(ck)
        }
        
    }
    
    @objc func remove() ->Void{
        let type:EventType = .remove
        if let a = action {
            a(type)
        }
    }
    
    func updateText() -> Void {
        bet?.input = textField.text ?? ""
        
        var n =  Double(textField.text ?? "") ?? 0
        let max = bet?.maxMoney ?? 0
        if n > max{
            n = max
            let s = String(format: "%.0f",max)
            textField.text = s
            bet?.input = s
        }
        let win = String(format: "%.2f",n * (bet?.odds ?? 0))
        let attr = NSMutableAttributedString(string:"可赢金额¥ \(win)", attributes: [NSAttributedString.Key.font :UIFont(name: "PingFangSC-Regular", size: 12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.marchName])
        attr.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.forgetPwd], range: NSRange(location: 0, length:4))
        winMoney.attributedText = attr
    }
    
    @objc func textFiledDidChange(_ textFiled:TextField)->Void{
        updateText()
        let type:EventType = .textFieldDidChange(text: textField.text)
        if let a = action {
            a(type)
        }
    }
    
    func resignKeyBoard() -> Void {
        textField.resignFirstResponder()
        let type:EventType = .resign
        if let a = action{
            a(type)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension BetListTableCell:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let type:EventType = .beginEdit
        if let a = action{
            a(type)
        }
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        if let text = textField.text,text.count>0,
            let n =  Double(text),let min = bet?.minMoney,n < min{

            textField.text = String(format: "%.0f",min)
            textFiledDidChange(self.textField)
        }
    }
}

extension BetListTableCell{
    class TextFieldView: UIView {
        let textField = TextField()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = UIColor(hexString: "#0F1419")
            
            textField.set(placeHolder:"请输入金额")
            addSubview(textField)
            textField.snp.makeConstraints { (make) in
                make.trailing.height.centerY.equalToSuperview()
                make.width.lessThanOrEqualToSuperview()
                make.width.greaterThanOrEqualToSuperview().multipliedBy(0.5)
            }
        }
        
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            super.touchesBegan(touches, with: event)
            textField.becomeFirstResponder()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}

extension BetListTableCell{
    class TextField:UITextField{
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            textColor = .tintColor
            UITextField.appearance().tintColor = textColor
            inputView = UIView(frame: .zero)
            font = UIFont(name: "PingFangSC-Medium", size: 14.scale)
        }
        
        func set(placeHolder:String) -> Void {
            attributedPlaceholder = NSAttributedString(string:placeHolder,attributes:[NSAttributedString.Key.foregroundColor:textColor!.withAlphaComponent(0.5),NSAttributedString.Key.font:font!])
        }

        override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
            return false
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}

