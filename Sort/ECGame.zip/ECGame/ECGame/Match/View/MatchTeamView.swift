//
//  MatchTeamView.swift
//  ECGame
//
//  Created by Michale on 2019/11/28.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol MatchTeamViewProtocol {
    
    var cellAlpha:CGFloat{
        get
    }
    
    var stateImage:String?{
        get
    }
    
    var matchTitle:String?{
        get
    }
    
    var leftMatch:MatchTeamView.Match?{
        get
    }
    
    var rightMatch:MatchTeamView.Match?{
        get
    }
    
    var centerAttr:NSAttributedString?{
        get
    }
}

class MatchTeamView: UIView {
    
    let stateImage   = UIImageView()
    let matchName    = UILabel()
    
    let leftState = UIImageView()
    let leftImage = UIImageView()
    let leftName  = UILabel()
    let leftOdds = MatchOddsButton()
    
    let rightState = UIImageView()
    let rightImage = UIImageView()
    let rightName  = UILabel()
    let rightOdds = MatchOddsButton()
    
    let time = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        layer.cornerRadius = 6.scale
        clipsToBounds = true
        layer.borderColor = UIColor.line.cgColor
        layer.borderWidth = 1
        
        stateImage.backgroundColor = .clear
        addSubview(stateImage)
        stateImage.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview()
        }
        
        matchName.backgroundColor = .clear
        matchName.textColor = .marchName
        matchName.textAlignment = .center
        matchName.font = UIFont(name: "PingFangSC-Medium", size: 12.scale)
        addSubview(matchName)
        matchName.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(4.scale)
            make.centerX.equalToSuperview()
        }
        
        leftImage.backgroundColor = .clear
        let leading = 35.scale
        addSubview(leftImage)
        leftImage.snp.makeConstraints { (make) in
            let w = 68.scale
            make.size.equalTo(CGSize(width: w, height: w))
            make.top.equalTo(matchName.snp.bottom).offset(10.scale)
            make.leading.equalToSuperview().offset(leading)
        }
        
        leftState.backgroundColor = .clear
        //        leftState.image = UIImage(named: "win")
        addSubview(leftState)
        leftState.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.bottom.equalTo(leftImage)
        }
        
        leftName.backgroundColor = .clear
        leftName.textColor = .marchName
        leftName.font = UIFont(name: "PingFangSC-Regular", size: 10.scale)
        leftName.textAlignment = .center
        //        leftName.text = "EG"
        addSubview(leftName)
        leftName.snp.makeConstraints { (make) in
            make.top.equalTo(leftImage.snp.bottom)
            make.centerX.equalTo(leftImage)
        }
        

        addSubview(leftOdds)
        leftOdds.snp.makeConstraints { (make) in
            make.top.equalTo(leftName.snp.bottom).offset(10.scale)
            make.centerX.equalTo(leftName)
            make.width.equalTo(114.scale)
        }
        
        rightImage.backgroundColor = .clear
        //        rightImage.image = UIImage(named: "aaafda")
        addSubview(rightImage)
        rightImage.snp.makeConstraints { (make) in
            make.size.centerY.equalTo(leftImage)
            make.trailing.equalToSuperview().offset(-leading)
        }
        
        rightState.backgroundColor = .clear
        //        rightState.image = UIImage(named: "lose")
        addSubview(rightState)
        rightState.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview()
            make.bottom.equalTo(rightImage)
        }
        
        rightName.backgroundColor = .clear
        rightName.textColor = .marchName
        rightName.font = UIFont(name: "PingFangSC-Regular", size: 10.scale)
        rightName.textAlignment = .center
        //        rightName.text = "EG"
        addSubview(rightName)
        rightName.snp.makeConstraints { (make) in
            make.centerY.equalTo(leftName)
            make.centerX.equalTo(rightImage)
        }
        

        addSubview(rightOdds)
        rightOdds.snp.makeConstraints { (make) in
            make.centerY.size.equalTo(leftOdds)
            make.centerX.equalTo(rightName)
        }
        
        //        time.setText(line1: "2019-10-09", line2: "15:00")
        time.numberOfLines = 0
        addSubview(time)
        time.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
    }
    
    func updateUI(with delegate:MatchTeamViewProtocol?) -> Void {
        guard let d = delegate else {
            return
        }
        
        matchName.text = d.matchTitle
        stateImage.image = UIImage(named: d.stateImage ?? "")
        time.attributedText = d.centerAttr
        
        let placeholder = UIImage(named: "img_nologo")
        leftImage.setImage(url:d.leftMatch?.url ?? "",placeholder:placeholder)
        leftName.text = d.leftMatch?.name
        leftOdds.content = d.leftMatch?.content
        if let img = d.leftMatch?.stateImage{
            leftState.image = UIImage(named: img)
        }else{
            leftState.image = nil
        }
        
        rightImage.setImage(url:d.rightMatch?.url ?? "",placeholder: placeholder)
        rightName.text = d.rightMatch?.name
        rightOdds.content = d.rightMatch?.content
        if let img = d.rightMatch?.stateImage{
            rightState.image = UIImage(named: img)
        }else{
            rightState.image = nil
        }
        
        alpha = d.cellAlpha
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width:kScreenWidth - 2 * 15.scale, height:type(of: self).height)
    }
    
    class var height: CGFloat{
        return 175.scale
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension MatchTeamView{
    class OddsLable: UIView {
        let image = UIImageView()
        let title = UILabel()
        
        enum `Type` {
            case `default`(String?)
            case up(String?)
            case down(String?)
            case lock
            case error(String?)
            case result(Bool)
        }
        
        private var _type:`Type`?
        var type:`Type`?{
            get{
                return _type
            }
            set{
                _type = newValue
                switch newValue {
                case let .up(text)?:
                    image.image = UIImage(named: "icon_up")
                    title.text = text
                    title.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
                    title.textColor = .up
                case let .down(text)?:
                    image.image = UIImage(named: "icon_down")
                    title.text = text
                    title.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
                    title.textColor = .down
                case let .default(text)?:
                    title.font = UIFont(name: "PingFangSC-Semibold", size:14.scale)
                    title.textColor = .white
                    title.text = text
                    image.image = nil
                case .lock?:
                    title.text = nil
                    image.image = UIImage(named: "icon_lock")
                case let .error(str)?:
                    title.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
                    title.textColor = .forgetPwd
                    title.text = str//
                    image.image = nil
                case let .result(success)?:
                    title.text = nil
                    image.image = UIImage(named: success ? "icon_odds_win" : "icon_odds_lose")
                default:
                    image.image = nil
                    title.text = nil
                }
                setNeedsLayout()
                layoutIfNeeded()
            }
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            image.backgroundColor = .clear
            addSubview(image)
            image.snp.makeConstraints { (make) in
                make.leading.centerY.equalToSuperview()
            }
            
            title.backgroundColor = .clear
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.leading.equalTo(image.snp.trailing).offset(4.scale)
            }
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            
            switch type {
            case .default?,.error?,nil:
                title.x = 0
            case .result?:
                image.x = 0
            default:
                break
            }
            
            invalidateIntrinsicContentSize()
        }
        
        override var intrinsicContentSize: CGSize{
            switch type {
            case .up?,.down?:
                return CGSize(width:title.x+title.width, height:title.height)
            case .lock?,.result?:
                return image.intrinsicContentSize
            default:
                return title.intrinsicContentSize
            }
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}


extension MatchTeamView{
    class Match{
        var url:String?
        var name:String?
        var content:MatchOddsButton.Content?
        var stateImage:String?
    }
}
