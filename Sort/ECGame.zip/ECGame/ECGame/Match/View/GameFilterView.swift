//
//  GameFilterView.swift
//  ECGame
//
//  Created by Michale on 2019/10/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol GameFilterViewProtocol:class {
    func numberOfItem(in section: Int) -> Int
    func cellType(at indexPath:IndexPath) -> GameFilterView.CellType
    func didSelectItem(at indexPath:IndexPath,_ view:GameFilterView) -> Void
    func didDeselectItem(at indexPath:IndexPath,_ view:GameFilterView) -> Void
}

private let id = "id"

class GameFilterView: UICollectionView  {
    
    weak var csDelegate:GameFilterViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        let inset = 16.scale
        let width = (kScreenWidth - 3*inset)/2 - 1
        flow.itemSize = CGSize(width: width, height:38.scale)
        flow.minimumInteritemSpacing = inset
        flow.minimumLineSpacing = inset
        flow.footerReferenceSize = CGSize(width:kScreenWidth - 2*inset, height:150.scale)
        flow.sectionInset = UIEdgeInsets(top: inset, left: inset, bottom:35.scale, right: inset)
        super.init(frame: frame, collectionViewLayout: flow)
        allowsMultipleSelection = true
        delegate = self
        dataSource = self
        
        let cells:[CellType] = [.all(nil),.game(title: nil, url: nil)]
        for c in cells {
            register(c.cellClass, forCellWithReuseIdentifier: c.reuseId)
        }
        register(GameFilterFooterView.self, forSupplementaryViewOfKind:UICollectionView.elementKindSectionFooter, withReuseIdentifier:id)
        backgroundColor = .navigatonBar
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension GameFilterView:UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        csDelegate?.didSelectItem(at: indexPath, self)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        csDelegate?.didDeselectItem(at: indexPath, self)
    }
}

extension GameFilterView:UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItem(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = csDelegate?.cellType(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:type!.reuseId, for: indexPath)
        
        switch type {
        case let .all(title)?:
            if let c = cell as? GameFilterAllCell{
                c.title.text = title
            }
        case let .game(title, url)?:
            if let c = cell as? GameFilterGameCell{
                c.title.text = title
                c.image.setImage(url: url)
            }
        default:
            break
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let footer = collectionView.dequeueReusableSupplementaryView(ofKind:kind, withReuseIdentifier: id, for: indexPath)
        return footer
    }
}

extension GameFilterView{
    enum CellType {
        
        var cellClass:UICollectionViewCell.Type{
            switch self {
            case .all:
                return GameFilterAllCell.self
            case .game:
                return GameFilterGameCell.self
            }
        }
        
        var reuseId:String{
            switch self {
            case .all:
                return "all"
            case .game:
                return "game"
            }
        }
        
        case all(_ title:String?)
        case game(title:String?,url:String?)
    }
}

