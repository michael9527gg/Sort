//
//  GameFilterFooterView.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class GameFilterFooterView: UICollectionReusableView {
    
    enum Event {
        case sure
        case clear
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        let sure = UIButton()
        sure.backgroundColor = .clear
        sure.setBackgroundImage(UIImage(named: "bg_confirm"), for: .normal)
        sure.setTitle("确定", for: .normal)
        sure.addTarget(self, action: #selector(sureClick), for: .touchUpInside)
        sure.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        sure.setTitleColor(.white, for: .normal)
        addSubview(sure)
        sure.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalToSuperview().offset(16.scale)
            make.top.equalToSuperview()
        }
        
        let clear = UIButton()
        clear.backgroundColor = .clear
        clear.addTarget(self, action: #selector(clearClick), for: .touchUpInside)
        clear.setTitle("清除筛选条件", for: .normal)
        clear.titleLabel?.font = UIFont(name: " PingFangSC-Regular", size:14.scale)
        clear.setTitleColor(UIColor(hexString: "#FFB627"), for: .normal)
        addSubview(clear)
        clear.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(sure.snp.bottom).offset(15.scale)
        }
    }
    
    @objc func sureClick()->Void{
        let event:Event = .sure
        routerEvent(event)
    }
    
    @objc func clearClick()->Void{
        let event:Event = .clear
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
