//
//  MatchListNotifiyView.swift
//  ECGame
//
//  Created by Michale on 2019/11/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MatchListNotifiyView: UIView {
    let title = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        backgroundColor = .line
        clipsToBounds = true
        layer.cornerRadius = 14.scale
        
        let img = UIImageView()
        img.image = UIImage(named: "match_notice")
        img.backgroundColor = .clear
        addSubview(img)
        img.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(6.scale)
            make.centerY.equalToSuperview()
        }
        
        title.text = "亚洲电竞不会通过客服提供任何方式（银行卡信息请注意保密）"
        title.backgroundColor = .clear
        title.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        title.textColor = .marchName
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.leading.equalTo(img.snp.trailing).offset(8.scale)
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-21.scale)
        }
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width: kScreenWidth - 2 * 15.scale, height: 28.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
