//
//  MatchDetailCollectionView.swift
//  ECGame
//
//  Created by Michale on 2019/11/1.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


protocol MatchDetailViewProtocol:MatchSegementScrollProtocol {
    func numberOfSections() -> Int
    func sectionType(at section:Int) -> MatchDetailView.SectonType
    func numberOfCell() -> Int
    func cellForItem(at row:Int) -> MatchDetailView.CellType
    func didSelectButton(at row:Int,isSelected:Bool) -> Void
}


class MatchDetailView: UICollectionView {
    
    weak var csDelegate:MatchDetailViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let layout = MatchDetailFlowLayout()
        super.init(frame: frame, collectionViewLayout: layout)
        backgroundColor = .navigatonBar
        allowsMultipleSelection = true
        let cells:[CellType] = [.button(nil),.title(nil)]
        for item in cells{
            register(item.cellClass, forCellWithReuseIdentifier:item.reuseId)
        }
        let sections:[SectonType] = [.team(nil),.odds]
        for item in sections {
            register(item.classType, forSupplementaryViewOfKind:UICollectionView.elementKindSectionHeader, withReuseIdentifier:item.reuseId)
        }
        delegate = self
        dataSource = self
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension MatchDetailView:UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if let section =  csDelegate?.sectionType(at: indexPath.section){
            switch section{
            case .odds:
                return csDelegate?.cellForItem(at:indexPath.row).sizeForItem ?? .zero
            default:
                break
            }
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return csDelegate?.sectionType(at: section).sizeForHeader ?? .zero
    }
    
}



extension MatchDetailView:UICollectionViewDataSource,UICollectionViewDelegate{

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return csDelegate?.numberOfSections() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let section =  csDelegate?.sectionType(at: section){
            switch section{
            case .odds:
                return csDelegate?.numberOfCell() ?? 0
            default:
                break
            }
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var type:CellType!
        if let s = csDelegate?.sectionType(at:indexPath.section),
            case .odds = s{
            type = csDelegate?.cellForItem(at: indexPath.row)
        }
        
        let cell =
            collectionView.dequeueReusableCell(withReuseIdentifier:type.reuseId,for: indexPath)
        
        if case let .button(content)? = type,
            let c = cell as? MatchDetailButtonCell{
            c.button.content = content?.matchOddsButtonContent
            c.btnAction = {[weak self] (sender) in
                self?.csDelegate?.didSelectButton(at: indexPath.row,isSelected: sender.isSelected)
            }
        }else if case let .title(attr)? = type,
            let c = cell as? MatchDetailTitleCell{
            c.title.attributedText = attr
        }
    
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let s =  csDelegate?.sectionType(at: indexPath.section)
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier:s!.reuseId, for: indexPath)
        switch s {
        case let .team(delegate)?:
            (header as! MatchDetailTeamHeader).updateUI(with: delegate)
        case .odds?:
            let h = header as! MatchDetailSegementHeader
            h.updateUI(with:csDelegate)
            h.scroll.selectedIndex = 0
        default:
            break
        }
        return header
    }
}
        
    
extension MatchDetailView{
    
    enum SectonType {
        case team(MatchTeamViewProtocol?)
        case odds
        
        var classType:UICollectionReusableView.Type{
            switch self {
            case .team:
                return MatchDetailTeamHeader.self
            case .odds:
                return MatchDetailSegementHeader.self
            }
        }
        
        var sizeForHeader:CGSize{
            switch self {
            case .team:
                return CGSize(width:kScreenWidth, height:MatchTeamView.height)
            case .odds:
                return CGSize(width:kScreenWidth, height:45.scale)
            }
        }
        
        var reuseId: String{
            switch self {
            case .team:
                return "team"
            case .odds:
                return "odds"
            }
        }
    }
    
    enum CellType {
        
        var cellClass: UICollectionViewCell.Type{
            switch self {
            case .button:
                return MatchDetailButtonCell.self
            case .title:
                return MatchDetailTitleCell.self
            }
        }
        
        var reuseId: String{
            switch self {
            case .button:
                return "button"
            case .title:
                return "title"
            }
        }
        
        var sizeForItem: CGSize{
            switch self {
            case .button:
                return CGSize(width:kScreenWidth/2 - 1,height: 50.scale)
            case .title:
                return CGSize(width:kScreenWidth,height: 35.scale)
            }
        }
        
        case button(MatchOddsButtonProtocol?)
        case title(NSAttributedString?)
    }
}
