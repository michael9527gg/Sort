//
//  MatchDetailButtonCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/1.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MatchDetailButtonCell: UICollectionViewCell {
    
    let button = MatchOddsButton()
    var btnAction:((_ sender:MatchOddsButton)->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        let leading = 15.scale
        contentView.addSubview(button)
        button.addTarget(self, action:#selector(btnClick(sender:)), for: .touchUpInside)
        button.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(leading)
            make.center.equalToSuperview()
        }
    }
    
    @objc func btnClick(sender:MatchOddsButton) ->Void{
        sender.isSelected = !sender.isSelected
        sender.content?.isSelected = sender.isSelected
        btnAction?(sender)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
