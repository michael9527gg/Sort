//
//  MatchTeamDetailHeader.swift
//  ECGame
//
//  Created by Michale on 2019/11/29.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MatchDetailTeamHeader: UICollectionReusableView {
    enum Event {
        case exit
    }
    
    let team = MatchTeamView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        
        addSubview(team)
        team.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
        }
        
        let btn = UIButton()
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.backgroundColor = .clear
        btn.setImage(UIImage(named: "icon_match_close"), for: .normal)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.equalTo(team).offset(5.scale)
            make.trailing.equalTo(team).offset(-5.scale)
        }
    }
    
    func updateUI(with delegate:MatchTeamViewProtocol?) -> Void {
        team.updateUI(with: delegate)
    }
    
    @objc func btnClick() ->Void{
        let event:Event = .exit
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
