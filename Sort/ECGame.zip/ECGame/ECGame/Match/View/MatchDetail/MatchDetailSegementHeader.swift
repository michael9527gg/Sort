//
//  MatchDetailHeaderReuse.swift
//  ECGame
//
//  Created by Michale on 2019/11/1.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MatchDetailSegementHeader: UICollectionReusableView {
    let scroll = MatchSegementScroll()
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        backgroundColor = .navigatonBar
        
        addSubview(scroll)
        scroll.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func updateUI(with delegate:MatchSegementScrollProtocol?) -> Void {
        scroll.csDelegate = delegate
        scroll.reload()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

