//
//  MatchDetailTitleCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/1.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MatchDetailTitleCell: UICollectionViewCell {
    
    let title = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear
   
        title.backgroundColor = .clear
        title.textAlignment = .left
//      title.text = "全场-获胜者"
        title.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
