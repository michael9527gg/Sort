//
//  MatchOddsButton.swift
//  ECGame
//
//  Created by Michale on 2019/12/1.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol MatchOddsButtonProtocol {
    var matchOddsButtonContent:MatchOddsButton.Content?{
        get
    }
}

class MatchOddsButton: UIButton {
    
    private let leading = 10.scale
    class Content {
        enum `Type` {
            case left
            case right
            case center
        }
        var isEnable:Bool = true
        var isSelected:Bool = false
        var type:`Type` = .left
        var name:String?
        var odds:MatchTeamView.OddsLable.`Type`?
    }
    
    let odds = MatchTeamView.OddsLable()
    
    private var _content:Content?
    var content:Content?{
        set{
            _content = newValue
            odds.type = newValue?.odds
            
            switch newValue?.type {
            case .some(.left):
                titleLabel?.textAlignment = .left
            case .some(.right):
                titleLabel?.textAlignment = .right
            default:
                break
            }
            
            if let c = newValue {
                setTitle(c.name, for: .normal)
                isSelected = c.isSelected
                isEnabled = c.isEnable
            }else{
                titleLabel?.text = nil
                odds.type = nil
                layer.borderColor = backgroundColor?.cgColor
            }
            setNeedsLayout()
            layoutIfNeeded()
        }
        get{
            return _content
        }
    }
    
    override var isSelected: Bool{
        set{
            super.isSelected = newValue
            if newValue{
                titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 12.scale)
                layer.borderColor = UIColor.tintColor.withAlphaComponent(0.4).cgColor
            }else{
                titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:10.scale)
                layer.borderColor = backgroundColor?.cgColor
            }
        }
        get{
            return super.isSelected
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.line.withAlphaComponent(0.5)
        setTitleColor(.white, for: .selected)
        let ck:UIColor = .marchName
        setTitleColor(ck, for: .normal)
        setTitleColor(ck, for: .disabled)
        titleLabel?.numberOfLines = 0
        
        clipsToBounds = true
        layer.cornerRadius = 2
        layer.borderWidth = 1
        
        odds.isUserInteractionEnabled = false
        addSubview(odds)
        odds.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview().offset(-leading)
            make.centerY.equalToSuperview()
        }
        
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let hspace = 5.scale
        if let c = content{
            
            switch c.type{
            case .left:
                titleLabel?.frame = CGRect(x:leading, y:0, width:width-2*leading-odds.width-hspace, height:height)
                odds.x = width - leading - odds.width
            case .right:
                odds.x = leading
                let x = odds.x+odds.width + hspace
                titleLabel?.frame = CGRect(x:x, y:0, width:width-x - leading, height: height)
            case .center:
                titleLabel?.frame = .zero
                odds.center = CGPoint(x: width/2, y: height/2)
            }
        }
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height:40.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
