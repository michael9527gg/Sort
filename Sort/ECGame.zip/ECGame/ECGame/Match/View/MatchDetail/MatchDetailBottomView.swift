//
//  MatchDetailBottomView.swift
//  ECGame
//
//  Created by Michale on 2019/11/29.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class MatchDetailBottomView: UIView {
    
    enum Event {
        case betClick
    }
    
    func updateBar(count:Int) -> Void {
        let attr = NSMutableAttributedString(string:"已选注单 (\(count))", attributes: [NSAttributedString.Key.foregroundColor :UIColor.tintColor,NSAttributedString.Key.font:lable.font!])
        attr.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white], range:NSRange(location:0, length: 4))
        lable.attributedText = attr
    }
    
    let lable = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .line
        
        let img = UIImageView()
        img.backgroundColor = .clear
        img.image = UIImage(named: "icon_bet")
        addSubview(img)
        img.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(19.scale)
        }
        
        lable.backgroundColor = .clear
        lable.textAlignment = .left
        lable.font = UIFont(name: "PingFangSC-Medium", size: 16.scale)
        addSubview(lable)
        lable.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(img.snp.trailing).offset(8.scale)
        }
        
        let btn = UIButton()
        btn.backgroundColor = .clear
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        btn.setBackgroundImage(UIImage(named: "bg_confirm"), for: .normal)
        btn.setTitle("立即下注", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont(name:"PingFangSC-Medium", size: 16.scale)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.bottom.trailing.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
        }
        
        updateBar(count: 0)
    }
    
    @objc func btnClick() ->Void{
        let event:Event = .betClick
        routerEvent(event)
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height:50.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
