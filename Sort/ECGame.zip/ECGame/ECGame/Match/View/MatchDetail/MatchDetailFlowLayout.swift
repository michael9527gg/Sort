//
//  MatchDetailFlowLayout.swift
//  ECGame
//
//  Created by Michale on 2019/11/3.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class MatchDetailFlowLayout: UICollectionViewFlowLayout {
    override init() {
        super.init()
        scrollDirection = .vertical
        sectionHeadersPinToVisibleBounds = true
        minimumLineSpacing = 0
        minimumInteritemSpacing = 0
        sectionInset = .zero
    }
    
//    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
//        let array = super.layoutAttributesForElements(in: rect)
//        if array?.count == 0{
//            return array
//        }
//        
//        for a in array!{
//            if a.size.width * 2 == kScreenWidth,
//                abs(a.center.x - kScreenWidth/2) < 5{
//                a.frame = CGRect(origin: CGPoint(x: 0, y: a.frame.origin.y), size: a.size)
//            }
//        }
//        
//        return array
//    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
