//
//  MatchSegementScroll.swift
//  ECGame
//
//  Created by Michale on 2019/10/25.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol MatchSegementScrollProtocol:class {
    func numberOfItems() -> Int
    func titleOfItems(index:Int) -> String
    func didSelectItems(view:MatchSegementScroll,index:Int) -> Void
}

class MatchSegementScroll: UIScrollView {
    
    weak var csDelegate:MatchSegementScrollProtocol?
    let segement = MatchSortSegement()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        showsHorizontalScrollIndicator = false
        backgroundColor = .clear
        bounces = false
//        isPagingEnabled = true
        segement.addTarget(self, action: #selector(valueChange), for: .valueChanged)
        addSubview(segement)
        segement.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
            make.width.equalTo(1)
            make.height.equalToSuperview()
        }
    }
    
    var selectedIndex:Int{
        get{
            return segement.selectedSegmentIndex
        }
        set{
            segement.selectedSegmentIndex = newValue
        }
    }
    
    func reload() -> Void {
        segement.removeAllSegments()
        guard let total = csDelegate?.numberOfItems(),total>0 else {
            return
        }
        
        for i  in (0 ..< total).reversed(){
            if let title = csDelegate?.titleOfItems(index: i){
                segement.insertSegment(withTitle: title, at: 0, animated: false)
            }
        }
        
        segement.snp.updateConstraints { (make) in
            make.width.equalTo(kScreenWidth/5 * CGFloat(total))
        }
        setNeedsLayout()
        layoutIfNeeded()
    }
    
    @objc func valueChange() ->Void{
        csDelegate?.didSelectItems(view:self, index: segement.selectedSegmentIndex)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
