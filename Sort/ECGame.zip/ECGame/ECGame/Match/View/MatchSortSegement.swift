//
//  MatchSortSegement.swift
//  ECGame
//
//  Created by Michale on 2019/10/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class MatchSortSegement: UISegmentedControl {
    
    private let botomLine = UIImageView(image:UIImage(named: "segement_bottom"))
    
    override init(items: [Any]?) {
        super.init(items: items)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        tintColor = .clear
        setTitleTextAttributes([NSAttributedString.Key.foregroundColor :UIColor.white,NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size: 14.scale)!], for: .normal)
        setTitleTextAttributes([NSAttributedString.Key.foregroundColor :UIColor.white,NSAttributedString.Key.font:UIFont(name: "PingFangSC-Semibold", size:21.scale)!], for: .selected)
        
        addSubview(botomLine)
        
        addObserver(self, forKeyPath: "selectedSegmentIndex", options: NSKeyValueObservingOptions.new, context: nil)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "selectedSegmentIndex" {
            updateLine()
        }
    }
    
    deinit {
        removeObserver(self, forKeyPath: "selectedSegmentIndex")
    }
    
    
    func updateLine() -> Void {
        var width:CGFloat = 0
        if selectedSegmentIndex != UISegmentedControl.noSegment {
            width = 25.scale
        }
        let x = (CGFloat(selectedSegmentIndex*2+1))/(CGFloat)(numberOfSegments*2)
        let centerX =  x * self.frame.size.width
        botomLine.frame = CGRect(x:centerX-width/2, y:self.frame.size.height-6, width:width, height:4)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        bringSubviewToFront(botomLine)
        updateLine()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
