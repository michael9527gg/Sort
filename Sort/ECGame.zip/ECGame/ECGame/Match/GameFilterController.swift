//
//  GameFilterController.swift
//  ECGame
//
//  Created by Michale on 2019/10/22.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class GameFilterController: BaseController {
    
    let vm = VMGameFilter()
    let ctView = GameFilterView()
    var selectedEgame:[MBaseEgame]?
    var finishSelect:((_ egame:[MBaseEgame]?)->Void)?
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .navigatonBar
        let leading = 16.scale
        let title = UILabel()
        title.backgroundColor = .clear
        title.font = UIFont(name: "PingFangSC-Semibold", size:21.scale)
        title.textColor = .white
        title.text = "选择游戏平台"
        view.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(leading)
            make.top.equalToSuperview().offset(40.scale)
        }
        
        let close = UIButton()
        close.addTarget(self, action: #selector(cancel), for: .touchUpInside)
        close.setImage(UIImage(named: "game_filter_close"), for: .normal)
        view.addSubview(close)
        close.snp.makeConstraints { (make) in
            make.centerY.equalTo(title)
            make.trailing.equalToSuperview().offset(-leading)
        }
        
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.leading.trailing.bottomMargin.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(10.scale)
        }
        ctView.csDelegate = vm
        
        vm.getBaseEgameList(success:{[weak self] in
            self?.ctView.reloadData()
            guard let array = self?.vm.selected(egames: self?.selectedEgame) else{
                if (self?.vm.numberOfItem(in: 0) ?? 0) > 1{
                    self?.ctView.selectItem(at: IndexPath(row: 0, section: 0), animated: true, scrollPosition:.init(rawValue: 0))
                }
                return
            }
            for item in array{
                self?.ctView.selectItem(at: item,animated:true,
                                        scrollPosition:.init(rawValue: 0))
            }
        })
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? GameFilterFooterView.Event {
        case .sure?:
            sureClick()
        case .clear?:
            clearAllSelect()
        default:
            break
        }
    }
    
    func sureClick() -> Void {
        if ctView.indexPathsForSelectedItems == nil || ctView.indexPathsForSelectedItems!.count == 0{
            finishSelect?(nil)
            cancel()
            return
        }
        
        var array = [MBaseEgame]()
        for item in ctView.indexPathsForSelectedItems! {
            let index = item.row - 1
            if index < 0{
                finishSelect?(nil)
                cancel()
                return
            }
            array.append(vm.gameList![index])
        }
        
        finishSelect?(array)
        cancel()
    }
    
    func clearAllSelect() -> Void {
        if let items = ctView.indexPathsForSelectedItems{
            for item in items{
                ctView.deselectItem(at: item, animated: false)
            }
        }
        
        if ctView.numberOfItems(inSection:0) > 1 {
            ctView.selectItem(at:IndexPath(row:0, section: 0), animated:true, scrollPosition:.init(rawValue: 0))
        }
    }
    
    @objc func cancel() -> Void {
        dismiss(animated: true, completion: nil)
    }
}
