//
//  NewListVideoCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol NewListVideoCellProtocol {
    var videoData:(title:String?,image:String?,subTitle:String?)?{
        get
    }
}

class NewListVideoCell: UICollectionViewCell {
    let title = UILabel()
    let subTitle = UILabel()
    let image = UIImageView()
    let time = UILabel()
    let teamLogo = UIImageView()
    let teamName = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        title.backgroundColor = .clear
        title.textColor = .white
//        title.text = "Fnatic官宣：功勋教头YoungBu"
        title.textAlignment = .left
        title.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
        }
        
        
        subTitle.backgroundColor = .clear
        subTitle.textColor = .marchName
//        subTitle.text = "2019年《英雄联盟全球总》"
        subTitle.textAlignment = .left
        subTitle.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        contentView.addSubview(subTitle)
        subTitle.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(10.scale)
        }
        
      
        image.layer.cornerRadius = 6.scale
        image.clipsToBounds = true
        image.backgroundColor = .clear
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(title)
            make.top.equalTo(subTitle.snp.bottom).offset(10.scale)
            make.height.equalTo(194.scale)
        }
        
        let play = UIImageView()
        play.image = UIImage(named: "icon_video_play")
        play.backgroundColor = .clear
        contentView.addSubview(play)
        play.snp.makeConstraints { (make) in
            make.center.equalTo(image)
        }
       
    
        time.backgroundColor = .clear
        time.textColor = .marchName
        time.text = "10086次播放     2017年11月11日"
        time.textAlignment = .right
        time.font = UIFont(name: "PingFangSC-Regular", size: 13.scale)
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.trailing.equalTo(title)
            make.top.equalTo(image.snp.bottom).offset(13.scale)
        }
        
        
        
        teamLogo.backgroundColor = .clear
        contentView.addSubview(teamLogo)
        teamLogo.snp.makeConstraints { (make) in
            make.centerY.equalTo(time)
            make.leading.equalTo(title)
            let w = 18.scale
            make.size.equalTo(CGSize(width:w, height:w))
        }
        
       
        teamName.backgroundColor = .clear
        teamName.textColor = .marchName
        teamName.text = "DOTA 2"
        teamName.textAlignment = .left
        teamName.font = UIFont(name: "PingFangSC-Medium", size: 14.scale)
        contentView.addSubview(teamName)
        teamName.snp.makeConstraints { (make) in
            make.centerY.equalTo(teamLogo)
            make.leading.equalTo(teamLogo.snp.trailing).offset(5.scale)
        }
    }
    
    func updateUI(delegate:NewListVideoCellProtocol?) -> Void {
        guard let data = delegate?.videoData else {
            return
        }
        
        image.setImage(url: data.image)
        title.text = data.title
        subTitle.text = data.subTitle
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
