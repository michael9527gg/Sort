//
//  NewsSearchSegement.swift
//  ECGame
//
//  Created by Michale on 2019/11/28.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class NewsSearchSegement: UIView {
    
    weak var delegate:NewListSegementProtocol?
    var selectedSegmentIndex:Int?
    var inset:CGFloat?
    private var totalCount:Int?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        reload()
    }
    
    func reload() -> Void {
        for item in subviews {
            item.removeFromSuperview()
        }
        totalCount = delegate?.countOfSegement ?? 0
        var pre:UIView?
        for i in 0 ..< totalCount! {
            let btn = Button()
            btn.tag = i
            btn.isSelected = i == 0
            btn.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
            if let title = delegate?.segement(index: i).title{
                btn.setNormal(title: title)
                btn.setSelected(title: title)
            }
            addSubview(btn)
            btn.snp.makeConstraints { (make) in
                make.height.top.equalToSuperview()
                make.width.equalToSuperview().multipliedBy(1.0 / Double(totalCount!)).offset(1 - (inset ?? 0))
                if pre == nil{
                    make.leading.equalToSuperview()
                }else{
                    make.leading.equalTo(pre!.snp.trailing).offset(self.inset ?? 0)
                }
                pre = btn
            }
        }
        
        selectedSegmentIndex = 0
        invalidateIntrinsicContentSize()
    }
    
    func valueChange() -> Void {
        if let index = selectedSegmentIndex {
            for item in subviews {
                if let btn = item as? UIButton,btn.tag == index{
                    btnClick(sender: btn)
                    break
                }
            }
        }
    }
    
    @objc func btnClick(sender:UIButton) ->Void{
        for item in subviews {
            if let btn = item as? UIButton{
                btn.isSelected = false
            }
        }
        sender.isSelected = true
        selectedSegmentIndex = sender.tag
        
        if let s = delegate?.segement(index: selectedSegmentIndex!){
            s.didSelect?()
        }
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width:40.scale * (CGFloat(totalCount ?? 0)), height:40.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension NewsSearchSegement{
    class Button: UIButton {
        let image = UIImageView(image: UIImage(named: "game_picked"))
        
        func setNormal(title:String) -> Void {
            let attr = NSMutableAttributedString(string:title, attributes: [NSAttributedString.Key.font :UIFont(name: "PingFangSC-Regular", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.marchName])
            setAttributedTitle(attr, for: .normal)
        }
        
        func setSelected(title:String) -> Void {
            let attr = NSMutableAttributedString(string:title, attributes: [NSAttributedString.Key.font :UIFont(name: "PingFangSC-Medium", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.white])
            setAttributedTitle(attr, for: .selected)
        }
        
        override var isSelected: Bool{
            get{
                return super.isSelected
            }
            set{
                super.isSelected = newValue
                if newValue {
                    image.isHidden = false
                    backgroundColor = .navigatonBar
                    layer.borderColor = UIColor.tintColor.cgColor
                }else{
                     image.isHidden = true
                    layer.borderColor = UIColor.clear.cgColor
                    backgroundColor = .line
                }
            }
        }
        
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            clipsToBounds = true
            layer.cornerRadius = 4.scale
            layer.borderWidth = 1
            
            addSubview(image)
            image.snp.makeConstraints { (make) in
                make.trailing.bottom.equalToSuperview()
            }
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
