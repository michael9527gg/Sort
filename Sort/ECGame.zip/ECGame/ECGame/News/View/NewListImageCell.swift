//
//  NewListImageCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol NewListImageCellProtocol {
    var imageData:(image:String?,title:String?,number:String?)?{
        get
    }
}

class NewListImageCell: UICollectionViewCell {
    let image = UIImageView()
    let title = UILabel()
    let number = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
       
        image.contentMode = .scaleAspectFit
        image.clipsToBounds = true
        image.layer.cornerRadius = 6.scale
        image.backgroundColor = .clear
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.centerX.top.equalToSuperview()
            make.leading.equalToSuperview().offset(8.scale)
            make.height.equalTo(220.scale)
        }
        
        let topLeft = UIImageView(image: UIImage(named: "icon_news_image"))
        topLeft.backgroundColor = .clear
        image.addSubview(topLeft)
        topLeft.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview()
        }

        number.backgroundColor = .clear
//        number.text = "8P"
        number.textColor = .white
        number.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        image.addSubview(number)
        number.snp.makeConstraints { (make) in
            make.centerY.equalTo(topLeft)
            make.trailing.equalToSuperview().offset(-10.scale)
        }
       
        title.backgroundColor = .clear
        title.textColor = .white
//        title.text = "韩国女主播进驻过捏国内直播平台"
        title.textAlignment = .left
        title.numberOfLines = 2
        title.font = UIFont(name: "PingFangSC-Semibold", size: 14.scale)
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.left.right.equalTo(image)
            make.top.equalTo(image.snp.bottom).offset(10.scale)
        }
    }
    
    func updateUI(delegate:NewListImageCellProtocol?) -> Void {
        guard let data = delegate?.imageData else {
            return
        }
        
        image.setImage(url: data.image,placeholder: UIImage(named: "image_news_placeholder"))
        title.text = data.title
        number.text = data.number
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
