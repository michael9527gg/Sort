//
//  NewListNewsCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol NewListNewsCellProtocol {
    var newsData:(image:String?,title:String?,
        des:String?,time:String?,
        teamLogo:String?,teamName:String?)?{
        get
    }
}

class NewListNewsCell: UICollectionViewCell {
    let image = UIImageView()
    let title = UILabel()
    let des = UILabel()
    let time = UILabel()
    let teamLogo = UIImageView()
    let teamName = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        
        image.clipsToBounds = true
        image.layer.cornerRadius = 6.scale
        image.backgroundColor = .clear
//        image.image = UIImage(named: "image_news_placeholder")
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.leading.top.equalToSuperview()
            make.size.equalTo(CGSize(width:160.scale, height:100.scale))
        }
        
        let topLeft = UIImageView(image: UIImage(named: "icon_news_note"))
        topLeft.backgroundColor = .clear
        image.addSubview(topLeft)
        topLeft.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview()
        }
        
       
        title.backgroundColor = .clear
        title.textColor = .white
//        title.text = "WESG2019-2020北区巡回解说以及酸菜公布"
        title.textAlignment = .left
        title.numberOfLines = 2
        title.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.trailing.equalToSuperview()
            make.leading.equalTo(image.snp.trailing).offset(10.scale)
            make.top.equalTo(image)
        }
       
        des.backgroundColor = .clear
        des.textColor = .marchName
//        des.text = "WESG2019-2020北区巡回解说以及酸菜公布"
        des.textAlignment = .left
        des.numberOfLines = 2
        des.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        contentView.addSubview(des)
        des.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(title)
            make.bottom.equalTo(image)
        }
        
        time.backgroundColor = .clear
        time.textColor = .marchName
//        time.text = "10086次播放     2017年11月11日"
        time.textAlignment = .right
        time.font = UIFont(name: "PingFangSC-Regular", size: 13.scale)
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.trailing.equalTo(title)
            make.top.equalTo(image.snp.bottom).offset(8.scale)
        }
        
    
        teamLogo.backgroundColor = .clear
        contentView.addSubview(teamLogo)
        teamLogo.snp.makeConstraints { (make) in
            make.centerY.equalTo(time)
            make.leading.equalTo(image)
            let w = 18.scale
            make.size.equalTo(CGSize(width:w, height:w))
        }
        
       
        teamName.backgroundColor = .clear
        teamName.textColor = .marchName
//        teamName.text = "DOTA 2"
        teamName.textAlignment = .left
        teamName.font = UIFont(name: "PingFangSC-Medium", size: 14.scale)
        contentView.addSubview(teamName)
        teamName.snp.makeConstraints { (make) in
            make.centerY.equalTo(teamLogo)
            make.leading.equalTo(teamLogo.snp.trailing).offset(5.scale)
        }
    }
    
    func updateUI(delegate:NewListNewsCellProtocol?) -> Void {
        guard let data = delegate?.newsData else {
            return
        }
        
        image.setImage(url: data.image,placeholder: UIImage(named: "image_news_placeholder"))
        title.text = data.title
        des.text = data.des
        time.text = data.time
        teamLogo.setImage(url: data.teamLogo)
        teamName.text = data.teamName
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
