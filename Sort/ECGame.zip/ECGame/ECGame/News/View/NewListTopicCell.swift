//
//  NewListTopicCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

protocol NewListTopicCellProtocol {
    var topicData:(image:String?,title:String?,
        time:String?,teamLogo:String?,teamName:String?)?{
        get
    }
}

class NewListTopicCell: UICollectionViewCell {
    let image = UIImageView()
    let title = UILabel()
    let time = UILabel()
    let teamLogo = UIImageView()
    let teamName = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
       
        image.clipsToBounds = true
        image.layer.cornerRadius = 6.scale
        image.backgroundColor = .clear
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(140.scale)
        }
        
        let topLeft = UIImageView(image: UIImage(named: "icon_news_topic"))
        topLeft.backgroundColor = .clear
        image.addSubview(topLeft)
        topLeft.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview()
        }
        
       
        title.backgroundColor = .clear
        title.textColor = .white
//        title.text = "WESG2019-2020北区巡回解说以及酸菜公布"
        title.textAlignment = .left
        title.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.left.right.equalTo(image)
            make.top.equalTo(image.snp.bottom).offset(10.scale)
        }
        
        
        
        time.backgroundColor = .clear
        time.textColor = .marchName
//        time.text = "10086次播放     2017年11月11日"
        time.textAlignment = .right
        time.font = UIFont(name: "PingFangSC-Regular", size: 13.scale)
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.trailing.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(8.scale)
        }
        
        
       
        teamLogo.backgroundColor = .clear
        contentView.addSubview(teamLogo)
        teamLogo.snp.makeConstraints { (make) in
            make.centerY.equalTo(time)
            make.leading.equalTo(title)
            let w = 18.scale
            make.size.equalTo(CGSize(width:w, height:w))
        }
        
       
        teamName.backgroundColor = .clear
        teamName.textColor = .marchName
//        teamName.text = "DOTA 2"
        teamName.textAlignment = .left
        teamName.font = UIFont(name: "PingFangSC-Medium", size: 14.scale)
        contentView.addSubview(teamName)
        teamName.snp.makeConstraints { (make) in
            make.centerY.equalTo(teamLogo)
            make.leading.equalTo(teamLogo.snp.trailing).offset(5.scale)
        }
        
    }
    
    func updateUI(delegate:NewListTopicCellProtocol?) -> Void {
        guard let data = delegate?.topicData else{
            return
        }
        image.setImage(url: data.image)
        title.text = data.title
        time.text = data.time
        teamName.text = data.teamName
        teamLogo.setImage(url: data.teamLogo)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
