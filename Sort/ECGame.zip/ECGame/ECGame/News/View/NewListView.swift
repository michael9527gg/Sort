//
//  NewListView.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol NewListViewProtocol:class {
    func numberOfItems(in section:Int) -> Int
    func cellForItem(at indexPath:IndexPath) -> NewListView.CellType
}


class NewListView: UICollectionView {
    
    weak var csDelegate:NewListViewProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 10.scale
        flow.sectionInset = UIEdgeInsets(top:homeLeading, left:homeLeading, bottom:homeLeading, right:homeLeading)
        super.init(frame: frame, collectionViewLayout: flow)
        let cells:[CellType] = [.video(nil),.image(nil),.topic(nil),.news(nil)]
        for c in cells {
            register(c.cellClass, forCellWithReuseIdentifier: c.reuseId)
        }
        delegate = self
        dataSource = self
        backgroundColor = .navigatonBar
        showsVerticalScrollIndicator = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension NewListView:UICollectionViewDelegate{
}

extension NewListView:UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return csDelegate!.cellForItem(at: indexPath).sizeForItem
    }
}

extension NewListView:UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems(in: section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = csDelegate!.cellForItem(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: type.reuseId, for: indexPath)
        
        switch type {
        case let .news(d):
            (cell as! NewListNewsCell).updateUI(delegate:d)
        case let .image(d):
            (cell as! NewListImageCell).updateUI(delegate:d)
        case let .video(d):
            (cell as! NewListVideoCell).updateUI(delegate:d)
        case let .topic(d):
            (cell as! NewListTopicCell).updateUI(delegate:d)
        }
        
        return cell
    }
}

extension NewListView{
    enum CellType {
        
        var cellClass:UICollectionViewCell.Type{
            switch self {
            case .video:
                return NewListVideoCell.self
            case .image:
                return NewListImageCell.self
            case .topic:
                return NewListTopicCell.self
            case .news:
                return NewListNewsCell.self
            }
        }
        
        var sizeForItem:CGSize{
            let w = kScreenWidth - 2 * homeLeading
            switch self {
            case .video:
                return CGSize(width:w, height:300.scale)
            case .image:
                return CGSize(width:w/2,height:280.scale)
            case .topic:
                return CGSize(width:w, height:205.scale)
            case .news:
                return CGSize(width:w, height:130.scale)
            }
        }
        
        var reuseId:String{
            switch self {
            case .video:
                return "video"
            case .image:
                return "image"
            case .topic:
                return "topic"
            case .news:
                return "news"
            }
        }
        
        case video(NewListVideoCellProtocol?)
        case image(NewListImageCellProtocol?)
        case topic(NewListTopicCellProtocol?)
        case news(NewListNewsCellProtocol?)
    }
}
