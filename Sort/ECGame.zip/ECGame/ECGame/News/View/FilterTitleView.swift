//
//  FilterTitleView.swift
//  ECGame
//
//  Created by Michale on 2019/11/27.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class FilterTitleView: UIView {
    let title = UILabel()
    
    func set(title:String,content:String) -> Void {
        let attr = NSMutableAttributedString(string:title+content, attributes: [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size:12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.white])
        attr.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.note], range: NSRange(location: 0, length: title.count))
        self.title.attributedText = attr
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .notify
//        clipsToBounds = false
//        let img = UIImageView()
//        img.backgroundColor = .clear
//        img.image = UIImage(named: "bg_tips")
//        img.layer.zPosition  = 1000
//        addSubview(img)
//        img.snp.makeConstraints { (make) in
//            make.bottom.equalTo(self.snp.top)
//            make.centerX.equalToSuperview()
//        }
        
        title.backgroundColor = .clear
        addSubview(title)
        title.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(15.scale)
            make.trailing.equalToSuperview().offset(-40.scale)
            make.centerY.equalToSuperview()
        }
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height:28.scale)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
