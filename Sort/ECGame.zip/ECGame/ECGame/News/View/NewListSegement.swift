//
//  NewListSegement.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

protocol NewListSegementProtocol:class {
    var countOfSegement:Int{
        get
    }
    func segement(index:Int) -> NewListSegement.Index
}

class NewListSegement: MatchSortSegement {
    
    struct Index {
        var title:String
        var didSelect:(()->Void)?
    }
    
    weak var delegate:NewListSegementProtocol?
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        addTarget(self, action: #selector(valueChanged), for: .valueChanged)
    }
    
    @objc func valueChanged() -> Void {
        if let s = delegate?.segement(index: selectedSegmentIndex){
            s.didSelect?()
        }
    }
    
    func reload() -> Void {
        removeAllSegments()
        for i in (0 ..< (delegate?.countOfSegement ?? 0)).reversed() {
            insertSegment(withTitle: delegate?.segement(index: i).title ?? "", at:0, animated: false)
        }
        selectedSegmentIndex = 0
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
