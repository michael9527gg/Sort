//
//  NewsListViewController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class NewsListViewController: BaseController {
    let filterTitle = FilterTitleView()
    let segement = NewListSegement(frame: CGRect(x: 0, y: 0, width:200.scale, height:50.scale))
    let vm = VMNewsList()
    let ctView = NewListView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
    }
    
    func setupNavigation() -> Void {
        updateFilterTitle(nil)
        segement.delegate = vm
        segement.reload()
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: segement)
        
        let filterBtn = UIButton()
        filterBtn.addTarget(self, action: #selector(filterAction(sender:)), for: .touchUpInside)
        filterBtn.backgroundColor = .clear
        filterBtn.setTitle("筛选", for: .normal)
        filterBtn.setTitleColor(.tintColor, for:.normal)
        filterBtn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        
        let search = UIButton()
        search.addTarget(self, action: #selector(searchAction(sender:)), for: .touchUpInside)
        search.backgroundColor = .clear
        search.setImage(UIImage(named: "icon_search"), for: .normal)
        
        navigationItem.rightBarButtonItems =
            [UIBarButtonItem(customView:search),
             UIBarButtonItem(customView:filterBtn)]
    }
    
    func updateFilterTitle(_ sorts:[MNewsSort]?) -> Void {
        vm.sorts = sorts
        var content = "全部"
        if (sorts?.count ?? 0) > 0 {
            content = ""
            for item in sorts!{
                if let s = item.name{
                    content.append(s + ",")
                }
            }
            content.removeLast()
        }
        filterTitle.set(title: "正在查看 ",content: content)
    }
    
    @objc func filterAction(sender:UIButton)->Void{
        let filter = NewsFilterController()
        filter.selectedSort = vm.sorts
        filter.finishSelect = {[weak self] (sorts) in
            self?.updateFilterTitle(sorts)
        }
        present(filter, animated: true, completion:nil)
    }
   
    @objc func searchAction(sender:UIButton)->Void{
        let result = NewsSearchViewController()
        result.vm.currentItid = vm.currentItid
        let searchController = UISearchController(searchResultsController: result)
        searchController.searchResultsUpdater = result
        searchController.hidesNavigationBarDuringPresentation = true
        let searchBar = searchController.searchBar
        searchBar.isTranslucent = false
        let app = UIBarButtonItem.appearance(whenContainedInInstancesOf:[UISearchBar.self])
        app.title = "取消"
        searchBar.tintColor = .marchName
        if let textFiled = searchBar.value(forKey:"searchField") as? UITextField{
            textFiled.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
            textFiled.textColor = .white
        }
        searchBar.barTintColor = .navigatonBar
        searchBar.searchTextPositionAdjustment = UIOffset(horizontal:8.scale, vertical:0)
        searchBar.setSearchFieldBackgroundImage(UIImage(named: "bg_search"), for:.normal)
        searchBar.setImage(UIImage(named: "icon_search"), for:.search, state:.normal)
        searchBar.placeholder = "输入关键字进行搜索"
        definesPresentationContext = true
        present(searchController, animated: true, completion:nil)
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .clear
        view.addSubview(filterTitle)
        filterTitle.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(view.snp.topMargin)
        }
        
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.top.equalTo(filterTitle.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
        ctView.csDelegate = vm
        vm.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        segement.valueChanged()
    }
}


extension NewsListViewController:VMNewsListProtocol{
    func success() {
        ctView.reloadData()
    }
}
