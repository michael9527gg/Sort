//
//  VMNewsList.swift
//  ECGame
//
//  Created by Michale on 2019/11/26.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMNewsListProtocol:class {
    func success() -> Void
}

extension MNewsContent:NewListNewsCellProtocol{
    var newsData: (image: String?, title: String?, des: String?, time: String?, teamLogo: String?, teamName: String?)? {
        return (image:imgPath, title:title, des:content, time:"", teamLogo:"", teamName:"")
    }
}

extension MNewsContent:NewListImageCellProtocol{
    var imageData: (image: String?, title: String?, number: String?)? {
        return (image:imgPath, title:title,number:"\(imageUrls?.count ?? 0)P")
    }
}

extension MNewsContent:NewListTopicCellProtocol{
    var topicData: (image: String?, title: String?, time: String?, teamLogo: String?, teamName: String?)? {
        return (image:imgPath, title:title, time:nil, teamLogo:nil, teamName:nil)
    }
}

extension MNewsContent:NewListVideoCellProtocol{
    var videoData: (title: String?, image: String?, subTitle: String?)? {
        return (title:title, image:imgPath,subTitle:content)
    }
}

class VMNewsList: VMBase {
    weak var delegate:VMNewsListProtocol?
    
    var sorts:[MNewsSort]?
    var keyword:String?
    var currentItid:ItidType?
    
    let itidTypes:[ItidType] = [.news,.image,.video,.topic]
    var content:[MNewsContent]?
}

extension VMNewsList:NewListViewProtocol{
    func numberOfItems(in section: Int) -> Int {
        return content?.count ?? 0
    }
    
    func cellForItem(at indexPath: IndexPath) -> NewListView.CellType {
        switch currentItid! {
        case .image:
            return .image(content![indexPath.row])
        case .video:
            return .video(content![indexPath.row])
        case .news:
            return .news(content![indexPath.row])
        case .topic:
            return .topic(content![indexPath.row])
        }
    }
}

extension VMNewsList:NewListSegementProtocol{
    var countOfSegement: Int {
        return itidTypes.count
    }
    
    func segement(index: Int) -> NewListSegement.Index {
        return NewListSegement.Index(title:itidTypes[index].title, didSelect: {[weak self] in
            
            guard let itid = self?.itidTypes[index].rawValue else{
                return
            }
            
            var nsid = [String]()
            if let items = self?.sorts{
                for item in items{
                    if let id = item.nSid{
                        nsid.append(id)
                    }
                }
            }
            
            News.provider.request(.contentList(itid:itid,sid:"",nsid:nsid,
                                               keyword:self?.keyword ?? "",
                                               pageIndex:0,pageSize:0))
            {(_ result:ECResult<[MNewsContent]>) in
                if case let .success(list) = result{
                    self?.content = list
                    self?.currentItid = self?.itidTypes[index]
                    self?.delegate?.success()
                }
            }
        })
    }
}



extension VMNewsList{
    enum ItidType:String {
        case video = "328f1bac-bfdf-42b5-a637-012707a8a6b8"
        case image = "aed6eda2-c663-4d91-886c-01574e9034aa"
        case topic = "1a96dbfb-c18c-426c-a7da-00152574b0e0"
        case news  = "7b261dc2-1cdd-49f0-b477-00280c873a1c"
        
        var title:String{
            switch self {
            case .video:
                return "视频"
            case .news:
                return "新闻"
            case .topic:
                return "专题"
            case .image:
                return "图集"
            }
        }
    }
}
