//
//  NewsController.swift
//  ECGame
//
//  Created by Michale on 2020/1/3.
//  Copyright © 2020 EC. All rights reserved.
//

import UIKit
import WebKit

class NewsController: WebViewController {
    init() {
        super.init(urlStr: "http://10.10.11.54:8080/#/news")
        webView.navigationDelegate = self
        title = "咨讯"
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension NewsController:WKNavigationDelegate{
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        let js = "(document.getElementsByClassName(\"main\")[0]).style.bottom = 0"
        webView.evaluateJavaScript(js, completionHandler: nil)
    }
}
