//
//  NewsSearchViewController.swift
//  ECGame
//
//  Created by Michale on 2019/11/28.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class NewsSearchViewController: BaseController {
    let vm = VMNewsList()
    let ctView = NewListView()
    let segement = NewsSearchSegement()
    
    override func loadView() {
        super.loadView()
        
        segement.inset = 10.scale
        view.addSubview(segement)
        segement.backgroundColor = .clear
        segement.delegate = vm
        segement.reload()
        segement.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(16.scale)
            make.centerX.equalToSuperview()
            make.top.equalTo(view.snp.topMargin).offset(50)
        }
        
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.top.equalTo(segement.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
        ctView.csDelegate = vm
        vm.delegate = self
        view.backgroundColor = .navigatonBar
    }
}

extension NewsSearchViewController:UISearchResultsUpdating{
    func updateSearchResults(for searchController: UISearchController) {
        vm.keyword = searchController.searchBar.text
        segement.valueChange()
    }
}

extension NewsSearchViewController:VMNewsListProtocol{
    func success() {
        ctView.reloadData()
    }
}
