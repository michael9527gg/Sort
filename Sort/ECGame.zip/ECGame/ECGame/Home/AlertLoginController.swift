//
//  AlertLoginController.swift
//  ECGame
//
//  Created by Michale on 2019/11/20.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class AlertLoginController: BaseController {
    
    private var loginAction:(()->Void)?
    private var registerAction:(()->Void)?
    private var scanAction:(()->Void)?
   
    convenience init(login:(()->Void)?,register:(()->Void)?,scan:(()->Void)?) {
        self.init(nibName:nil,bundle:nil)
        loginAction = login
        registerAction = register
        scanAction = scan
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle:nibBundleOrNil)
        modalPresentationStyle = .custom
        modalTransitionStyle = .crossDissolve
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .init(red: 0, green: 0, blue: 0, alpha: 0.5)
        
        let ctView = UIView()
        ctView.layer.cornerRadius = 4
        ctView.clipsToBounds = true
        ctView.backgroundColor = .white
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.leading.equalToSuperview().offset(30.scale)
            make.height.equalTo(272.scale)
        }
        
        let title = UILabel()
        title.font = UIFont(name: "PingFangSC-Medium", size:18.scale)
        title.textColor = .black
        title.textAlignment = .center
        title.text = "加入开心电竞"
        title.backgroundColor = .clear
        ctView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(25.scale)
        }
        
        let des = UILabel()
        des.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        des.textColor = .note
        des.textAlignment = .center
        des.text = "享受更多服务，请先注册账号"
        des.backgroundColor = .clear
        ctView.addSubview(des)
        des.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(title.snp.bottom).offset(12.scale)
        }
        
        let register = UIButton()
        register.addTarget(self, action: #selector(registerBtn), for: .touchUpInside)
        register.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        register.setTitle("立即注册", for: .normal)
        register.setTitleColor(.white, for: .normal)
        register.setBackgroundImage(UIImage(named: "bg_signin2"), for: .normal)
        ctView.addSubview(register)
        register.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.leading.equalToSuperview().offset(16.scale)
            make.top.equalTo(des.snp.bottom).offset(14.scale)
            make.height.equalTo(50.scale)
        }
        
        let scan = UIButton()
        scan.titleEdgeInsets = UIEdgeInsets(top: 0, left:10, bottom: 0, right:0)
        scan.imageEdgeInsets = UIEdgeInsets(top: 0, left:0, bottom: 0, right: 10)
        scan.clipsToBounds = true
        scan.layer.cornerRadius = 3
        scan.layer.borderWidth = 1
        scan.layer.borderColor = UIColor.borderColor.cgColor
        scan.addTarget(self, action: #selector(scanClick), for: .touchUpInside)
        scan.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:16.scale)
        scan.setTitle("扫描好友推荐二维码注册", for: .normal)
        scan.setImage(UIImage(named: "icon_scan"), for: .normal)
        scan.setTitleColor(.note, for: .normal)
        ctView.addSubview(scan)
        scan.snp.makeConstraints { (make) in
            make.size.centerX.equalTo(register)
            make.top.equalTo(register.snp.bottom).offset(16.scale)
        }
        
        let login = UIButton()
        login.addTarget(self, action: #selector(loginBtn), for: .touchUpInside)
        login.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        login.setTitle("已有账号？点此登陆", for: .normal)
        login.setTitleColor(.loginBtn, for: .normal)
        ctView.addSubview(login)
        login.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(scan.snp.bottom).offset(16.scale)
        }
        
        let close = UIButton()
        close.addTarget(self, action: #selector(closeBtn), for: .touchUpInside)
        close.setBackgroundImage(UIImage(named: "icon_close"), for: .normal)
        view.addSubview(close)
        close.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(ctView.snp.bottom).offset(30.scale)
        }
    }
    
    @objc func scanClick()->Void{
        dismiss(animated: true, completion: {
            self.scanAction?()
        })
    }
    
    @objc func loginBtn() ->Void{
        dismiss(animated: true, completion: {
            self.loginAction?()
        })
    }
    
    @objc func registerBtn() ->Void{
        dismiss(animated: true, completion: {
            self.registerAction?()
        })
    }
    
    @objc func closeBtn() ->Void{
        dismiss(animated: true, completion: nil)
    }
}
