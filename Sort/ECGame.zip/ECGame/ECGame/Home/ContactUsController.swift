//
//  ContactUsController.swift
//  ECGame
//
//  Created by Michale on 2019/12/27.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class ContactUsController: BaseController {
    let vm = VMContactUs()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "联系客服"
        setBackButton()
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .navigatonBar
        
        let bk = UIImageView()
        bk.backgroundColor = .clear
        let img:UIImage! = UIImage(named: "customer_service_bg")
        bk.image = img
        view.addSubview(bk)
        bk.snp.makeConstraints { (make) in
            make.leading.equalToSuperview().offset(15.scale)
            make.centerX.equalToSuperview()
            make.top.equalTo(view.snp.topMargin)
            make.height.equalTo(bk.snp.width).multipliedBy(img.size.height/img.size.width)
        }
        
        let title = UILabel()
        title.backgroundColor = .clear
        title.text = "免费在线客服"
        title.font = UIFont(name: "PingFangSC-Medium", size:24.scale)
        title.textColor = .white
        title.textAlignment = .center
        view.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(bk).offset(30.scale)
        }
        
        let icon = UIImageView()
        icon.image = UIImage(named:"customer_service_white")
        view.addSubview(icon)
        icon.snp.makeConstraints { (make) in
            make.centerY.equalTo(title)
            make.trailing.equalTo(title.snp.leading).offset(-8.scale)
        }
        
        let contact = UIButton()
        contact.addTarget(self, action: #selector(btnContact), for: .touchUpInside)
        contact.titleLabel?.font = UIFont(name: "PingFangSC-Semibold", size:16.scale)
        contact.setTitle("马上联系 >", for: .normal)
        contact.setTitleColor(.tintColor, for:.normal)
        contact.layer.cornerRadius = 19.scale
        contact.clipsToBounds = true
        contact.setBackgroundImage(UIColor.white.image, for: .normal)
        view.addSubview(contact)
        contact.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.size.equalTo(CGSize(width: 142.scale, height: 38.scale))
            make.top.equalTo(title.snp.bottom).offset(15.scale)
        }
        
        let other = UILabel()
        other.text = "其他联系方式"
        other.backgroundColor = .clear
        other.textColor = .marchName
        other.font = UIFont(name: "PingFangSC-Regular", size:12.scale)
        other.textAlignment = .left
        view.addSubview(other)
        other.snp.makeConstraints { (make) in
            make.leading.equalTo(bk)
            make.top.equalTo(bk.snp.bottom).offset(10.scale)
        }
        
        let wechat = WeChatView()
        view.addSubview(wechat)
        wechat.snp.makeConstraints { (make) in
            make.centerX.leading.equalTo(bk)
            make.top.equalTo(other.snp.bottom).offset(10.scale)
        }
        
        let qq = LineView()
        qq.right.setTitle("复制QQ", for: .normal)
        view.addSubview(qq)
        qq.snp.makeConstraints { (make) in
            make.left.centerX.equalTo(bk)
            make.top.equalTo(wechat.snp.bottom).offset(10.scale)
        }
        
        let email = LineView()
        email.right.setTitle("复制邮箱", for: .normal)
        view.addSubview(email)
        email.snp.makeConstraints { (make) in
            make.left.centerX.equalTo(bk)
            make.top.equalTo(qq.snp.bottom).offset(10.scale)
        }
        
        vm.site {(result) in
            if case let .success(site) = result{
                wechat.qrCode.image = site.wx?.qrCode(size: CGSize(width: 120.scale, height: 120.scale))
                qq.left.text = "QQ联系   \(site.qq ?? "")"
                email.left.text = "邮箱联系   \(site.email ?? "")"
            }
        }
    }
    
    @objc func btnContact()->Void{
        print("--")
    }
}
extension ContactUsController{
    class WeChatView: UIView {
        let qrCode = UIImageView()
        let des = UILabel()
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = UIColor.line.withAlphaComponent(0.5)
            clipsToBounds = true
            layer.cornerRadius = 6.scale
            
            qrCode.backgroundColor = .clear
            addSubview(qrCode)
            qrCode.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
                make.size.equalTo(CGSize(width: 114.scale, height: 114.scale))
            }
            
            let title = UILabel()
            title.text = "微信联系"
            title.backgroundColor = .clear
            title.textColor = .marchName
            title.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            title.textAlignment = .left
            addSubview(title)
            title.snp.makeConstraints { (make) in
                make.leading.equalToSuperview().offset(13.scale)
                make.bottom.equalTo(qrCode.snp.top).offset(-10.scale)
            }
            
            
            des.text = "微信扫描二维码联系客服"
            des.backgroundColor = .clear
            des.textColor = .marchName
            des.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            des.textAlignment = .left
            addSubview(des)
            des.snp.makeConstraints { (make) in
                make.top.equalTo(qrCode.snp.bottom).offset(10.scale)
                make.centerX.equalToSuperview()
            }
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height:200.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    class LineView: UIView {
        let left = UILabel()
        let right = UIButton()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = UIColor.line.withAlphaComponent(0.5)
            clipsToBounds = true
            layer.cornerRadius = 6.scale
            
            left.backgroundColor = .clear
            left.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            left.textColor = .marchName
            left.textAlignment = .center
            addSubview(left)
            left.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.leading.equalToSuperview().offset(12.scale)
            }
            
            right.backgroundColor = .clear
            right.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
            right.setTitleColor(.tintColor, for: .normal)
            addSubview(right)
            right.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.trailing.equalToSuperview().offset(-12.scale)
            }
        }
        
        override var intrinsicContentSize: CGSize{
            return CGSize(width: UIView.noIntrinsicMetric, height:50.scale)
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
