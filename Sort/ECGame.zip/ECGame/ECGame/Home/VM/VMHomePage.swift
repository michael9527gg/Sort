//
//  VMHomePage.swift
//  ECGame
//
//  Created by Michale on 2019/10/11.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol VMHomePageProtocol:class {
    func refreshUI() -> Void
    func didSelect(promotion id:String) -> Void
    func didSelect(match id:String) -> Void
}


class VMHomePage:VMMatchObserver{
    
    weak var delegate:VMHomePageProtocol?
    
    var bannerList:[MPromotion]?
    
    var cellType:[HomePageView.CellType] = []
    
    func request() -> Void {
        getMatchHot()
        getBanners()
        getUserInfo()
    }
    
    override func updateUI() {
        delegate?.refreshUI()
    }
    
    func getSite(complete:@escaping (_ logo:String?)->Void) -> Void {
        VMContactUs().site {(result) in
            switch result{
            case let .success(site):
                complete(site.logo)
            case .failed:
                break
            }
        }
    }
    
    func getUserInfo() -> Void {
        VMUserInfo().getUserInfo { (result) in
            switch result{
            case .success:
                self.refreshUI()
            default:
                break
            }
        }
    }
    
    func getMatchHot() -> Void {
        Bet.provider.request(.egEgameMatchHotList) { (_ result: ECResult<[MEgEgameMatch]>) in
            if case let .success(array) = result{
                self.matchList = array
                self.refreshUI()
            }
        }
    }
    
    private func refreshUI() -> Void{
        cellType.removeAll()
        if bannerList != nil {
            cellType.append(.banner({[weak self] (cell) in
                cell.banner.csDelegate = self
                cell.banner.reloadData()
                cell.pageControl.numberOfPages = self?.bannerList?.count ?? 0
            }))
        }
        
        if let user = Account.current?.user {
            let headStr = "欢迎回来，"
            let fullStr = headStr + (user.nickName ?? (user.mobile ?? "新用户"))
            let title = NSMutableAttributedString(string: fullStr, attributes: [NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.tintColor])
            title.addAttributes([NSAttributedString.Key.foregroundColor :UIColor.white], range: NSRange(location: 0, length: headStr.count))
        
            let h = "您的余额 "
            let full = String(format: "\(h) ¥ %.2f",user.balance ?? 0)
            let balance = NSMutableAttributedString(string: full, attributes: [NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size: 14.scale)!,NSAttributedString.Key.foregroundColor:UIColor.tintColor])
            balance.addAttributes([NSAttributedString.Key.foregroundColor :UIColor.white,NSAttributedString.Key.font:UIFont(name: "PingFangSC-Semibold", size: 14.scale)!], range: NSRange(location: 0, length: h.count))
            
            cellType.append(.info(title:title, balance:balance))
        }
        
        if matchList != nil {
            let headStr = "今日比赛  "
            let fullStr = headStr //+ "共15场 >"
            let attr = NSMutableAttributedString(string: fullStr, attributes: [NSAttributedString.Key.font : UIFont(name: "PingFangSC-Regular", size: 12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.tintColor])
            attr.addAttributes([NSAttributedString.Key.foregroundColor :UIColor.white,NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size: 16.scale)!], range: NSRange(location: 0, length: headStr.count))
            
            cellType.append(.matchTitle(attr:attr))
            for m in matchList!{
                cellType.append(.match({(cell) in
                    cell.updateUI(with: m)
                },{[weak self] in
                    self?.delegate?.didSelect(match: m.mid)
                }))
            }
        }
        
        self.delegate?.refreshUI()
    }
    
    public func getBanners()->Void{
        BaseInfo.provider.request(.promotionList(state: 0, pageIndex: 0, pageSize: 0)) { (_ result:ECResult<[MPromotion]>) in
            if case let .success(array) = result{
                self.bannerList = array
                self.refreshUI()
            }
        }
    }
}

extension VMHomePage:HomePageProtocol{
    func numberOfItems() -> Int {
        return cellType.count
    }
    
    func cellForItemAt(row: Int) -> HomePageView.CellType {
      return cellType[row]
    }
}

extension VMHomePage:HomeBannerCollectionViewProtocol{
    func numberOfBanners() -> Int {
        return bannerList?.count ?? 0
    }
    
    func configBanner(cell: HomeBannerCollectionView.CollectionCell, row: Int) {
        let url = bannerList![row].imgUrl
        cell.image.setImage(url: url,placeholder: UIImage(named: "image_news_placeholder"))
    }
    
    func didSelectBanner(row: Int) {
        delegate?.didSelect(promotion: bannerList![row].pid ?? "")
    }
}
