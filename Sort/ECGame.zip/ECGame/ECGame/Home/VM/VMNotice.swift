//
//  VMNotice.swift
//  ECGame
//
//  Created by Michale on 2019/12/10.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

protocol VMNoticeProtocol:class {
    func success() -> Void
}

extension MNotice:MessageListCellProtocol{
    var titleText: String? {
        return title
    }
    
    var readStatus: Bool {
        get {
            return true
        }
        set {
            
        }
    }
    
    var timeText: String? {
        return publishDateTime
    }
    
    var detailText: String? {
        return content
    }
    
    var id: String? {
        return nid
    }
}

class VMNotice: VMBase {
    weak var delegate:VMNoticeProtocol?
    var dataSource:[MessageListView.CellType]?
    
    func getNoticeList() -> Void {
        BaseInfo.provider.request(.msgNoticeList(pageIndex:0, pageSize:0)) { (_ result:ECResult<[MNotice]>) in
            if case let .success(list) = result{
                self.dataSource = []
                for item in list{
                    self.dataSource?.append(.default(item))
                }
                self.delegate?.success()
            }
        }
    }
    
}

extension VMNotice:MessageListViewProtocol{
    func numberOfItems(in section: Int) -> Int {
        return dataSource?.count ?? 0
    }
    
    func cellForItem(at indexPath: IndexPath) -> MessageListView.CellType {
        return dataSource![indexPath.row]
    }
    
    func didSelectItem(at indexPath: IndexPath) {
        
    }
}
