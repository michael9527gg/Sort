//
//  VMContactUs.swift
//  ECGame
//
//  Created by Michale on 2019/12/27.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation

class VMContactUs: VMBase {
    enum Result {
        case success(MSiteOperator)
        case failed(String)
    }
    func site(complete:@escaping (_ result:Result)->Void) -> Void {
        BaseInfo.provider.request(.getSiteOperator) { (_ result:ECResult<MSiteOperator>) in
            switch result{
            case let .success(o):
                complete(.success(o))
            case let .failed(_, msg):
                complete(.failed(msg))
            case .unreachable:
                complete(.failed("网络无法连接"))
            default:
                complete(.failed("其他错误"))
            }
        }
    }
}
