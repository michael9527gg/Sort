//
//  HomeCollectionMatchTitle.swift
//  ECGame
//
//  Created by Michale on 2019/11/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class HomeCollectionMatchTitle: UICollectionViewCell {
    let right = OnlineCount()
    let left = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        left.backgroundColor = .clear
        left.textAlignment = .left
        contentView.addSubview(left)
        left.snp.makeConstraints { (make) in
            make.centerY.leading.equalToSuperview()
        }
        
        right.backgroundColor = .clear
        right.textAlignment = .right
        contentView.addSubview(right)
        right.snp.makeConstraints { (make) in
            make.centerY.trailing.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension HomeCollectionMatchTitle{
    class OnlineCount: UILabel,ECSocketOnlineProtocol {
        func onlineCountChanged(_ count: ECSocket.MOnlineCount) {
            let str = "在线人数\(count.count ?? 0)人"
            let attr = NSMutableAttributedString(string:str, attributes: [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size: 12.scale)!,NSAttributedString.Key.foregroundColor:UIColor.marchName])
             attr.addAttributes([NSAttributedString.Key.foregroundColor:UIColor.tintColor], range:NSRange(location:4, length:str.count-5))
            attributedText = attr
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            ECSocket.add(delegates: [.onlineCount(self)])
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
