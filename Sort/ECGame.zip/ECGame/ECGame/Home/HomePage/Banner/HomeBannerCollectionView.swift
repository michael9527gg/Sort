//
//  HomeBannerCollectionView.swift
//  EEGame
//
//  Created by Michale on 2019/10/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

private let id = "id"

protocol HomeBannerCollectionViewProtocol:class {
    func numberOfBanners() -> Int
    func configBanner(cell:HomeBannerCollectionView.CollectionCell,row:Int) -> Void
    func didSelectBanner(row:Int) -> Void
}

class HomeBannerCollectionView: UICollectionView {

    enum Event {
        case turn(page:Int)
    }
    
    weak var csDelegate:HomeBannerCollectionViewProtocol?

    override init(frame: CGRect,collectionViewLayout layout: UICollectionViewLayout) {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = CGSize(width: kScreenWidth - 2 * homeLeading, height:homeBannerHeight)
        super.init(frame: frame, collectionViewLayout: layout)
        backgroundColor = .clear
        delegate = self
        dataSource = self
        isPagingEnabled = true
        showsHorizontalScrollIndicator = false
        bounces = false
        register(CollectionCell.self, forCellWithReuseIdentifier: id)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let index =  Int(scrollView.contentOffset.x / scrollView.width)
        let event:Event = .turn(page: index)
        routerEvent(event)
    }
}

extension HomeBannerCollectionView: UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfBanners() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: id, for: indexPath) as! CollectionCell
        csDelegate?.configBanner(cell: cell, row: indexPath.row)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        csDelegate?.didSelectBanner(row: indexPath.row)
    }
}


extension HomeBannerCollectionView{
    class CollectionCell: UICollectionViewCell {
        let image = UIImageView()
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .clear
            contentView.backgroundColor = .clear
            contentView.addSubview(image)
            image.backgroundColor = .clear
            image.snp.makeConstraints { (make) in
                make.edges.equalToSuperview()
            }
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
