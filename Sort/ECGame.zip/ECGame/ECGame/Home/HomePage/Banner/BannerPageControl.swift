//
//  BannerPageControl.swift
//  ECGame
//
//  Created by Michale on 2019/12/10.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class BannerPageControl: UIPageControl {
    private let imageNormal = UIImage(named: "control_unpicked")
    private let imageHighlited = UIImage(named: "control_picked")
    
    override var currentPage: Int{
        get{
            return super.currentPage
        }
        set{
            super.currentPage = newValue
            updateDots()
        }
    }
    
    private func updateDots()->Void{
        for (i,item) in subviews.enumerated() {
            var img:UIImageView?
            if item.subviews.count == 0{
                img = UIImageView()
                item.addSubview(img!)
            }else{
                img = item.subviews.first as? UIImageView
            }
            item.backgroundColor = .clear
            img?.image = (i == currentPage) ? imageHighlited : imageNormal
            img?.frame = CGRect(origin: .zero, size: img?.image?.size ?? .zero)
        }
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width:super.intrinsicContentSize.width, height:10.scale)
    }
}
