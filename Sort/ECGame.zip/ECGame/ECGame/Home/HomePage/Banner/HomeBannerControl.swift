//
//  BannerPageControl.swift
//  ECGame
//
//  Created by Michale on 2019/12/10.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class BannerPageControl: UIPageControl {
    
}
