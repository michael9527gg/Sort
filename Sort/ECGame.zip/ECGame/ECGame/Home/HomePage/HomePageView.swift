//
//  HomePageView.swift
//  ECGame
//
//  Created by Michale on 2019/10/21.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

let homeLeading = 15.scale
let homeBannerHeight = 140.scale

protocol HomePageProtocol:class {
    func numberOfItems() -> Int
    func cellForItemAt(row:Int) -> HomePageView.CellType
}

class HomePageView: UICollectionView {
 
    var csDelegate:HomePageProtocol?
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        let flow = UICollectionViewFlowLayout()
        flow.minimumInteritemSpacing = 0
        flow.minimumLineSpacing = 10.scale
        flow.sectionInset = UIEdgeInsets(top:0, left:homeLeading, bottom:0, right:homeLeading)
        super.init(frame: frame, collectionViewLayout: flow)
        
        backgroundColor = .navigatonBar
        showsVerticalScrollIndicator = false
        delegate = self
        dataSource = self
        let cells:[CellType] = [.banner(nil),
                                .info(title: nil, balance: nil),.match(nil,nil),
                                .matchTitle(attr: nil),.news,.newsTitle]
        for g in cells{
            register(g.cellClass, forCellWithReuseIdentifier: g.reuserId)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}



extension HomePageView:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return csDelegate?.numberOfItems() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = csDelegate!.cellForItemAt(row: indexPath.row)
        let cell:UICollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier:type.reuserId, for: indexPath)
        
        switch type {
        case let .banner(config):
            if let b = config{
                b(cell as! HomeCollectionBannerCell)
            }
        case let .matchTitle(attr):
            (cell as! HomeCollectionMatchTitle).left.attributedText = attr
        case let .match(config,_):
            if let b = config,let c = cell as? MatchListCell{
                b(c)
                /// Disabled Button Click
                c.team.leftOdds.isEnabled = false
                c.team.rightOdds.isEnabled = false
            }
        case let .info(title, balance):
            if let c = cell as? HomeCollectionInfoCell{
                c.name.attributedText = title
                c.balance.attributedText = balance
            }
        default:
            break
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let type = csDelegate!.cellForItemAt(row: indexPath.row)
        switch type {
        case let .match(_,didSelect):
            didSelect?()
        default:
            break
        }
    }
}

extension HomePageView:UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return csDelegate!.cellForItemAt(row: indexPath.row).sizeForItem
    }
}


extension HomePageView{
    enum CellType {
        
        case banner(_ config:((_ cell:HomeCollectionBannerCell)->Void)?)
        case info(title:NSAttributedString?,balance:NSAttributedString?)
        case match(_ config:((_ cell:MatchListCell)->Void)?,_ didSelect:(()->Void)?)
        case matchTitle(attr:NSAttributedString?)
        case news
        case newsTitle
        
        var reuserId:String{
            switch self {
            case .banner:
                return "banner"
            case .info:
                return "info"
            case .match:
                return "match"
            case .news:
                return "news"
            case .matchTitle:
                return "matchTitle"
            case .newsTitle:
                return "newsTitle"
            }
        }
        
        var cellClass: UICollectionViewCell.Type{
            switch self {
            case .banner:
                return HomeCollectionBannerCell.self
            case .info:
                return HomeCollectionInfoCell.self
            case .match:
                return MatchListCell.self
            case .news:
                return HomeCollectionNewsCell.self
            case .matchTitle:
                return HomeCollectionMatchTitle.self
            case .newsTitle:
                return HomeCollectionNewsTitle.self
            }
        }
        
        var sizeForItem: CGSize{
            var height:CGFloat = 0
            switch self {
            case .banner:
                height = homeBannerHeight
            case .info:
                height = 85.scale
            case .match:
                height = MatchTeamView.height
            case .news:
                height = 205.scale
            case .matchTitle:
                height = 30.scale
            case .newsTitle:
                height = 40.scale
            }
            return CGSize(width:kScreenWidth - 2 * homeLeading,height:height)
        }
    }
}

