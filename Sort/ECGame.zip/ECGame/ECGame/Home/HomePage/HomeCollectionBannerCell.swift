//
//  HomeCollectionBannerCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class HomeCollectionBannerCell: UICollectionViewCell {
    let banner = HomeBannerCollectionView()
    let pageControl = BannerPageControl()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 8.scale
        clipsToBounds = true
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        contentView.addSubview(banner)
        banner.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        pageControl.backgroundColor = .clear
        pageControl.hidesForSinglePage = true
        contentView.addSubview(pageControl)
        pageControl.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
    override func routerEvent(_ event: Any) {
        if case let .turn(page)? = event as? HomeBannerCollectionView.Event{
            pageControl.currentPage = page
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
