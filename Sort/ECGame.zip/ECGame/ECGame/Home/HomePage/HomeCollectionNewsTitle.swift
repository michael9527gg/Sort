//
//  HomeCollectionNewsTitle.swift
//  ECGame
//
//  Created by Michale on 2019/11/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class HomeCollectionNewsTitle: UICollectionViewCell {
    let left = UILabel()
    let right = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        left.backgroundColor = .clear
        left.textAlignment = .left
        left.textColor = .white
        left.text = "新闻"
        left.font = UIFont(name: "PingFangSC-Regular", size: 16.scale)
        contentView.addSubview(left)
        left.snp.makeConstraints { (make) in
            make.centerY.leading.equalToSuperview()
        }
        
        right.backgroundColor = .clear
        right.textAlignment = .right
        right.textColor = .tintColor
        right.text = "查看更多 >"
        right.font = UIFont(name: "PingFangSC-Regular", size: 12.scale)
        contentView.addSubview(right)
        right.snp.makeConstraints { (make) in
            make.centerY.trailing.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
