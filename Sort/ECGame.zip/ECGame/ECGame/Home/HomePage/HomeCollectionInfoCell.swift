//
//  HomeCollectionInfoCell.swift
//  ECGame
//
//  Created by Michale on 2019/11/19.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit



class HomeCollectionInfoCell: UICollectionViewCell {
    
    enum Event {
        case charge
    }
    
    let name = UILabel()
    let balance = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear

        name.backgroundColor = .clear
        name.textAlignment = .center
        contentView.addSubview(name)
        name.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10.scale)
            make.centerX.equalToSuperview()
        }
        
        let radius = 20.scale
        let bottom = UIView()
        bottom.layer.borderWidth = 1
        bottom.layer.borderColor = UIColor(red:151/255.0, green:151/255.0, blue: 151/255.0, alpha: 0.5).cgColor
        bottom.clipsToBounds = true
        bottom.layer.cornerRadius = radius
        bottom.backgroundColor = .clear
        contentView.addSubview(bottom)
        bottom.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(name.snp.bottom).offset(10.scale)
            make.height.equalTo(radius * 2)
        }
        
        let btn = UIButton()
        btn.addTarget(self, action: #selector(btnClick), for: .touchUpInside)
        let image = UIImage(named: "bg_recharge")
        btn.setBackgroundImage(image, for: .normal)
        btn.setTitle("去充值 >", for: .normal)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        btn.setTitleColor(.white, for: .normal)
        bottom.addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.top.bottom.trailing.equalToSuperview()
            make.width.equalTo((image!.size.width/image!.size.height) * radius * 2)
        }
        
        
        balance.backgroundColor = .clear
        balance.textAlignment = .left
        bottom.addSubview(balance)
        balance.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(18.scale)
        }
    }
    
    @objc func btnClick()->Void{
        let event:Event = .charge
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
