//
//  RegisterBar.swift
//  ECGame
//
//  Created by Michale on 2019/11/20.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit


class HomePageBottomBar: UIImageView {
    
    enum Event {
        case registerClick
    }
    
    convenience init() {
        self.init(frame: .zero)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isUserInteractionEnabled = true
        image = UIImage(named: "bg_signin1")
        
        let lable = UILabel()
        lable.text = "现在加入开心电竞，马上下注！"
        lable.backgroundColor = .clear
        lable.font = UIFont(name: "PingFangSC-Regular", size:14.scale)
        lable.textColor = .white
        lable.textAlignment = .left
        addSubview(lable)
        lable.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(15.scale)
        }
        let radio = 15.scale
        let btn = UIButton()
        btn.layer.cornerRadius = radio
        btn.clipsToBounds = true
        btn.addTarget(self, action:#selector(register), for: .touchUpInside)
        btn.setTitle("注册 >", for: .normal)
        btn.setBackgroundImage(UIColor.white.image, for: .normal)
        btn.setTitleColor(.tintColor, for: .normal)
        btn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size:16.scale)
        addSubview(btn)
        btn.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.size.equalTo(CGSize(width:82.scale, height:radio*2))
            make.trailing.equalToSuperview().offset(-15.scale)
        }
    }
    
    @objc func register() ->Void{
        let event:Event = .registerClick
        routerEvent(event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var intrinsicContentSize: CGSize{
        return CGSize(width: UIView.noIntrinsicMetric, height: 50.scale)
    }
}
