//
//  HomeCollectionNewsCell.swift
//  EEGame
//
//  Created by Michale on 2019/10/7.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class HomeCollectionNewsCell: UICollectionViewCell {
    
   private let title  = UILabel()
   private let image  = UIImageView()
   private let number = UILabel()
   private let time   = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        image.backgroundColor = .clear
//        image.image = UIImage(named: "neewssaa")
        image.layer.cornerRadius = 5
        image.clipsToBounds = true
        contentView.addSubview(image)
        image.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(140.scale)
        }
        
        title.backgroundColor = .clear
        title.textColor = .white
        title.textAlignment = .left
        title.font = UIFont(name: "PingFangSC-Semibold", size: 16.scale)
//        title.text = "S6入围赛数据：孙"
        contentView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.top.equalTo(image.snp.bottom).offset(11.scale)
            make.leading.trailing.equalToSuperview()
        }


        let eye = UIImageView(image: UIImage(named: "icon_eye"))
        eye.backgroundColor = .clear
        contentView.addSubview(eye)
        eye.snp.makeConstraints { (make) in
            make.leading.equalTo(title)
            make.top.equalTo(title.snp.bottom).offset(6.scale)
        }
        
        number.backgroundColor = .clear
        number.textAlignment = .left
        number.textColor = .marchName
        number.text = "8"
        number.font = UIFont(name: "PingFangSC-Regular", size: 14.scale)
        contentView.addSubview(number)
        number.snp.makeConstraints { (make) in
            make.centerY.equalTo(eye)
            make.leading.equalTo(eye.snp.trailing).offset(5.scale)
        }
        
        let timg = UIImageView(image: UIImage(named: "icon_time"))
        timg.backgroundColor = .clear
        contentView.addSubview(timg)
        timg.snp.makeConstraints { (make) in
            make.centerY.equalTo(number)
            make.leading.equalToSuperview().offset(100.scale)
        }
        
        time.backgroundColor = .clear
        time.textColor = number.textColor
        time.text = "3小时前"
        time.font = number.font
        contentView.addSubview(time)
        time.snp.makeConstraints { (make) in
            make.centerY.equalTo(timg)
            make.leading.equalTo(timg.snp.trailing).offset(5.scale)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
