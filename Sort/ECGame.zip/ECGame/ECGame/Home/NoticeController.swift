//
//  NoticeController.swift
//  ECGame
//
//  Created by Michale on 2019/12/10.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class NoticeController: BaseController {
    let vm = VMNotice()
    let listView = MessageListView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "公告"
        setBackButton()
    }
    
    override func loadView() {
        view = listView
        listView.csDelegate = vm
        vm.delegate = self
        vm.getNoticeList()
    }
}

extension NoticeController:VMNoticeProtocol{
    func success() {
        listView.reloadData()
    }
}
