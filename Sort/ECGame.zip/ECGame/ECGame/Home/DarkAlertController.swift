//
//  LoginAlertController.swift
//  ECGame
//
//  Created by Michale on 2019/12/4.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class DarkAlertController: BaseController {
    
    enum ButtonType {
        case `default`(title:String?,action:(()->Void)?)
        case hilight(title:String?,action:(()->Void)?)
    }
    
    private var titleStr: String?
    private var buttons: [ButtonType]?
    
   
    convenience init(title:String?,buttons:[ButtonType]?) {
        self.init(nibName: nil, bundle: nil)
        titleStr = title
        self.buttons = buttons
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle:nibBundleOrNil)
        modalPresentationStyle = .custom
        modalTransitionStyle = .crossDissolve
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func loadView() {
        super.loadView()
        view.backgroundColor = .init(red: 0, green: 0, blue: 0, alpha: 0.65)
        
        let ctView = UIView()
        ctView.layer.cornerRadius = 4.scale
        ctView.clipsToBounds = true
        ctView.backgroundColor = .line
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.leading.equalToSuperview().offset(30.scale)
            make.height.equalTo(155.scale)
        }
        
        let title = UILabel()
        title.font = UIFont(name: "PingFangSC-Medium", size:18.scale)
        title.textColor = .white
        title.text = titleStr
        title.textAlignment = .center
        title.backgroundColor = .clear
        ctView.addSubview(title)
        title.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(34.scale)
        }
        
        let leading = 10.scale
        var pre:UIView?
        if let btns = buttons{
            for (tag,item) in btns.enumerated(){
                let btn = UIButton()
                btn.tag = tag
                btn.addTarget(self, action: #selector(btnClick(sender:)), for: .touchUpInside)
                btn.layer.cornerRadius = 6.scale
                btn.clipsToBounds = true
                btn.backgroundColor = .clear
                var ck:UIColor?
                switch item{
                case let .default(title,_):
                    btn.layer.borderColor = UIColor.note.cgColor
                    btn.layer.borderWidth = 1
                    ck = .line
                    btn.setTitle(title, for: .normal)
                case let .hilight(title,_):
                    ck = .tintColor
                    btn.setTitle(title, for: .normal)
                }
                btn.setBackgroundImage(ck?.image, for: .normal)
                
                ctView.addSubview(btn)
                btn.snp.makeConstraints { (make) in
                    if pre == nil{
                        make.leading.equalToSuperview().offset(leading)
                    }else{
                        make.leading.equalTo(pre!.snp.trailing).offset(leading)
                    }
                    make.height.equalTo(48.scale)
                    make.bottom.equalToSuperview().offset(-15.scale)
                    make.width.equalToSuperview().multipliedBy(1.0/Double(buttons!.count)).offset(-leading / CGFloat(buttons!.count) - leading)
                }
                pre = btn
            }
        }
    }
    
    @objc func btnClick(sender:UIButton)->Void{
        dismiss(animated: true, completion: {[weak self] in
            if let btn = self?.buttons,btn.count > sender.tag {
                switch btn[sender.tag]{
                case let .default(_,action):
                    if action != nil{
                        action!()
                    }
                case let .hilight(_,action):
                    if action != nil{
                        action!()
                    }
                }
            }
        })
    }
}
