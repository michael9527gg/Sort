//
//  HomePageController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import SnapKit

class HomePageController: BaseController {

    private let vm = VMHomePage()
    private let ctView = HomePageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func setNavigation() -> Void {
        let left = UIBarButtonItem(image: UIImage(named: "Notice")?.withRenderingMode(.alwaysOriginal), style: .done, target: self, action: #selector(leftClick))
        navigationItem.leftBarButtonItem = left
        
        let h = 25.scale
        let w = 200.scale
        let icon = UIImageView(frame:CGRect(origin: .zero, size: CGSize(width:w, height:h)))
        icon.contentMode = .scaleAspectFit
        navigationItem.titleView = icon
        vm.getSite { (logo) in
            icon.setImage(url:logo)
        }
        
        let right = UIBarButtonItem(image: UIImage(named: "customer_service")?.withRenderingMode(.alwaysOriginal), style: .done, target: self, action: #selector(rightClick))
        navigationItem.rightBarButtonItem = right
    }

   
    @objc override func leftClick() -> Void {
        let notice = NoticeController()
        notice.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(notice, animated:true)
    }
    
    @objc func rightClick() -> Void {
        let contact = ContactUsController()
        contact.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(contact, animated: true)
    }
    
    override func loadView() {
        super.loadView()
        updateView(isLogin: Account.current != nil)
        vm.delegate = self
        ctView.csDelegate = vm
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setNavigation()
        updateView(isLogin: Account.current != nil)
        vm.addObserver()
        vm.request()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        vm.remeveObserver()
    }
    
    func updateView(isLogin:Bool) -> Void {
        for item in view.subviews {
            item.removeFromSuperview()
        }
        view.addSubview(ctView)
        ctView.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            if isLogin{
                make.bottom.equalToSuperview()
            }
        }
        
        if !isLogin {
            let bottom = HomePageBottomBar()
            view.addSubview(bottom)
            bottom.snp.makeConstraints {[weak self] (make) in
                make.leading.trailing.equalToSuperview()
                make.bottom.equalTo(self!.view.snp.bottomMargin)
                make.top.equalTo(ctView.snp.bottom)
            }
        }
    }
    
    override func routerEvent(_ event: Any) {
        if case .registerClick? = event as? HomePageBottomBar.Event{
            TabBarController.current?.register(complete: {[weak self] (success) in
                if success{
                    self?.updateView(isLogin: Account.current != nil)
                    self?.vm.getUserInfo()
                }
            })
            return
        }
        if case .charge? = event as? HomeCollectionInfoCell.Event{
            print("去充值")
            return
        }
    }
}

extension HomePageController:VMHomePageProtocol{
    func didSelect(promotion id: String) {
        let detail = DiscountDetailControler(id: id)
        detail.title = "优惠详情"
        detail.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(detail, animated: true)
    }
    
    func didSelect(match id: String) {
        let match = MatchDetailController(mid: id)
        present(match, animated:true, completion:nil)
    }
    
    func refreshUI() {
        ctView.reloadData()
    }
}
