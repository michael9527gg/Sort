//
//  BaseNavigationController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class NavigationController: UINavigationController {

    enum `Type` {
        case `default`
        case white
        case image
        case color(UIColor)
    }
    
    override init(rootViewController: UIViewController) {
        _type = .default
        super.init(rootViewController: rootViewController)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        _type = .default
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var _type:`Type`
    var type:`Type`{
        get{
            return _type
        }
        set{
            func set(ck:UIColor) ->Void{
                navigationBar.setBackgroundImage(nil, for: .default)
                navigationBar.barTintColor = ck
                navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Regular", size: 17)!,NSAttributedString.Key.foregroundColor:UIColor.white]
            }
            _type = newValue
            switch newValue {
            case let .color(ck):
                set(ck: ck)
            case .default:
                set(ck: .navigatonBar)
            case .white:
                navigationBar.setBackgroundImage(nil, for: .default)
                navigationBar.barTintColor = .white
            case .image:
                navigationBar.titleTextAttributes = [NSAttributedString.Key.font:UIFont(name: "PingFangSC-Semibold", size: 17)!,NSAttributedString.Key.foregroundColor:UIColor.white]
                navigationBar.setBackgroundImage(UIImage(named: "bk_login_navigation"), for: .default)
            }
            setNeedsStatusBarAppearanceUpdate()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationBar.shadowImage = UIImage()
        navigationBar.isTranslucent = false
        type = .default
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        switch type {
        case .white:
            return .default
        default:
            return .lightContent
        }
    }
    
}
