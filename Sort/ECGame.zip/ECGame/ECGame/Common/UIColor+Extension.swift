//
//  UIColor+Extension.swift
//  EEGame
//
//  Created by Michale on 2019/10/7.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit



extension UIColor{
    
    open class var notify:UIColor{
        return UIColor(hexString: "#222B36")
    }
    
    open class var up:UIColor{
        return UIColor(hexString: "#00C873")
    }
    
    open class var down:UIColor{
        return UIColor(hexString: "#FF3750")
    }
    
    open class var placeHolder:UIColor{
        return UIColor(hexString: "#797979")
    }
    
    open class var odds:UIColor{
        return UIColor(hexString: "#FFD827")
    }
    
    open class var subUser:UIColor{
        return UIColor(hexString:"#294D4F")
    }
    
    open class var selected:UIColor{
        return UIColor(hexString: "#1E967B")
    }
    
    open class var title:UIColor{
        return UIColor(hexString: "#232321")
    }
    
    open class var error:UIColor{
        return UIColor(hexString:"#E02020")
    }
    
    open class var disabled:UIColor{
        return UIColor(hexString: "#9B9B9B")
    }
    
    
    open class var inactivate:UIColor{
        return UIColor(hexString: "#434343")
    }
    
    /// 登陆按钮 前景色
    open class var loginBtn:UIColor{
        return UIColor(hexString: "#FFAA01")
    }
    
    /// 下一步 背景色
    open class var nextBtn:UIColor{
        return UIColor(hexString: "#EEEEEE")
    }
    
    /// 忘记密码 前景色
    open class var forgetPwd:UIColor{
        return UIColor(hexString: "#666666")
    }
    
    /// 提示
    open class var note:UIColor{
        return UIColor(hexString: "#A2A2A2")
    }
    
    /// 比赛名称 前景色
    open class var marchName:UIColor{
        return UIColor(hexString: "#C4C5CB")
    }
    
    /// 分割线 背景色
    open class var line:UIColor{
        return UIColor(hexString: "#303C4C")
    }
    
    /// Tabbar tintColor
    open class var tintColor:UIColor{
        return UIColor(hexString: "#44D7B6")
    }
    
    open class var borderColor:UIColor{
        return UIColor(hexString: "#E6E6E6")
    }
    
    /// 导航栏 背景色
    open class var navigatonBar:UIColor{
        return UIColor(hexString: "#121C29")
    }
    
    var image:UIImage?{
        get{
            let frame = CGRect(x: 0, y: 0, width: 1, height:1)
            UIGraphicsBeginImageContext(frame.size)
            let context = UIGraphicsGetCurrentContext()
            context?.setFillColor(cgColor)
            context?.fill(frame)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return image
        }
    }
    
    // Hex String -> UIColor
    convenience init(hexString: String) {
        let hexString = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        
        if hexString.hasPrefix("#") {
            scanner.scanLocation = 1
        }
        
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        
        self.init(red: red, green: green, blue: blue, alpha: 1)
    }
}
