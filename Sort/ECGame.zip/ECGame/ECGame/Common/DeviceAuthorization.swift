//
//  DeviceAuthorization.swift
//  ECGame
//
//  Created by Michale on 2019/12/13.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import Photos
import AVFoundation

class DeviceAuthorization {
    enum `Type` {
        case first(Bool)
        case `default`(Bool)
    }
    
    typealias Complete = (_ result:`Type`)->Void

    class func video(_ complete:Complete?) -> Void {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        switch status {
        case .authorized:
            complete?(.default(true))
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { (s) in
                complete?(.first(s))
            }
        default:
            complete?(.default(false))
        }
    }
    
    
    class func photo(_ complete:Complete?) -> Void {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            complete?(.default(true))
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { (s) in
                complete?(.first(s == .authorized))
            }
        default:
            complete?(.default(false))
        }
    }
    
    class func toSetting() -> Void {
        if let url = URL(string: UIApplication.openSettingsURLString){
            if (UIApplication.shared.canOpenURL(url)){
                UIApplication.shared.open(url, options: [:], completionHandler:nil)
            }
        }
    }
    
    /// 切换闪光灯
    class func switchTorch()->Void{
        let device = AVCaptureDevice.default(for: .video)
        if device?.hasFlash == true{
            try? device?.lockForConfiguration()
            
            if device?.torchMode == .some(.on){
                device?.torchMode = .off
            }else{
                device?.torchMode = .on
            }
            device?.unlockForConfiguration()
        }
    }
}
