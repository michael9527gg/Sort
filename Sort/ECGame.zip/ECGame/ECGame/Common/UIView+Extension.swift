
//
//  afdsa.swift
//  ECGame
//
//  Created by Michale on 2019/10/14.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

extension Int{
    var scale:CGFloat{
        return CGFloat(self).scale
    }
}

extension CGFloat{
    var scale:CGFloat{
        //base w:375 h:667,iPhone 8
        let w = kScreenWidth
        if w < 375{
            return self * w/375
        }
        return self
    }
}

extension UIView{
    
    var origin:CGPoint{
        set{
            frame = CGRect(x: newValue.x, y: newValue.y, width: width, height: height)
        }
        get{
            return frame.origin
        }
    }
    
    var x:CGFloat{
        set{
            frame = CGRect(x: newValue, y: y, width: width, height: height)
        }
        get{
            return frame.origin.x
        }
    }
    
    var y:CGFloat{
        set{
            frame = CGRect(x: x, y: newValue, width: width, height: height)
        }
        get{
            return frame.origin.y
        }
    }
    
    var width:CGFloat{
        set{
            frame = CGRect(x: x, y: y, width:newValue, height: height)
        }
        get{
            return frame.size.width
        }
    }
    
    var height:CGFloat{
        set{
            frame = CGRect(x: x, y: y, width:width, height:newValue)
        }
        get{
            return frame.size.height
        }
    }
    
    var size:CGSize{
        set{
            frame = CGRect(x: x, y: y, width:newValue.width, height: newValue.height)
        }
        get{
            return frame.size
        }
    }
    
    var center:CGPoint{
        set{
            frame = CGRect(x: newValue.x-width/2, y:newValue.y - height/2, width: width, height: height)
        }
        get{
            return CGPoint(x:x + width/2, y:y + height/2)
        }
    }
    
    var centerX:CGFloat{
        set{
            center = CGPoint(x: newValue, y: centerY)
        }
        get{
            return center.x
        }
    }
    
    var centerY:CGFloat{
        set{
            center = CGPoint(x: centerX, y: newValue)
        }
        get{
            return center.y
        }
    }
    
    func nextResponder<T:UIResponder>() -> T?{
        var p = next
        while p != nil {
            if let d = p as? T{
                return d
            }
            p = p?.next
        }
        return nil
    }
    
    var topWindow:UIWindow?{
        get{
            let w:UIWindow? = nextResponder()
            return w
        }
    }
    
    var currentController:UIViewController?{
        get{
            let c:UIViewController? = nextResponder()
            return c
        }
    }
}
