//
//  UIImage+Extension.swift
//  ECGame
//
//  Created by Michale on 2019/12/13.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


extension UIImage{
    
    var qrCodes:[String]?{
        //1. 创建过滤器
        let detector = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: nil)
        
        //2. 获取CIImage
        guard let ciImage = CIImage(image:self) else { return nil }
        
        //3. 识别二维码
        guard let features = detector?.features(in: ciImage) else { return nil }
        
        //4. 遍历数组, 获取信息
        var resultArr = [String]()
        for feature in features {
            if let qr = feature as? CIQRCodeFeature,let msg = qr.messageString{
                resultArr.append(msg)
            }
        }
        return resultArr
    }
}
