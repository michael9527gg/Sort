//
//  WebViewController.swift
//  EEGame
//
//  Created by Michale on 2019/10/8.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: BaseController {

    private var url:String
    let webView = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())
   
    init(urlStr:String) {
        url = urlStr
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func loadView() {
        view = webView
        webView.backgroundColor = .navigatonBar
        webView.scrollView.bounces = false
        let request = URLRequest(url: URL(string: url)!, cachePolicy: URLRequest.CachePolicy.returnCacheDataElseLoad, timeoutInterval: 15)
        
        if title == nil {
            webView.addObserver(self, forKeyPath: "title", options: NSKeyValueObservingOptions.new, context: nil)
        }
        
        webView.load(request)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "title" {
            if object as? WKWebView == webView {
                title = webView.title ?? ""
            }
        }
    }

}
