//
//  KeyboardMover.swift
//  ECGame
//
//  Created by Michale on 2019/12/26.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import UIKit

protocol KeyboardMoverProtocol:class {
    var movingViewWithKeyboard:UIView{
        get
    }
}

class KeyboardMover{
    enum `Type` {
        case alwaysAboveKeyboard(offset:CGFloat)
    }
    
    private var type:`Type`
    weak var delegate:KeyboardMoverProtocol?
    
    init(type:`Type` = .alwaysAboveKeyboard(offset: 0)) {
        self.type = type
        let center = NotificationCenter.default
        center.addObserver(self, selector:#selector(keyBoardWillShow(note:)), name:UIResponder.keyboardWillShowNotification, object: nil)
        center.addObserver(self, selector:#selector(keyBoardWillHide(note:)), name:UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    @objc func keyBoardWillShow(note:NSNotification){
        guard let movingView = delegate?.movingViewWithKeyboard else {
            return
        }
        
        let userInfo  = note.userInfo! as NSDictionary
        let  keyBoardBounds = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let duration = (userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        
        //        _ = convert(keyBoardBounds, to:nil)
        
        //        _ = movingView.frame
        let deltaY = keyBoardBounds.size.height
        
        let options = UIView.AnimationOptions(rawValue: UInt((userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as! NSNumber).intValue << 16))
        
        UIView.animate(withDuration: duration, delay: 0, options:options, animations: {
            movingView.transform = CGAffineTransform(translationX: 0,y: -deltaY)
        }, completion: nil)
    }
    
    @objc func keyBoardWillHide(note:NSNotification){
        guard let movingView = delegate?.movingViewWithKeyboard else {
            return
        }
        
        let userInfo  = note.userInfo! as NSDictionary
        let duration = (userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        let options = UIView.AnimationOptions(rawValue: UInt((userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as! NSNumber).intValue << 16))
        UIView.animate(withDuration: duration, delay: 0, options:options, animations: {
            movingView.transform = .identity
        }, completion: nil)
    }
    
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
}
