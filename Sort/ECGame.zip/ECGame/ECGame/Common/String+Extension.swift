//
//  String+Extension.swift
//  ECGame
//
//  Created by Michale on 2019/10/15.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import CommonCrypto
import UIKit
import CoreImage

extension String{
    
    func qrCode(size:CGSize) -> UIImage? {
        let filter = CIFilter(name: "CIQRCodeGenerator")
        filter?.setDefaults()
        let data = self.data(using:String.Encoding.utf8)
        filter?.setValue(data, forKey: "inputMessage")
        if let ci = filter?.outputImage{
            let sz = ci.extent.size
            let transform = ci.transformed(by: CGAffineTransform(scaleX:size.width/sz.width, y: size.height/sz.height))
            return UIImage(ciImage: transform)
        }
        return nil
    }
    
    var md5:String{
        let str = self.cString(using: String.Encoding.utf8)
        let strLen = CUnsignedInt(self.lengthOfBytes(using: String.Encoding.utf8))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<UInt8>.allocate(capacity: 16)
        CC_MD5(str!, strLen, result)
        let hash = NSMutableString()
        for i in 0 ..< digestLen {
            hash.appendFormat("%02x", result[i])
        }
        free(result)
        return String(format: hash as String)
    }
    
    func evaluate(_ pattern:String) -> Bool {
        return NSPredicate(format: "SELF MATCHES %@",pattern).evaluate(with:self)
    }
}
