//
//  CaptchImageView.swift
//  ECGame
//
//  Created by Michale on 2019/10/14.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

class CaptchImageView: UIImageView {

    private var charCount:Int = 5
    public var captchaKey:String?
    
    init(width:CGFloat,height:CGFloat,charCount:Int = 5) {
        super.init(frame: CGRect(x: 0, y: 0, width: width, height: height))
        self.charCount = charCount
        getCaptcha()
        isUserInteractionEnabled = true
    }
    
    func getCaptcha() -> Void {
        BaseInfo.provider.request(.getCaptcha(width:Int(self.frame.self.width), height: Int(self.frame.self.height), charCount:charCount)) {[weak self] (_ result:ECResult<MCaptchaInfo>) in
            if case let .success(captcha) = result,
                let data = captcha.image,
                let img = UIImage(data: data){
                self?.image = img
                self?.captchaKey = captcha.captchaKey
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        captchaKey = nil
        getCaptcha()
        super.touchesBegan(touches, with: event)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
