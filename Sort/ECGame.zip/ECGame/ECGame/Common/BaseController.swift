//
//  BaseController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


let kScreenWidth  = UIScreen.main.bounds.size.width
let kScreenHeight = UIScreen.main.bounds.size.height


class BaseController: UIViewController {
    
    enum Event {
        case copy(String?)
    }
    
    var navigationType:NavigationController.`Type`?
    
    func setBackButton(isBlack:Bool = false) -> Void {
        let left = UIBarButtonItem(image: UIImage(named:isBlack ? "icon_back_black" : "icon_back_white")?.withRenderingMode(.alwaysOriginal), style: .done, target: self, action: #selector(leftClick))
        navigationItem.leftBarButtonItem = left
    }
    
    
    @objc func leftClick() ->Void{
        navigationController?.popViewController(animated: true)
    }
    
    override func routerEvent(_ event: Any) {
        switch event as? Event {
        case let .copy(text)?:
            copyLable(text: text)
        default:
            break
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let n = navigationController as? NavigationController{
            n.type = navigationType ?? .default
        }
    }
    
    func copyLable(text:String?) -> Void {
        UIPasteboard.general.string = text ?? ""
    }
    
    deinit {
        print("销毁--\(self)")
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }
}
