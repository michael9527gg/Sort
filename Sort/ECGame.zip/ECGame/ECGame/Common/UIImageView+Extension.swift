//
//  UIImageView+Extension.swift
//  ECGame
//
//  Created by Michale on 2019/10/21.
//  Copyright © 2019 EC. All rights reserved.
//

import Foundation
import Kingfisher

extension UIImageView{
    
    func setImage(url:String?,placeholder:UIImage? = nil,completion:((_ success:Bool) -> Void)? = nil) -> Void {
        if url == nil {
            image = placeholder
            return
        }
        let u = URL(string: url!)
        kf.setImage(with:u, placeholder: placeholder) { (result) in
            switch result{
            case .failure:
                completion?(false)
            case .success:
                completion?(true)
            }
        }
    }
}
