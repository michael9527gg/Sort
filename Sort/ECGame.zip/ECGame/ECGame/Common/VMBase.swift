//
//  VMBase.swift
//  ECGame
//
//  Created by Michale on 2019/10/11.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit


class VMBase:NSObject {
    deinit {
        print("---deint\(self)")
    }
}
