//
//  MainTabBarController.swift
//  EEGame
//
//  Created by Michale on 2019/10/6.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit



class TabBarController: UITabBarController {
    
    static var current:TabBarController?
    
    init() {
        super.init(nibName: nil, bundle: nil)
        type(of: self).current = self
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        delegate = self
        let array:[(BaseController,String,String,String)] = [(HomePageController(),"主页","Icon_home_grey","Icon_home"),(NewsController(),"咨讯","Icon_information_grey","Icon_information"),(MatchListController(),"竞猜","Icon_lottery_grey","Icon_lottery"),(DiscountListController(),"优惠","Icon_discounts_grey","Icon_discounts"),(MineViewController(),"我的","Icon_my_grey","Icon_my")]
        
        for v in array {
            let nav = NavigationController(rootViewController: v.0)
            nav.tabBarItem = UITabBarItem(title: v.1, image: UIImage(named: v.2)?.withRenderingMode(.alwaysOriginal), selectedImage: UIImage(named: v.3)?.withRenderingMode(.alwaysOriginal))
            addChild(nav)
        }
        
        tabBar.barTintColor = .navigatonBar
        tabBar.tintColor = .tintColor
        tabBar.unselectedItemTintColor = UIColor(hexString: "#A1A1A1")
        tabBar.isTranslucent = false
    }
    
    func register(complete:((_ success:Bool)->Void)?) -> Void {
        
        let alert = AlertLoginController(login: {[weak self] in
            let pack = PackageLogin()
            pack.startLogin(self!.selectedViewController!, completion: { (success) in
                complete?(success)
            })
            }, register: {[weak self] in
                let pack = PackageLogin()
                pack.startRegister(self!.selectedViewController!,completion: { (success) in
                    complete?(success)
                })
        }) {[weak self] in
            ScanQRCodeController.startScan(ctr:self!.selectedViewController!, complete: { (text) in
                if text != nil{
                    let pack = PackageLogin()
                    pack.startRegister(self!.selectedViewController!, inviteCode: text, completion: { (success) in
                        complete?(success)
                    })
                }else{
                    complete?(false)
                }
            })
        }
        selectedViewController?.present(alert, animated: true, completion:nil)
    }
}


extension TabBarController:UITabBarControllerDelegate{
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        if let nav = viewController as? NavigationController,
            nav.viewControllers.count > 0,nav.viewControllers.first!.isKind(of: MineViewController.self),Account.current == nil{
            register {[weak self] (success) in
                if success{
                    self?.selectedIndex = self!.viewControllers!.count - 1
                }
            }
            return false
        }
        
        return true
    }
}
