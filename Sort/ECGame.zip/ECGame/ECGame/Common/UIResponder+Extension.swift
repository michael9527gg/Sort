//
//  UIResponder+Extension.swift
//  ECGame
//
//  Created by Michale on 2019/10/18.
//  Copyright © 2019 EC. All rights reserved.
//

import UIKit

extension UIResponder{
   
    @objc func routerEvent(_ event:Any) -> Void {
        next?.routerEvent(event)
    }
}
